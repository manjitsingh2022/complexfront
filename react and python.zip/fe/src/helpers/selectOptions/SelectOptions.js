const options = [
  [
    { id: 1, name: 'Invoice' },
    { id: 2, name: 'P.O' },
    { id: 3, name: 'Quote' },
    { id: 4, name: 'Timesheet' }
  ],
  [
    { id: 5, name: 'KLT Machinery and Plant Hire' },
    { id: 6, name: 'Quartz Plant Hire' },
    { id: 7, name: 'Red Top Asset Management' }
  ],
  [
    { id: 9, name: 'Articulated Dump Truck' },
    { id: 10, name: 'Dozer' },
    { id: 11, name: 'Excavator' },
    { id: 12, name: 'Hydraulic Excavator' }
  ],
  [
    { id: 13, name: 'John Paul' },
    { id: 14, name: 'David Fincher' },
    { id: 15, name: 'Willie Engelbrecht' }
  ],
  [
    { id: 17, name: '6x4' },
    { id: 18, name: '20 Ton' },
    { id: 19, name: 'D6H' }
  ]
]

export default options
