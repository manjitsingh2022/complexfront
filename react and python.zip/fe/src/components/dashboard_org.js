// 13831cc3247a2481ada98ef61c691214

import { useEffect, useState } from "react";
import React from "react";
import { MDBContainer } from "mdbreact";
import NavBar from "./NavBar";
import { history } from "../helpers/history";
import Clock from "react-clock";
import ReactWeather, {
  useVisualCrossing,
  useWeatherBit,
} from "react-open-weather";
import { MDBIcon } from "mdb-react-ui-kit";
import "react-clock/dist/Clock.css";
import { userActions } from "../store/actions/user.actions";
import { machineActions } from "../store/actions/machine.action";
import { useDispatch, useSelector } from "react-redux";
import { timesheetActions } from "../store/actions/timeSheet.actions";
import moment from "moment";
import Nav from "react-bootstrap/Nav";
import weatherIcon from "../assets/images/weather.png";
// import weatherIcon2 from "../assets/icons/soncevo-oblacno.png";
import axios from "axios";
import {
  convertToInternationalCurrencySystem,
  formatCurrency,
} from "../helpers/Helper";
import { apiUrl } from "../config/config";
import SideBar from "./SideBar";

const Dashboard = () => {
  const moveToTimesheet = (tm_url) => {
    window.location.assign(tm_url);
  };

  const moveToCFOTimesheet = (id, type) => {
    window.location.assign(`/list-timesheet/?id=${id}`);

    // window.location.assign(tm_url);
  };

  const moveToListTimesheet = (ltm_url) => {
    window.location.assign(ltm_url);
  };
  const moveToListUrgentAnomalies = () => {
    window.location.assign(`/anomalies/?status=${"Urgent"}`);
  };
  const sheetCounts = useSelector(
    (state) => state.getMessagesById.sheet_counts
  );
  const msg_loading = useSelector((state) => state.getMessagesById.msg_loading);
  const tdyDate = new Date();
  const crntDate = String(tdyDate.getDate()).padStart(2, "0");
  const crntMonth = tdyDate.toLocaleString("default", { month: "short" });
  const crntDay = tdyDate.toLocaleString("default", { weekday: "long" });

  const msgData = useSelector((state) => state.getMessagesById.data);
  const mchnMsgData = useSelector((state) => state.getMachineMessagesById.data);
  const dispatch = useDispatch();
  const [clockValue, setClockValue] = useState(new Date());
  const [currentLat, setCurrentLat] = useState(null);
  const [currentLon, setCurrentLon] = useState(null);
  const [isWeather, setIsWeather] = useState(true);

  const user_dt = useSelector((state) => state.users);
  let widgetArr = [1, 2];

  // const { data, isLoading, errorMessage } = useVisualCrossing({
  //     key: "3KR6VMN8AKYXUQVJ6S6TSWDF3",
  //     lat: currentLat,
  //     lon: currentLon,
  //     lang: "en",
  //     unit: "metric",
  // });

  const { data, isLoading, errorMessage } = useWeatherBit({
    key: "b04991905b4e46bca4fb376eaabac999",
    lat: "53.2734",
    lon: "-7.77832031",
    lang: "en",
    unit: "M", // values are (M,S,I)
  });

  const getMyLocation = () => {
    // if (navigator.geolocation) {
    //     } else {
    //     alert(“Sorry Not available!”);
    // const location = window.navigator && window.navigator.geolocation;
    // if (location) {
    //     location.getCurrentPosition((position) => {
    //         setCurrentLat(position.coords.latitude);
    //         setCurrentLon(position.coords.longitude);
    //         setIsWeather(true);
    //     });
    // }
  };
  const [wind, setWind] = useState(null);
  const [windgusts, setWindgusts] = useState(null);
  const [currentTemperature, SetCurrentTemperature] = useState(null);
  const [weather1, setWeather1] = useState(null);
  const [city, setCity] = useState(null);
  const [wthr, setWeatherData] = useState(null);
  const [wLongitude, setWLongitude] = useState(null);
  const [wLatitude, setWLatitude] = useState(null);

  useEffect(() => {
    dispatch(userActions.getUserData());
    getMyLocation();
    if (navigator.geolocation) {
      let weatherUnit = "metric";
      navigator.geolocation.getCurrentPosition((position) => {
        setWLatitude(position.coords.latitude);
        setWLongitude(position.coords.longitude);
        const API_KEY = "d2d614fb93d05b0642711077c7c78856";
        let city = "";
        fetch("https://ipapi.co/json/")
          .then((response) => response.json())
          .then((data) => {
            axios.get("https://ipapi.co/json/").then((response) => {
              city = response.data.city;
              setCity(response.data.city);
            });

            // const API_URL = `https://api.openweathermap.org/data/2.5/weather?lat=${position.coords.latitude}&lon=${position.coords.longitude}&appid=d2d614fb93d05b0642711077c7c78856`;
            // axios.get(API_URL).then((response) => {
            //     setWeather1(response.data);
            // });
            // .catch((error) => console.log(error));
            axios
              .get(
                `https://api.openweathermap.org/data/2.5/weather?lat=${position.coords.latitude}&lon=${position.coords.longitude}&appid=a7aec0005ad81a470818c6ecdd2c313b&units=${weatherUnit}`
              )

              .then((response) => {
                SetCurrentTemperature(Math.ceil(response.data.main["temp"]));
                setWind(response.data.wind["speed"]);
                setWindgusts(response.data.wind["gust"]);
              });
          });
      });
    }

    if (user_dt) {
      dispatch(timesheetActions.getMessagesById());
      dispatch(machineActions.getMachineMessagesById());
    }

    history.push("/");

    const interval = setInterval(() => setClockValue(new Date()), 1000);

    return () => {
      clearInterval(interval);
    };

    // if (user_dt){

    // }
  }, [currentLat, currentLon]);

  return (
    <>
      <div className="App">
        <SideBar />
        <main className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row justify-content-center  m-0 p-0">
          <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 m-top-40 m-0 p-0  text-center">
            <span className="ovrview-heading ml-2">
              Welcome ,{" "}
              {user_dt.items !== undefined
                ? user_dt.items.role_detail.role !== "CFO"
                  ? user_dt.items.company_name +
                    " (" +
                    user_dt.items.role_detail.role +
                    ")"
                  : " " + user_dt.items.role_detail.role
                : null}{" "}
            </span>
          </div>
          <div className="col-sm-11 col-lg-11 col-xs-11 col-md-11 row justify-content-center border-box5 mr-btm-40 m-top-40 pd-0 hght-850px pl-0 pr-0 ">
            <div className="col-sm-12 col-lg-9 col-xs-12 col-md-9 row  ml-0 pr-0 ">
              <MDBContainer>
                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 justify-content-center mt16 row m-0 p-0">
                  <div className="mt30 col-sm-12 col-lg-6 col-xs-12 col-md-6 crsr-pointer justify-content-center d-flex txt-alg-cnt2 txt-alg-cntr mx-auto mt-3 p-0">
                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                      <p
                        className="cstm-inpt-text pd-top10 pl20 pr20 dshbd-head gry-clr m-0 p-0"
                        onClick={() => {
                          moveToListTimesheet(`/list-timesheet`);
                        }}
                      >
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                          Total Timesheets Submitted
                          <i
                            className="fa fa-bars fnt-24 bar-icon flt-right"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="row align-items-center justify-content-center">
                          <div className="col-12 ">
                            <div className="row">
                              <div className="col-12 sheet-count  text-center">
                                {sheetCounts ? (
                                  <p className="mt-4">
                                    {convertToInternationalCurrencySystem(
                                      sheetCounts["total_sheets"]
                                    )}
                                  </p>
                                ) : (
                                  <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                        {/* <div className="sheet-count mt-20">
                                            {sheetCounts ? (
                                                sheetCounts["total_sheets"]
                                            ) : (
                                                <span className=" mar-left-40-px fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                            )}
                                        </div> */}
                      </p>
                    </div>
                  </div>
                  <div className=" mt30 col-sm-12 col-lg-6 col-xs-12 col-md-6 crsr-pointer txt-alg-txt-alg-cntr txt-alg-cnt2 justify-content-cente d-flex mx-auto  mt-3 p-0">
                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                      <p
                        className="cstm-inpt-text pd-top10 pl20 pr20 dshbd-head gry-clr m-0 p-0"
                        onClick={() => {
                          moveToListTimesheet(
                            `/list-timesheet/?status=Approved`
                          );
                        }}
                      >
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                          Approved Timesheets
                          <i
                            className="fa fa-bars fnt-24 bar-icon flt-right"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="row align-items-center justify-content-center">
                          <div className="col-12">
                            <div className="row">
                              <div className="col-12 sheet-count  text-center">
                                {sheetCounts ? (
                                  <p className="mt-4 ">
                                    {sheetCounts["approved_sheets"]}
                                  </p>
                                ) : (
                                  <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </p>
                    </div>
                  </div>
                </div>
                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 justify-content-center row m-0   p-0">
                  <div className=" mt30 col-sm-12 col-lg-6 col-xs-12 col-md-6 crsr-pointer justify-content-center d-flex txt-alg-cnt2 txt-alg-cntr mx-auto mt-3 p-0">
                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                      <p
                        className="cstm-inpt-text pd-top10 pl20 pr20 dshbd-head gry-clr m-0 p-0"
                        onClick={() => {
                          moveToListTimesheet(
                            `/list-timesheet/?status=Pending`
                          );
                        }}
                      >
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                          {/* <MDBIcon className="fas fa-check-square	"></MDBIcon>{" "} */}
                          Timesheets In Progress
                          <i
                            className="fa fa-bars fnt-24 bar-icon flt-right"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="row align-items-center justify-content-center">
                          <div className="col-12">
                            <div className="row">
                              <div className="col-12 sheet-count  text-center">
                                {sheetCounts ? (
                                  <p className="mt-4">
                                    {sheetCounts["pending_sheets"]}
                                  </p>
                                ) : (
                                  <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </p>
                    </div>
                  </div>
                  <div className="mt30 col-sm-12 col-lg-6 col-xs-12 col-md-6 crsr-pointer txt-alg-cntr justify-content-cente txt-alg-cnt2 d-flex mx-auto  mt-3 p-0">
                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                      <p
                        className="cstm-inpt-text pd-top10 pl20 pr20 dshbd-head gry-clr  m-0 p-0"
                        onClick={() => {
                          moveToListTimesheet(
                            `/list-timesheet/?status=Request Clarification`
                          );
                        }}
                      >
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                          {/* <MDBIcon className="fas fa-check-square	"></MDBIcon>{" "} */}
                          Request Clarification
                          <i
                            className="fa fa-bars fnt-24 bar-icon flt-right"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="row align-items-center justify-content-center">
                          <div className="col-12">
                            <div className="row">
                              <div className="col-12 sheet-count  text-center">
                                {sheetCounts ? (
                                  <p className="mt-4">
                                    {sheetCounts["clarification_sheets"]}
                                  </p>
                                ) : (
                                  <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </p>
                    </div>
                  </div>
                </div>
                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 justify-content-center row m-0  p-0">
                  <div className=" mt30 col-sm-12 col-lg-6 col-xs-12 col-md-6 crsr-pointer justify-content-center d-flex txt-alg-cnt2 txt-alg-cntr mx-auto mt-3 p-0">
                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                      <p
                        className="cstm-inpt-text pd-top10 pl20 pr20 dshbd-head gry-clr m-0 p-0"
                        onClick={() => {
                          moveToListTimesheet(`/machines`);
                        }}
                      >
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                          Total Machines Logged
                          <i
                            className="fa fa-bars fnt-24 bar-icon flt-right"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="row align-items-center justify-content-center">
                          <div className="col-12 ">
                            <div className="row">
                              <div className="col-12 sheet-count  text-center">
                                {sheetCounts ? (
                                  <p className="mt-4">
                                    {sheetCounts["total_machines"]}
                                  </p>
                                ) : (
                                  <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </p>
                    </div>
                  </div>
                  <div className=" mt30 col-sm-12 col-lg-6 col-xs-12 col-md-6 crsr-pointer txt-alg-cntr justify-content-cente txt-alg-cnt2 d-flex mx-auto  mt-3 p-0">
                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                      <p
                        className="cstm-inpt-text pd-top10 pl20 pr20 dshbd-head gry-clr m-0 p-0"
                        onClick={() => {
                          moveToListTimesheet(`/view-document`);
                        }}
                      >
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                          Data Available
                          <i
                            className="fa fa-bars fnt-24 bar-icon flt-right"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="row align-items-center justify-content-center">
                          <div className="col-12">
                            <div className="row">
                              <div className="col-12 sheet-count  text-center">
                                {sheetCounts ? (
                                  <p className="mt-4 ">
                                    {formatCurrency(
                                      sheetCounts["total_documents"]
                                    )}
                                  </p>
                                ) : (
                                  <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </p>
                    </div>
                  </div>
                </div>
                {user_dt.items !== undefined
                  ? user_dt.items.role_detail.role === "CFO" && (
                      <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 justify-content-center mb50 row m-0  p-0">
                        <div className=" mt30 col-sm-12 col-lg-6 col-xs-12 col-md-6 crsr-pointer justify-content-center d-flex txt-alg-cnt2 txt-alg-cntr mx-auto mt-3 p-0">
                          <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                            <p
                              className="cstm-inpt-text pd-top10 pl20 pr20 dshbd-head gry-clr m-0 p-0"
                              onClick={() => {
                                moveToListTimesheet(`/anomalies`);
                              }}
                            >
                              <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                Number of Total Anomalies
                                <i
                                  className="fa fa-bars fnt-24 bar-icon flt-right"
                                  aria-hidden="true"
                                ></i>
                              </div>
                              <div className="row align-items-center justify-content-center">
                                <div className="col-12 ">
                                  <div className="row">
                                    <div className="col-12 sheet-count  text-center">
                                      {sheetCounts ? (
                                        <p className="mt-4">
                                          {sheetCounts["anom_count"]}
                                        </p>
                                      ) : (
                                        <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </p>
                          </div>
                        </div>
                        <div className=" mt30 col-sm-12 col-lg-6 col-xs-12 col-md-6 crsr-pointer justify-content-center d-flex txt-alg-cnt2 txt-alg-cntr mx-auto mt-3 p-0">
                          <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                            <p
                              className="cstm-inpt-text pd-top10 pl20 pr20 dshbd-head gry-clr m-0 p-0"
                              onClick={() => {
                                moveToListUrgentAnomalies();
                              }}
                            >
                              <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                Urgent Anomalies
                                <i
                                  className="fa fa-bars fnt-24 bar-icon flt-right"
                                  aria-hidden="true"
                                ></i>
                              </div>
                              <div className="row align-items-center justify-content-center">
                                <div className="col-12">
                                  <div className="row">
                                    <div className="col-12 sheet-count  text-center">
                                      {sheetCounts ? (
                                        <p className="mt-4 ">
                                          {formatCurrency(
                                            sheetCounts["urgent_anomalies"]
                                          )}
                                        </p>
                                      ) : (
                                        <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </p>
                          </div>
                        </div>
                      </div>
                    )
                  : null}
                {/* <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0 justify-content-center   row">
                                <div className=" mt30 p-0 col-sm-12 col-lg-6 col-xs-12 col-md-6 mt-3 crsr-pointer justify-content-center mx-auto d-flex txt-alg-cnt2 txt-alg-cntr">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                                        <p
                                            className="cstm-inpt-text p-0 m-0 pd-top10 pl20 pr20 dshbd-head gry-clr"
                                            onClick={() => {
                                                moveToListTimesheet(
                                                    `/machines`
                                                );
                                            }}
                                        >
                                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                                Urgent Anomalies
                                                <i
                                                    className="fa fa-bars fnt-24 bar-icon flt-right"
                                                    aria-hidden="true"
                                                ></i>
                                            </div>
                                            <div className="row align-items-center justify-content-center">
                                                <div className="col-12 ">
                                                    <div className="row">
                                                        <div className="col-12 text-center  sheet-count">
                                                            {sheetCounts ? (
                                                                <p className="mt-4">
                                                                    {
                                                                        sheetCounts[
                                                                            "anom_count"
                                                                        ]
                                                                    }
                                                                </p>
                                                            ) : (
                                                                <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                                <div className=" mt30 p-0 col-sm-12 col-lg-6 col-xs-12 col-md-6 mt-3 crsr-pointer justify-content-center mx-auto d-flex txt-alg-cnt2 txt-alg-cntr"></div>
                            </div> */}
              </MDBContainer>
            </div>
            <div className="col-sm-12 col-lg-3 col-xs-12 col-md-3 row m-t-l bg-clr pb30 ml-0 mr-0 p-0 pl-0  ">
              <div className="bg-clr pr-0 ">
                <div className="col-sm-11 col-lg-11 col-xs-11 col-md-11 row d-flex msg-box2 mx-auto">
                  <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 temp-bars">
                    <i
                      className="fa fa-bars fnt-24 bar-icon "
                      aria-hidden="true"
                    ></i>
                  </div>
                  <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row pr-0">
                    {/* <div className="col-sm-10 col-lg-10 col-xs-10 col-md-10 pr-0 pt21"> */}
                    <p className="wthr-box">
                      {crntDate} {crntMonth}, {crntDay}
                    </p>
                    {/* </div> */}
                  </div>
                  <div className="col-sm-5 col-lg-5 col-xs-5 col-md-5">
                    {/* <img
                      src={weatherIcon2}
                      alt="icon"
                      className="weather-icon"
                    /> */}
                  </div>
                  <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 margin-left-20 wdth-54 m-0 p-0">
                    <span className="temperature">
                      {currentTemperature ? currentTemperature : `23`}{" "}
                      <span className="celsius-icon">&deg;</span> C
                    </span>
                  </div>
                  <div className="col-sm-12 col-lg-12 col-xs-12  col-md-12 row">
                    <div className="col-sm-5 col-lg-5 col-xs-5  col-md-5">
                      <p className="wind-txt mr-l">Wind</p>
                    </div>
                    <div className="col-sm-7 col-lg-7 col-xs-7  col-md-7">
                      <p className="wind-txt mr-l">
                        NW {wind ? wind : `10`} km/h
                      </p>
                    </div>
                  </div>
                  <div className="col-sm-12 col-lg-12 col-xs-12  col-md-12 mr-t-10 row">
                    <div className="col-sm-5 col-lg-5 col-xs-5  col-md-5">
                      <p className="wind-txt mr-l ">Wind Gusts</p>
                    </div>
                    <div className="col-sm-7 col-lg-7 col-xs-7  col-md-7">
                      <p className="wind-txt m-l-30px">
                        {windgusts ? windgusts : `20`} km/h
                      </p>
                    </div>
                  </div>
                </div>

                <hr className="brdr-dash mb35" />
              </div>
              <div className="hght-29 scrl">
                <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12  ">
                  {msgData ? (
                    msgData.map((data) => (
                      <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack msg-bx brdr-radius-15 p-0">
                        <div className="col-sm-11 col-lg-11 col-xs-11 col-md-11 d-flex msg-box mx-auto">
                          {" "}
                          {user_dt !== undefined &&
                          user_dt.items.role_detail.role === "CFO" ? (
                            <div
                              className="cstm-inpt-text top402 crsr-pointer  m-0 p-0"
                              onClick={() =>
                                user_dt !== undefined &&
                                user_dt.items.role_detail.role === "CFO"
                                  ? moveToCFOTimesheet(
                                      data.timesheet,
                                      data.type
                                    )
                                  : null
                              }
                            >
                              <p className="msg-txt crsr-pointer">
                                {data.Message}
                                <br></br>@{" "}
                                {moment(data.created_at).format(
                                  "DD.MM.YYYY hh.mm A"
                                )}
                              </p>
                            </div>
                          ) : (
                            <div
                              className="cstm-inpt-text crsr-pointer top402 m-0 p-0"
                              onClick={() => {
                                user_dt !== undefined &&
                                user_dt.items.role_detail.role !== "Approver"
                                  ? moveToTimesheet(
                                      `/edit-timesheet/id=${data.timesheet}`
                                    )
                                  : moveToTimesheet(
                                      `/list-timesheet/?id=${data.timesheet}`
                                    );
                              }}
                            >
                              <p className="msg-txt crsr-pointer">
                                {data.Message}
                                <br></br>@{" "}
                                {moment(data.created_at).format(
                                  "DD.MM.YYYY hh.mm A"
                                )}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="col-12 sheet-count  text-center">
                      {msg_loading ? (
                        <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                      ) : (
                        <>
                          <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 ">
                            <p className="cstm-inpt-text top402 m-0 p-0 text-center">
                              No new Notification
                            </p>
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* {mchnMsgData &&
                                mchnMsgData.map((data) => (
                                    <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 ">
                                        <div className="col-sm-10 col-lg-10 col-xs-10 col-md-10 msg-box">
                                            {" "}
                                            <div className="cstm-inpt-text p-0 m-0  top402">
                                                <p className="msg-txt crsr-pointer">
                                                    {data.message}
                                                    <br></br>@{" "}
                                                    {moment(
                                                        data.created_at
                                                    ).format(
                                                        "DD.MM.YYYY hh.mm A"
                                                    )}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                ))} */}
            </div>
          </div>
        </main>
      </div>
    </>
  );
};

export default Dashboard;
