import { useState } from "react";
import {
    MDBBtn,
    MDBModal,
    MDBModalDialog,
    MDBModalContent,
    MDBModalBody,
    MDBModalFooter,
    MDBModalHeader,
    MDBModalTitle,
} from "mdb-react-ui-kit";
import concIcon from "../assets/icons/conc.svg";
import doneIcon from "../assets/icons/done.svg";
import expirIcon from "../assets/icons/expir.svg";
import infoIcon from "../assets/icons/info.svg";
import pendIcon from "../assets/icons/pend.svg";
import warnIcon from "../assets/icons/warn.svg";
import document from "../assets/images/document.png";
import document2 from "../assets/images/contracts-document.jpg";

import AuditTable from "./AnomaliesAuditTable";
import { anomalieActions } from "../store/actions/anomalies.actions";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";

const AnomaliespopUp = (props) => {
    const anomalie_loading = useSelector(
        (state) => state.UpdatedAnomalies.anomalie_loading
    );
    const anomalies_data = useSelector((state) => state.UpdatedAnomalies.data);
    const dispatch = useDispatch();
    const audit_data = props.data.audit_data;
    const anomalie_data = props.data;
    const [anomaliePopUp, setAnomaliePopUp] = useState(true);
    const anomaliesplant = props.data.plant;

    const [viewdocumentPage, setViewDocumentPage] = useState(true);
    const [viewAuditPage, setViewAuditPage] = useState(false);

    const HandleDocumentActive = () => {
        setViewDocumentPage(true);
        setViewAuditPage(false);
    };

    const HandleAuditActive = () => {
        setViewDocumentPage(false);
        setViewAuditPage(true);
        setNext(false);
    };

    const [next, setNext] = useState(false);
    const [Previous, setPrevious] = useState(false);

    const HandleNextActive = () => {
        setNext(true);
        setViewDocumentPage(false);
        setPrevious(false);
    };

    const HandlePreviousActive = () => {
        setNext(false);
        setPrevious(false);
        setViewDocumentPage(true);
    };

    const toggle = () => {
        setAnomaliePopUp(false);
        props.hideAnomaliePopUp(anomaliePopUp);
    };

    const handleUpdateStatus = (status) => {
        dispatch(
            anomalieActions.updateAnomaliesStatus(status, anomalie_data["id"])
        );
    };

    return (
        <MDBModal show={anomaliePopUp} setShow={anomaliePopUp}>
            <MDBModalDialog size="xl">
                <MDBModalContent>
                    <MDBModalHeader>
                        <MDBModalTitle className="wdth-94">
                            <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 ">
                                <h4 className="txt-alg-cntr p-0 m-0">
                                    Anomalies Details
                                </h4>
                            </div>
                        </MDBModalTitle>

                        <MDBBtn
                            className="btn-close"
                            color="none"
                            onClick={toggle}
                        ></MDBBtn>
                    </MDBModalHeader>
                    <MDBModalBody>
                        <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 mt15  d-flex justify-content-center row">
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Invoice-PO Price Difference
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INV_PO_Price_Difference ||
                                    anomalie_data.INV_PO_Price_Difference === 0
                                        ? anomalie_data.INV_PO_Price_Difference
                                        : `N/A`}
                                </p>
                            </div>

                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Invoice Purchase Order Price Anomaly
                                    Indicator
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INV_PO_Price_Anomaly_Indicator ===
                                        false ||
                                    anomalie_data.INV_PO_Price_Anomaly_Indicator ===
                                        true
                                        ? anomalie_data.INV_PO_Price_Anomaly_Indicator.toString()
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 ">
                                <h5 className="m-l-16px">
                                    Invoice Purchase Order Price Anomaly Status
                                </h5>
                                <p className=" mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INV_PO_Price_Anomaly_Status
                                        ? anomalie_data.INV_PO_Price_Anomaly_Status
                                        : `N/A`}
                                </p>
                            </div>

                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Reason for Price Anomaly
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INV_PO_Price_Anomaly_Reason
                                        ? anomalie_data.INV_PO_Price_Anomaly_Reason
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Wet Day Rate</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.WetDayRate
                                        ? anomalie_data.WetDayRate
                                        : `N/A`}
                                </p>
                            </div>

                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Dry Day Rate</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.DryDayRate
                                        ? anomalie_data.DryDayRate
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    PO-Wet Rate Difference
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.PO_Wet_Rate_Difference
                                        ? anomalie_data.PO_Wet_Rate_Difference
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    PO-Dry Rate Difference
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.PO_Dry_Rate_Difference
                                        ? anomalie_data.PO_Dry_Rate_Difference
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Invoice Number</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INV_Invoice
                                        ? anomalie_data.INV_Invoice
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Invoice Date</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INV_InvoiceDate
                                        ? moment(
                                              anomalie_data.INV_InvoiceDate
                                          ).format("YYYY-MM-DD")
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Invoice Due Date</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INV_DueDate
                                        ? moment(
                                              anomalie_data.INV_DueDate
                                          ).format("YYYY-MM-DD")
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Original Invoice Value
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INV_OrigInvValue
                                        ? anomalie_data.INV_OrigInvValue
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Invoice Transaction Value
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INVPay_TrnValue
                                        ? anomalie_data.INVPay_TrnValue
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Invoice Transaction Type
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INVPay_TrnType === "P" &&
                                        "Payment"}
                                    {anomalie_data.INVPay_TrnType === "A" &&
                                        "Adjustment"}
                                    {anomalie_data.INVPay_TrnType === "C" &&
                                        "Credit Note"}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Linked Document Number
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.INV_Reference
                                        ? anomalie_data.INV_Reference
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Purchase Order Number
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.PODet_PurchaseOrder
                                        ? anomalie_data.PODet_PurchaseOrder
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Purchase Order Entry Date
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.POHdr_OrderEntryDate
                                        ? moment(
                                              anomalie_data.POHdr_OrderEntryDate
                                          ).format("YYYY-MM-DD")
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Purchase Order Due Date
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.POHdr_OrderDueDate
                                        ? moment(
                                              anomalie_data.POHdr_OrderDueDate
                                          ).format("YYYY-MM-DD")
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Purchase Order Stock Code
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.PODet_MStockCode
                                        ? anomalie_data.PODet_MStockCode
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Purchase Order Price
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.PODet_MPrice
                                        ? anomalie_data.PODet_MPrice
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Machine Type</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.MachineType
                                        ? anomalie_data.MachineType
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Machine Subtype</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.MachineSubType
                                        ? anomalie_data.MachineSubType
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Hire Type</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {anomalie_data.HireType
                                        ? anomalie_data.HireType
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6"></div>
                        </div>
                        {/* <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 ">
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row text-center mr-b-10px">
                                <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 text-right">
                                    {anomalie_data.anomalies_status ===
                                        "conc" && (
                                        <img
                                            src={concIcon}
                                            alt="icon"
                                            className="anomalies-text p-0 m-2"
                                        />
                                    )}
                                    {anomalie_data.anomalies_status ===
                                        "warn" && (
                                        <img
                                            src={warnIcon}
                                            alt="icon"
                                            className="anomalies-text p-0 m-2"
                                        />
                                    )}
                                    {anomalie_data.anomalies_status ===
                                        "done" && (
                                        <img
                                            src={doneIcon}
                                            alt="icon"
                                            className="anomalies-text p-0 m-2"
                                        />
                                    )}
                                    {anomalie_data.anomalies_status ===
                                        "info" && (
                                        <img
                                            src={infoIcon}
                                            alt="icon"
                                            className="anomalies-text p-0 m-2"
                                        />
                                    )}
                                    {anomalie_data.anomalies_status ===
                                        "expire" && (
                                        <img
                                            src={expirIcon}
                                            alt="icon"
                                            className="anomalies-text p-0 m-2"
                                        />
                                    )}
                                    {anomalie_data.anomalies_status ===
                                        "pend" && (
                                        <img
                                            src={pendIcon}
                                            alt="icon"
                                            className="anomalies-text p-0 m-2"
                                        />
                                    )}
                                </div>
                                <div className="col-sm-7 col-lg-7 col-xs-7 col-md-7 text-left mr-t-5">
                                    <p className="">{anomaliesplant}</p>
                                </div>
                            </div>
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row">
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-3">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                        <p
                                            className={
                                                viewdocumentPage
                                                    ? "nav-selcted"
                                                    : "hover-underline-animation crsr-pointer "
                                            }
                                            onClick={HandleDocumentActive}
                                        >
                                            document
                                        </p>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                        <p
                                            className={
                                                viewAuditPage
                                                    ? "nav-selcted"
                                                    : "hover-underline-animation crsr-pointer "
                                            }
                                            onClick={HandleAuditActive}
                                        >
                                            Audits
                                        </p>
                                    </div>
                                </div>
                                {next && (
                                    <div className="col-sm-12 col-lg-9 col-xs-12 col-md-9  ">
                                        <img
                                            className="document d-flex "
                                            src={document2}
                                            alt="document"
                                        />
                                    </div>
                                )}
                                {Previous && (
                                    <div className="col-sm-12 col-lg-9 col-xs-12 col-md-9  ">
                                        <img
                                            className="document d-flex "
                                            src={document}
                                            alt="document"
                                        />
                                    </div>
                                )}
                                {viewdocumentPage && (
                                    <div className="col-sm-12 col-lg-9 col-xs-12 col-md-9  ">
                                        <img
                                            className="document d-flex "
                                            src={document}
                                            alt="document"
                                        />
                                    </div>
                                )}
                                {viewAuditPage && (
                                    <div className="col-sm-12 col-lg-9 col-xs-12 col-md-9  p-0">
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 row m-0 audit-text">
                                            <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 text-center">
                                                <p className="mr-r-32"> What</p>
                                            </div>
                                            <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 text-center">
                                                <p className="mr-l-26"> When</p>
                                            </div>
                                            <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 text-center">
                                                <p className="mr-l-115"> Who</p>
                                            </div>
                                        </div>
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                            <AuditTable data={audit_data} />
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                        {anomalie_loading === false && anomalies_data && (
                            <div className="success-msg mt-3">
                                Status Updated successfully
                            </div>
                        )} */}
                    </MDBModalBody>

                    {/* <MDBModalFooter> */}
                    {/* <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0 row  mx-auto">
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 p-0 m-0 row  mx-auto">
                                <div className="col-sm-3 col-lg-3 col-xs-3 col-md-3 p-0 m-0 close-bt5 mx-auto ">
                                    <MDBBtn
                                        className={
                                            viewAuditPage
                                                ? "dsply-none"
                                                : "close-btn2"
                                        }
                                        onClick={HandlePreviousActive}
                                        disabled={
                                            next || next === true
                                                ? false
                                                : next === true
                                                ? false
                                                : true
                                        }
                                    >
                                        Previous
                                    </MDBBtn>
                                </div>
                                <div className="col-sm-3 col-lg-3 col-xs-3 col-md-3 p-0 m-0 close-bt4 mx-auto ">
                                    <MDBBtn
                                        className="close-btn2"
                                        onClick={toggle}
                                    >
                                        Close
                                    </MDBBtn>
                                </div>
                                <div className="col-sm-3 col-lg-3 col-xs-3 col-md-3 p-0 m-0 close-bt4 mx-auto ">
                                    <MDBBtn
                                        className="done-btn"
                                        onClick={() =>
                                            handleUpdateStatus("done")
                                        }
                                    >
                                        DONE
                                    </MDBBtn>
                                </div>
                                <div className="col-sm-3 col-lg-3 col-xs-3 col-md-3 p-0 m-0 close-bt4 mx-auto ">
                                    <MDBBtn
                                        className="warn-btn"
                                        onClick={() =>
                                            handleUpdateStatus("warn")
                                        }
                                    >
                                        WARN
                                    </MDBBtn>
                                </div>
                                <div className="col-sm-3 col-lg-3 col-xs-3 col-md-3 p-0 m-0 close-bt4 mx-auto ">
                                    <MDBBtn
                                        className={
                                            viewAuditPage
                                                ? "dsply-none"
                                                : "close-btn2"
                                        }
                                        onClick={HandleNextActive}
                                        disabled={
                                            viewdocumentPage ||
                                            viewdocumentPage === true
                                                ? false
                                                : viewdocumentPage === true
                                                ? false
                                                : true
                                        }
                                    >
                                        Next
                                    </MDBBtn>
                                </div>
                            </div>
                        </div> */}
                    {/* </MDBModalFooter> */}
                </MDBModalContent>
            </MDBModalDialog>
        </MDBModal>
    );
};

export default AnomaliespopUp;
