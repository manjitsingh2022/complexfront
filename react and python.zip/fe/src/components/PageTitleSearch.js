import { useEffect, useRef, useState } from "react";

import searchIcon from "../assets/icons/search-icon.svg";

function PageTitleSearch() {
    const title = "Financial Data";
    const subtitle = "Here's an overview of your Finance data";
    const inputRef = useRef();
    const [isInputEmpty, setIsInputEmpty] = useState(true);

    useEffect(() => {
        const currentRef = inputRef.current;

        const handleInputChange = () => {
            setIsInputEmpty(currentRef.value === "");
        };

        currentRef.addEventListener("input", handleInputChange);

        return () => {
            currentRef.removeEventListener("input", handleInputChange);
        };
    }, []);

    return (
        <div className="title-search">
            <div className="title-search__title-wrapper">
                <h1>{title}</h1>
                <p>{subtitle}</p>
            </div>
            <label htmlFor="search">
                {isInputEmpty && (
                    <>
                        <span>
                            {" "}
                            <img src={searchIcon} alt="search icon" /> Search
                        </span>
                    </>
                )}
                <input ref={inputRef} type="search" id="search" name="search" />
            </label>
        </div>
    );
}

export default PageTitleSearch;
