import { useState } from "react";
import {
    MDBBtn,
    MDBModal,
    MDBModalDialog,
    MDBModalContent,
    MDBModalHeader,
    MDBModalTitle,
    MDBModalBody,
    MDBModalFooter,
} from "mdb-react-ui-kit";
import { machineActions } from "../store/actions/machine.action";
import image1 from "../assets/icons/machines-img1.svg";
import image2 from "../assets/icons/machines-img2.svg";
import image3 from "../assets/icons/machines-img3.svg";
import Excavator from "../assets/icons/Excavator.png";
import SteerLoader from "../assets/icons/SteerLoader.png";
import SingleManLift from "../assets/icons/SingleManLift.png";
import { useDispatch, useSelector } from "react-redux";

const MachinepopUp = (props) => {
    const dispatch = useDispatch();
    const [machinePopUp, setMachinePopUp] = useState(true);
    const moveToListTimesheet = (ltm_url) => {
        window.location.assign(ltm_url);
    };
    const machineId = props.data.id;
    const machineMake = props.data.make;
    const machineName = props.data.name;
    const machineType = props.data.machine_type;
    const machineSubType = props.data.machine_sub_type;
    const machineAge = props.data.machine_age;
    const machineYear = props.data.year;
    const machineModel = props.data.model;
    const machineDescription = props.data.discription;
    const imeiNumber = props.data.imei_no;
    const vehicle_code = props.data.vehicle_code;
    const contractorCompany = props.data.contractor_company;
    const toggle = () => {
        // setMachinePopUp(false);
        props.hideMachinePopUp(machinePopUp);
        props.hidepopup(false);
    };

    const delete_code = useSelector(
        (state) => state.DeleteMachineDataById.delete_code
    );
    const deleteMachineLoading = useSelector(
        (state) => state.DeleteMachineDataById.data_loading
    );

    const handleMachineDelete = (id) => {
        if (id) {
            dispatch(machineActions.deleteMachineData(id));
            setTimeout(() => {
                props.hideMachinePopUp(machinePopUp, true);
            }, 3000);

            // window.location.assign("/machines");
        }
    };
    return (
        <MDBModal show={machinePopUp} setShow={machinePopUp}>
            <MDBModalDialog size="lg">
                <MDBModalContent>
                    <MDBModalHeader>
                        <MDBModalTitle className="wdth-94">
                            <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 ">
                                <h4 className="txt-alg-cntr p-0 m-0">
                                    Machine detail
                                </h4>
                            </div>
                        </MDBModalTitle>

                        <MDBBtn
                            className="btn-close"
                            color="none"
                            onClick={toggle}
                        ></MDBBtn>
                    </MDBModalHeader>
                    <MDBModalBody>
                        <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 mt15  d-flex justify-content-center row">
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Machine type</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {machineType ? machineType : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Machine subtype</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {machineSubType ? machineSubType : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Machine year</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {machineYear ? machineYear : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 ">
                                <h5 className="m-l-16px">Make</h5>
                                <p className=" mr-t-10 clr-gray m-l-16px">
                                    {machineMake ? machineMake : `N/A`}
                                </p>
                            </div>

                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Machine age</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {machineAge ? machineAge + " Years" : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Machine model</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {machineModel ? machineModel : `N/A`}
                                </p>
                            </div>

                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">IMEI number</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {imeiNumber ? imeiNumber : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Vehicle code</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {vehicle_code ? vehicle_code : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Contractor company</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {contractorCompany
                                        ? contractorCompany
                                        : `N/A`}
                                </p>
                            </div>

                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Machine description
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {machineDescription
                                        ? machineDescription
                                        : `N/A`}
                                </p>
                            </div>
                            {/* <div className="machine-modal__img-wrapper d-flex mx-auto">
                                <img
                                    src={Excavator}
                                    alt="icon"
                                    className="width-180 d-flex mx-auto"
                                />
                                <img
                                    src={SingleManLift}
                                    alt="icon"
                                    className="width-180 d-flex mx-auto"
                                />
                                <img
                                    src={SteerLoader}
                                    alt="icon"
                                    className="width-180 d-flex mx-auto"
                                />
                            </div> */}
                        </div>
                        {/* <div className=" col-sm-11 col-lg-11 col-xs-11 col-md-11 d-flex mx-auto machine-model">
                            {machineDiscription}
                        </div> */}
                    </MDBModalBody>

                    {/* <MDBModalFooter> */}
                    {/* <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 "> */}
                    {/* <div className="col-sm-2 col-lg-2 col-xs-2 col-md-2 p-0 m-0 close-btn3 d-flex mx-auto"> */}
                    {/* <div className="close-btn3 flt-right">
                                <MDBBtn
                                    className="close-btn2 "
                                    onClick={toggle}
                                >
                                    Close
                                </MDBBtn>
                            </div> */}
                    {/* </div> */}
                    {/* <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 p-0 m-0 close-btn3 mx-auto">
                                <MDBBtn
                                    className="edit-btn2"
                                    onClick={() => {
                                        moveToListTimesheet(
                                            `/add-machine/?id=${machineId}`
                                        );
                                    }}
                                >
                                    Edit
                                </MDBBtn>
                            </div>
                            <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 p-0 m-0 close-btn3 mx-auto">
                                <MDBBtn
                                    className="delete-btn2"
                                    onClick={() => {
                                        handleMachineDelete(machineId);
                                    }}
                                >
                                    {deleteMachineLoading && (
                                        <span className="fa fa-spinner fa-spin"></span>
                                    )}
                                    Delete
                                </MDBBtn>
                            </div> */}
                    {/* </div>
                    </MDBModalFooter> */}
                </MDBModalContent>
            </MDBModalDialog>
        </MDBModal>
    );
};

export default MachinepopUp;
