import { useState } from "react";
import {
    MDBBtn,
    MDBModal,
    MDBModalDialog,
    MDBModalContent,
    MDBModalHeader,
    MDBModalTitle,
    MDBModalBody,
    MDBModalFooter,
} from "mdb-react-ui-kit";

const ClarificationPopUp = (props) => {
    const [isPopUp, setIsPopUp] = useState(true);

    const toggle = () => {
        setIsPopUp(false);
        props.hideClarificationPopUp(isPopUp);
    };
    return(
        <MDBModal show={isPopUp} setShow={setIsPopUp}>
            <MDBModalDialog size="xl">
                <MDBModalContent>
                    <MDBModalHeader>
                        <MDBModalTitle className="justify-content-center">
                            Question to clarify
                        </MDBModalTitle>
                        <MDBBtn
                            className="btn-close"
                            color="none"
                            onClick={toggle}
                        ></MDBBtn>
                    </MDBModalHeader>
                    <MDBModalBody>
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 m-0 p-0 mb-2 ">
                            <label className="fnt-25">Title :</label>
                        </div>
                        <h5> {props.title}</h5>
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 m-0 p-0 mt-4 ">
                            <label className="fnt-25">Question :</label>
                        </div>
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 m-0 p-0 mt-2 ">
                        <textarea className="question-box" placeholder="Enter your question"/>

                        </div>
                    </MDBModalBody>

                    <MDBModalFooter>
                        <MDBBtn className="send-btn">
                            Send
                        </MDBBtn>
                    </MDBModalFooter>
                </MDBModalContent>
            </MDBModalDialog>
        </MDBModal>
    )

}
export default ClarificationPopUp;

