import React, { useState, useEffect } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { machineActions } from "../store/actions/machine.action";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";

function DocumentPopUp(props) {
    const [documentPopUp, setDocumentPopUp] = useState(true);
    const auditsData = [
        { id: 1, what: "Mark", when: "Otto", who: "@mdo" },
        { id: 2, what: "David", when: "Ritt", who: "@ghs" },
        { id: 3, what: "Bob", when: "Dro", who: "@fzr" },
    ];

    const handleClose = () => {
        props.hideDocPopUp(false);
        setDocumentPopUp(false);
    };
    useEffect(() => {
        setDocumentPopUp(props.ppmodal);
    }, []);

    return (
        <>
            <Modal show={documentPopUp} onHide={handleClose} size="lg">
                <Modal.Header closeButton>
                    <Modal.Title className="wdth-94">
                        <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 ">
                            <h4 className="txt-alg-cntr p-0 m-0">
                                Finance Details
                            </h4>
                        </div>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row">
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mt16 row  ">
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Supplier Code</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {props.data.supplier_code
                                        ? props.data.supplier_code
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Type</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {props.data.document_type
                                        ? props.data.document_type
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Number</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {props.data.document_no
                                        ? props.data.document_no
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 ">
                                <h5 className="m-l-16px">Date</h5>
                                <p className=" mr-t-10 clr-gray m-l-16px">
                                    {props.data.invoice_date
                                        ? moment(
                                              props.data.invoice_date
                                          ).format("DD.MM.YYYY hh.mm A")
                                        : `N/A`}
                                </p>
                            </div>

                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Due Date</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {props.data.invoice_due
                                        ? moment(props.data.invoice_due).format(
                                              "DD.MM.YYYY hh.mm A"
                                          )
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Original Value</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {props.data.org_value
                                        ? props.data.org_value
                                        : `N/A`}
                                </p>
                            </div>

                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Adjustments</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {props.data.total_adjustment
                                        ? props.data.total_adjustment
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Transaction Type</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {props.data.transaction
                                        ? props.data.transaction
                                        : `N/A`}
                                </p>
                            </div>

                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">Linked Document</h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {props.data.document_type
                                        ? props.data.document_type
                                        : `N/A`}
                                </p>
                            </div>
                            <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                <h5 className="m-l-16px">
                                    Linked Document Number
                                </h5>
                                <p className="mr-t-10 clr-gray m-l-16px">
                                    {props.data.linked_doc_no
                                        ? props.data.linked_doc_no
                                        : `N/A`}
                                </p>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>
        </>
    );
}

export default DocumentPopUp;
