import { Dialog, Transition } from "@headlessui/react";
import { XMarkIcon } from "@heroicons/react/20/solid";
import { Dispatch, Fragment, SetStateAction, useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  MDBBtn,
} from "mdb-react-ui-kit";
import { timesheetActions } from "../../store/actions/timeSheet.actions";

export function Modal({ open, setOpen,timesheet_data }) {
  const dispatch = useDispatch();
  const TimesheetData = timesheet_data ? timesheet_data :null
  const [userRole, setUserRole] = useState(null);

  const audit_or_approved = useSelector(
      (state) => state.AuditOrApproveSheet.audit_or_approve
  );
  const audit_or_approved_loading = useSelector(
      (state) => state.AuditOrApproveSheet.audit_or_approve_loading
  );
  const timesheet_loading = useSelector(
      (state) => state.timesheet.timesheet_loading
  );
  const [isApproved, setIsApproved] = useState(false);
  const [isCancel, setIsCancel] = useState(false);
  const [showMsgBox, setShowMsgBox] = useState(false);
  const [msgCount, setMsgCount] = useState(1);
  const [sheetMessqage, setSheetMessage] = useState(null);
  const [validationMessages, setValidationMessages] = useState([]);
  const [alertMsg, setAlertMsg] = useState(false);

  const submit = (status) => {
    let auditable = false;
    let approved = true;
    if (status === "Audit") {
        auditable = true;
        approved = false;
    }

    if (status === "Approved") {
        auditable = false;
        approved = true;
    }

    let dataDict = {
        sheet_id: TimesheetData.id,
        is_auditable: auditable,
        is_approved: approved,
        messages: sheetMessqage,
    };

    let messages = [];

    if (!sheetMessqage && status === "Audit") {
        messages.push("Message is required");
    }

    if (messages.length > 0) {
        const error_violation = document.getElementById("msg_div");
        window.scrollTo({
            top: error_violation.offsetTop,
            behavior: "smooth",
        });
        setValidationMessages(messages);
    } else {
        setAlertMsg(true);
        setValidationMessages([]);
        setMsgCount(1);
        setShowMsgBox(false);
        setValidationMessages([]);
        dispatch(timesheetActions.timesheetApprovedOrAudit(dataDict));
    }
};

  useEffect(() => {
    
    setUserRole(
        localStorage.getItem("user_role")
            ? localStorage.getItem("user_role")
            : null
    );
}, []);

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog as="div" className="relative z-10" onClose={setOpen}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
        </Transition.Child>

        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="relative w-full max-w-xl transform overflow-hidden rounded-lg bg-white p-6 text-left shadow-xl transition-all">
                {/* <form> */}
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center justify-between pb-4">
                        <h2 className="text-lg font-semibold leading-7 text-gray-900">
                          Timesheet Details
                        </h2>
                        <button type="button" onClick={() => setOpen(false)}>
                          <XMarkIcon className="h-5 w-5" />
                        </button>
                      </div>

                      <hr className="-mx-6" />

                      <div className="mt-4 grid grid-cols-1 gap-x-6 gap-y-3 sm:grid-cols-6">
                        <div className="sm:col-span-3">
                          <label
                            htmlFor="machine"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Machine
                          </label>
                          <div className="mt-2">
                            <input
                              type="text"
                              value={TimesheetData ? TimesheetData.machine : `N/H`}
                              name="machine"
                              id="machine"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="Water Ranker"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="foreman"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Foreman
                          </label>
                          <div className="mt-2">
                            <input
                              value={TimesheetData ? TimesheetData.foreman : `N/H`}

                              type="text"
                              name="foreman"
                              id="foreman"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="Foreman"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="invoice-number"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Invoice Number
                          </label>
                          <div className="mt-2">
                            <input
                              value={TimesheetData ? TimesheetData.invoice : `N/H`}

                              type="text"
                              name="invoice-number"
                              id="invoice-number"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="IN12121"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="purchase-order-number"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Purchase Order Number
                          </label>
                          <div className="mt-2">
                            <input
                              value={TimesheetData ? TimesheetData.po : `N/H`}

                              type="text"
                              name="purchase-number-order"
                              id="purchase-number-order"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="DW0256"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="status"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Status
                          </label>
                          <div className="mt-2">
                          <input
                           className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              type="text"
                          value = {TimesheetData ? TimesheetData.is_approved === false &&
                            TimesheetData.is_auditable === false
                                      ? `Pending`
                                      : TimesheetData.is_approved === true &&
                                      TimesheetData.is_auditable === false
                                      ? `Approved`
                                      : `Clarification Requested`:`N/A`}
                                      />
                            {/* <select
                              value={TimesheetData ? TimesheetData.machine : `N/H`}

                              name="status"
                              id="status"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                            > */}
                              {/* <option>Approved</option>
                              <option>Clarification Requested</option>
                              <option>Pending</option> */}
                            {/* </select> */}
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="order-number"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Order Number
                          </label>
                          <div className="mt-2">
                            <input
                              type="text"
                              value={TimesheetData ? TimesheetData.order_number : `N/H`}

                              name="order-number"
                              id="order-number"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="456"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="cost-center"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Cost Center
                          </label>
                          <div className="mt-2">
                            <input
                              value={TimesheetData ? TimesheetData.cost_center : `N/H`}

                              type="text"
                              name="cost-center"
                              id="cost-center"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="456"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="total-hours"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Total Hours
                          </label>
                          <div className="mt-2">
                            <input
                              value={TimesheetData ? TimesheetData.total_hours : `N/H`}

                              type="text"
                              name="total-hours"
                              id="total-hours"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="14"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="days-per-month"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Days Per Month
                          </label>
                          <div className="mt-2">
                            <input
                              type="text"
                              value={TimesheetData ? TimesheetData.days_per_month : `N/H`}

                              name="days-per-month"
                              id="days-per-month"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="31"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="per-day"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Per Day
                          </label>
                          <div className="mt-2">
                            <input
                              type="text"
                              value={TimesheetData ? TimesheetData.per_day : `N/H`}

                              name="per-day"
                              id="per-day"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="0.45"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="total-day"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Total Day
                          </label>
                          <div className="mt-2">
                            <input
                              type="text"
                              value={TimesheetData ? TimesheetData.days_per_month : `N/H`}

                              name="total-day"
                              id="total-day"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="14"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="name"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Name
                          </label>
                          <div className="mt-2">
                            <input
                              value={TimesheetData ? TimesheetData.manager_name : `N/H`}

                              type="text"
                              name="name"
                              id="name"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="Manager"
                            />
                          </div>
                        </div>

                        <div className="sm:col-span-3">
                          <label
                            htmlFor="signature"
                            className="block text-sm leading-6 text-gray-700"
                          >
                            Signature
                          </label>
                          <div className="mt-2">
                            <input
                              type="text"
                              value={TimesheetData ? TimesheetData.manager_name : `N/H`}

                              name="signature"
                              id="signature"
                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                              placeholder="Signature"
                            />
                          </div>
                        </div>

                        {showMsgBox && (
                                      <div className="sm:col-span-3">
                                        <label
                                          htmlFor="signature"
                                          className="block text-sm leading-6 text-gray-700"
                                        >
                                          Message
                                        </label>
                                        <div className="mt-2">
                                        <textarea
                          rows={3}
                          name="description"
                          id="description"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          placeholder="Type here..."
                          onChange={(e) =>
                            setSheetMessage(
                                e.target.value
                            )
                        }
                        ></textarea>
                                        </div>
                                      </div>
                                    )}

                        <div></div>
                      </div>
                    </div>
                  </div>

                  {/* <button
                    type="button"
                    className="focus-visible:outline-bg-[#FCAF17] mt-6 inline-flex w-full justify-center rounded-md bg-[#FCAF17] px-3 py-2 text-sm font-semibold text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2"
                    onClick={() => setOpen(false)}
                  >
                    Save
                  </button> */}
                  <div
                                        className="clr-red col-sm-12 col-lg-12 col-xs-12 col-md-12 d-flex justify-content-center mt-20"
                                        id="msg_div"
                                    >
                                        <ul>
                                            {validationMessages.map((vm) => (
                                                <li key={vm}>{vm}</li>
                                            ))}
                                        </ul>
                                    </div>
                  {alertMsg === true &&
                                        audit_or_approved === true &&
                                        isCancel === false &&
                                        audit_or_approved_loading === false &&
                                        isApproved === true && (
                                            <div>
                                                <p className="success-msg ">
                                                    Timesheet Approved
                                                    Successfully
                                                </p>
                                            </div>
                                        )}

                                    {alertMsg === true &&
                                        isCancel === true &&
                                        audit_or_approved === true &&
                                        audit_or_approved_loading === false &&
                                        isApproved === false && (
                                            <div>
                                                <p className="warn-msg">
                                                    Clarification Requested
                                                </p>
                                            </div>
                                        )}
                                        
                  <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12   row mt-20">
                    
                                        <div className="col-sm-12 col-lg-2 col-xs-12 col-md-2">
                                          </div>
                                        <div className="col-sm-12 col-lg-9 col-xs-12 col-md-9  row">
                                            {userRole &&
                                            userRole === "Approver" ? (
                                                <>
                                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 d-flex mx-auto">
                                                        {TimesheetData &&
                                                        TimesheetData.is_approved === false ? (
                                                            <MDBBtn
                                                                onClick={
                                                                    () => (
                                                                        setShowMsgBox(
                                                                            true
                                                                        ),
                                                                        setMsgCount(
                                                                            2
                                                                        ),
                                                                        setIsCancel(
                                                                            true
                                                                        ),
                                                                        msgCount ===
                                                                            2 &&
                                                                            submit(
                                                                                "Audit"
                                                                            ),
                                                                        setIsApproved(
                                                                            false
                                                                        )
                                                                    )
                                                                    // submit("Audit"),
                                                                    // setIsApproved(false)
                                                                }
                                                                className={
                                                                    "audit-and-approve-btn"
                                                                }
                                                            >
                                                                {audit_or_approved_loading && (
                                                                    <span className="fa fa-spinner fa-spin"></span>
                                                                )}
                                                                {timesheet_loading && (
                                                                    <span className="fa fa-spinner fa-spin"></span>
                                                                )}{" "}
                                                                Request
                                                                Clarification
                                                            </MDBBtn>
                                                        ) : null}
                                                    </div>
                                                    <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 d-flex mx-auto">
                                                        {TimesheetData && TimesheetData.is_approved
                                                         === false ? (
                                                            <MDBBtn
                                                                onClick={() => (
                                                                    setIsCancel(
                                                                        false
                                                                    ),
                                                                    setShowMsgBox(
                                                                        false
                                                                    ),
                                                                    submit(
                                                                        "Approve"
                                                                    ),
                                                                    setMsgCount(
                                                                        1
                                                                    ),
                                                                    setIsApproved(
                                                                        true
                                                                    ),
                                                                    setSheetMessage(
                                                                        null
                                                                    )
                                                                )}
                                                                className={
                                                                    "audit-and-approve-btn"
                                                                }
                                                            >
                                                                {audit_or_approved_loading && (
                                                                    <span className="fa fa-spinner fa-spin"></span>
                                                                )}
                                                                {timesheet_loading && (
                                                                    <span className="fa fa-spinner fa-spin"></span>
                                                                )}{" "}
                                                                Approve
                                                            </MDBBtn>
                                                        ) : null}
                                                    </div>
                                                </>
                                            ) : null}
                                        </div>
                                    </div>
                {/* </form> */}
              </Dialog.Panel>
            </Transition.Child>

            
          </div>
          
        </div>
        
      </Dialog>
    </Transition.Root>
  );
}
