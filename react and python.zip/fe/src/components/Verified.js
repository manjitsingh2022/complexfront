// import verifiedIcon from "../assets/images/verify.gif";
// import { MDBBtn } from "mdb-react-ui-kit";
// // import ClarificationPopUp from "./ClarificationPopUp";
// // import { useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { timesheetActions } from "../store/actions/timeSheet.actions";
// import { Viewer } from "@react-pdf-viewer/core";
// // import { defaultLayoutPlugin } from '@react-pdf-viewer/default-layout';
// import { Worker } from "@react-pdf-viewer/core";

// import "@react-pdf-viewer/core/lib/styles/index.css";

// function VarifiedFile(props) {
//     const dispatch = useDispatch();

//     const file_Type = useSelector(
//         (state) => state.Base64toJsonata.data.file_Type
//     );
//     const base64_data = useSelector(
//         (state) => state.Base64toJsonata.data.file_data
//     );
//     const file_to_show = useSelector(
//         (state) => state.Base64toJsonata.data.file_to_show
//     );

//     const file_name = useSelector(
//         (state) => state.Base64toJsonata.data.file_name
//     );
//     const file_code = useSelector((state) => state.SaveFileResults.code);

//     const handleSaveFileData = () => {
//         let data_dict = { file_data: base64_data, file_name: file_name };
//         dispatch(timesheetActions.SaveFileResults(data_dict));
//     };

//     return (
//         <>
//             <div className="verified__container">
//                 {file_code === 200 && (
//                     <div>
//                         <img
//                             className="d-flex mx-auto"
//                             src={verifiedIcon}
//                             alt="verified"
//                         />
//                         <h5 className="verified__title">Saved</h5>
//                         <p className="verified__text">
//                             Documents have been uploaded successfully
//                         </p>
//                     </div>
//                 )}
//             </div>
//             {file_code !== 200 && (
//                 <>
//                     <div className="col-sm-8 col-lg-8 col-xs-8 col-md-8 row d-flex mx-auto">
//                         <div className="col-sm-5 col-lg-5 col-xs-5 col-md-5 row border-box d-flex mx-auto ">
//                             {file_Type === "application/pdf" ? (
//                                 <h3>PDF</h3>
//                             ) : (
//                                 <h3>Image</h3>
//                             )}

//                             {file_Type === "application/pdf" ? (
//                                 <Worker
//                                     className="height-400"
//                                     workerUrl="https://unpkg.com/pdfjs-dist@3.3.122/build/pdf.worker.min.js"
//                                 >
//                                     <Viewer fileUrl={file_to_show} />
//                                 </Worker>
//                             ) : (
//                                 <img src={file_to_show} alt="preview image" />
//                             )}
//                         </div>
//                         <div className="col-sm-5 col-lg-5 col-xs-5 col-md-5 row border-box d-flex mx-auto ">
//                             <h3>Raw data</h3>
//                             <div>
//                                 <pre className="height-400">
//                                     {JSON.stringify(base64_data, null, 2)}
//                                 </pre>
//                             </div>
//                         </div>
//                     </div>
//                     <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 row d-flex mx-auto mb-5">
//                         <MDBBtn
//                             className="upload-btns"
//                             onClick={handleSaveFileData}
//                         >
//                             Save
//                         </MDBBtn>
//                     </div>
//                 </>
//             )}
//         </>
//     );
// }

// export default VarifiedFile;
