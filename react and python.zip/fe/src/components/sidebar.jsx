import { Disclosure } from "@headlessui/react";
import {
  ChevronDoubleLeftIcon,
  ChevronDoubleRightIcon,
  ChevronDownIcon,
} from "@heroicons/react/20/solid";
import { EyeIcon, PlusCircleIcon } from "@heroicons/react/24/outline";
import clsx from "clsx";
import { useEffect, useState } from "react";
import Avatar from "../assets/images/avatar.png";
import { useWindowSize } from "../hooks/useWindowSize";

export function Sidebar() {
  const size = useWindowSize();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  useEffect(() => {
    if (size.width && size.width < 1080) setSidebarOpen(false);
  }, [size]);
  return (
    <div
      className={clsx(
        sidebarOpen ? "w-72 min-w-[18rem]" : "w-[4.5rem] min-w-[4.5rem]",
        "flex h-screen grow flex-col gap-y-5 overflow-y-auto border-r border-gray-200 bg-white transition-all duration-300"
      )}
    >
      <div className="flex h-16 shrink-0 items-center pb-6 pt-12">
        {sidebarOpen ? (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width={91}
            height={50}
            fill="none"
            className="mx-auto"
          >
            <g clipPath="url(#a)">
              <path
                fill="#FCAF17"
                d="m44.489.054-16.923 24.57h6.705L44.49 9.784V.055Zm8.994 24.57 9.95-14.463V.431L46.778 24.623h6.706Zm-9.473 0 9.951-14.463V.431L37.305 24.623h6.705Z"
              />
              <path
                fill="#000"
                d="M90.415 24.624 73.492 0 56.516 24.624h33.899ZM42.84 42.85V49.3h4.842v.753h-6.014v-7.205h1.171ZM50.502 42.85v7.204h-1.224v-7.205h1.224ZM52.418 50.054v-7.205h1.543l3.406 6.022 3.353-6.022h1.437v7.205h-1.065v-5.807l-3.3 5.807h-.957l-3.353-5.807v5.807h-1.064ZM65.296 42.85v7.204h-1.224v-7.205h1.224ZM73.279 42.85v.752h-2.927v6.452h-1.17v-6.452h-2.928v-.752h7.025ZM80.303 42.85v.752h-4.842v2.42h4.63v.752h-4.63v2.527h4.949v.753h-6.173v-7.205h6.067ZM82.166 50.054v-7.205h3.778c2.874 0 4.311 1.13 4.311 3.388 0 2.526-1.437 3.817-4.31 3.817h-3.779Zm3.512-.753c2.289 0 3.406-1.021 3.406-3.064 0-1.775-1.117-2.635-3.406-2.635H83.39v5.7h2.288ZM.053 38.925v-10.27h5.641c4.098 0 6.12 1.614 6.12 4.84 0 3.602-2.022 5.43-6.12 5.43H.054Zm5.322-1.667c2.714 0 4.044-1.236 4.044-3.763 0-2.15-1.33-3.226-4.044-3.226H2.5v6.989h2.874ZM14.102 38.925v-10.27h5.907c2.661 0 3.992.915 3.992 2.743 0 1.236-1.012 2.258-3.087 3.064l4.15 4.463h-3.139l-3.938-4.516v-.86c2.395-.323 3.566-1.022 3.566-2.097 0-.753-.533-1.13-1.65-1.13h-3.3v8.603h-2.5ZM26.661 38.925v-10.27h5.641c4.098 0 6.12 1.614 6.12 4.84 0 3.602-2.022 5.43-6.12 5.43h-5.64Zm5.322-1.667c2.714 0 4.045-1.236 4.045-3.763 0-2.15-1.331-3.226-4.045-3.226h-2.874v6.989h2.874Z"
              />
              <path
                fill="#FCAF17"
                d="M51.14 38.44c-1.063.377-2.394.538-3.937.538-4.63 0-6.918-1.774-6.918-5.376 0-3.387 2.341-5.054 7.024-5.054 1.437 0 2.714.162 3.832.484v1.72a11.44 11.44 0 0 0-3.672-.59c-3.14 0-4.683 1.128-4.683 3.44 0 2.473 1.49 3.71 4.417 3.71.426 0 .958-.054 1.49-.161V34.14h2.395v4.3h.053ZM52.95 33.763c0-3.494 2.182-5.215 6.546-5.215 4.31 0 6.44 1.72 6.44 5.215 0 3.441-2.13 5.215-6.44 5.215-4.15 0-6.333-1.72-6.546-5.215Zm6.546 3.549c2.607 0 3.938-1.183 3.938-3.602 0-2.366-1.33-3.549-3.938-3.549-2.714 0-4.044 1.183-4.044 3.549 0 2.419 1.383 3.602 4.044 3.602ZM70.671 28.656v8.656h6.12v1.666h-8.514V28.656h2.394ZM79.08 38.925v-10.27h5.64c4.098 0 6.12 1.614 6.12 4.84 0 3.602-2.022 5.43-6.12 5.43h-5.64Zm5.268-1.667c2.714 0 4.044-1.236 4.044-3.763 0-2.15-1.33-3.226-4.044-3.226h-2.874v6.989h2.874Z"
              />
            </g>
            <defs>
              <clipPath id="a">
                <path fill="#fff" d="M0 0h91v50H0z" />
              </clipPath>
            </defs>
          </svg>
        ) : (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width={80}
            height={80}
            fill="none"
            className="absolute left-0"
          >
            <path
              fill="#FCAF17"
              d="M24.964 28.052 8 52h6.721l10.243-14.463v-9.485ZM33.979 52l9.975-14.096v-9.485L27.257 52h6.722Zm-9.495 0 9.975-14.096v-9.485L17.762 52h6.721Z"
            />
            <path fill="#000" d="M71 52 54.036 28 37.02 52H71Z" />
          </svg>
        )}
      </div>
      <button
        type="button"
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="my-6 px-6"
      >
        {sidebarOpen ? (
          <ChevronDoubleLeftIcon className="ml-auto h-5 w-5 text-gray-400" />
        ) : (
          <ChevronDoubleRightIcon className="ml-auto h-5 w-5 text-gray-400" />
        )}
      </button>
      <nav className="flex flex-1 flex-col">
        <ul role="list" className="flex flex-1 flex-col gap-y-7">
          <li>
            <ul role="list" className="-mx-2 space-y-1">
              <li>
                <a
                  href="#"
                  className={clsx(
                    false
                      ? "bg-[#FCAF17] text-white"
                      : "text-gray-500 hover:bg-gray-50",
                    sidebarOpen ? "gap-x-3 px-6" : "justify-center",
                    "group mx-auto flex rounded-md py-2 text-sm font-semibold leading-6"
                  )}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={24}
                    height={24}
                    fill="none"
                    className="h-6 w-6 shrink-0 text-gray-500"
                  >
                    <path
                      fill="currentColor"
                      d="M22 8.52V3.98C22 2.57 21.36 2 19.77 2h-4.04c-1.59 0-2.23.57-2.23 1.98v4.53c0 1.42.64 1.98 2.23 1.98h4.04c1.59.01 2.23-.56 2.23-1.97ZM22 19.77v-4.04c0-1.59-.64-2.23-2.23-2.23h-4.04c-1.59 0-2.23.64-2.23 2.23v4.04c0 1.59.64 2.23 2.23 2.23h4.04c1.59 0 2.23-.64 2.23-2.23ZM10.5 8.52V3.98C10.5 2.57 9.86 2 8.27 2H4.23C2.64 2 2 2.57 2 3.98v4.53c0 1.42.64 1.98 2.23 1.98h4.04c1.59.01 2.23-.56 2.23-1.97ZM10.5 19.77v-4.04c0-1.59-.64-2.23-2.23-2.23H4.23c-1.59 0-2.23.64-2.23 2.23v4.04C2 21.36 2.64 22 4.23 22h4.04c1.59 0 2.23-.64 2.23-2.23Z"
                    />
                  </svg>
                  {sidebarOpen && "Dashboard"}
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className={clsx(
                    false
                      ? "bg-[#FCAF17] text-white"
                      : "text-gray-500 hover:bg-gray-50",
                    sidebarOpen ? "gap-x-3 px-6" : "justify-center",
                    "group flex rounded-md p-2 text-sm font-semibold leading-6"
                  )}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={24}
                    height={24}
                    fill="none"
                    className="h-6 w-6 shrink-0 text-gray-500"
                  >
                    <path
                      fill="currentColor"
                      d="M8 18h8v-2H8v2Zm0-4h8v-2H8v2Zm-2 8c-.55 0-1.02-.196-1.412-.587A1.926 1.926 0 0 1 4 20V4c0-.55.196-1.02.588-1.413A1.926 1.926 0 0 1 6 2h8l6 6v12c0 .55-.196 1.02-.587 1.413A1.926 1.926 0 0 1 18 22H6Zm7-13V4H6v16h12V9h-5Z"
                    />
                  </svg>
                  {sidebarOpen && "Finance Data"}
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className={clsx(
                    false
                      ? "bg-[#FCAF17] text-white"
                      : "text-gray-500 hover:bg-gray-50",
                    sidebarOpen ? "gap-x-3 px-6" : "justify-center",
                    "group mx-auto flex rounded-md py-2 text-sm font-semibold leading-6"
                  )}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={24}
                    height={24}
                    fill="none"
                    className="h-6 w-6 shrink-0 text-gray-500"
                  >
                    <path
                      fill="currentColor"
                      d="M8 9c.283 0 .52-.096.713-.287A.968.968 0 0 0 9 8a.968.968 0 0 0-.287-.713A.968.968 0 0 0 8 7a.968.968 0 0 0-.713.287A.968.968 0 0 0 7 8c0 .283.096.52.287.713.192.191.43.287.713.287Zm0 4c.283 0 .52-.096.713-.287A.968.968 0 0 0 9 12a.968.968 0 0 0-.287-.713A.967.967 0 0 0 8 11a.967.967 0 0 0-.713.287A.968.968 0 0 0 7 12c0 .283.096.52.287.713.192.191.43.287.713.287Zm0 4c.283 0 .52-.096.713-.288A.968.968 0 0 0 9 16a.968.968 0 0 0-.287-.713A.967.967 0 0 0 8 15a.967.967 0 0 0-.713.287A.968.968 0 0 0 7 16c0 .283.096.52.287.712.192.192.43.288.713.288Zm-3 4c-.55 0-1.02-.196-1.413-.587A1.926 1.926 0 0 1 3 19V5c0-.55.196-1.02.587-1.413A1.926 1.926 0 0 1 5 3h11l5 5v11c0 .55-.196 1.02-.587 1.413A1.926 1.926 0 0 1 19 21H5Zm0-2h14V9h-4V5H5v14Z"
                    />
                  </svg>
                  {sidebarOpen && "Report"}
                </a>
              </li>
              <li>
                <Disclosure as="div">
                  {({ open }) => (
                    <>
                      <Disclosure.Button
                        className={clsx(
                          true
                            ? "bg-[#FCAF17] text-white"
                            : "text-gray-500 hover:bg-gray-50",
                          sidebarOpen ? "gap-x-3 px-6" : "justify-center",
                          "flex w-full items-center rounded-md p-2 text-left text-sm font-semibold leading-6"
                        )}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width={24}
                          height={24}
                          fill="none"
                          className="h-6 w-6 shrink-0 text-white"
                        >
                          <path
                            fill="currentColor"
                            d="m15.35 16.25 1.275-1.275L12.9 11.25V6h-1.8v6l4.25 4.25ZM12 21.6a9.346 9.346 0 0 1-3.73-.75 9.69 9.69 0 0 1-3.057-2.063 9.68 9.68 0 0 1-2.063-3.06 9.382 9.382 0 0 1-.75-3.738c0-1.326.25-2.572.75-3.739A9.53 9.53 0 0 1 5.213 5.2a9.786 9.786 0 0 1 3.061-2.05 9.382 9.382 0 0 1 3.738-.75c1.325 0 2.571.252 3.738.756a9.684 9.684 0 0 1 3.045 2.052 9.694 9.694 0 0 1 2.05 3.048A9.356 9.356 0 0 1 21.6 12c0 1.323-.25 2.566-.75 3.73a9.796 9.796 0 0 1-2.05 3.058 9.518 9.518 0 0 1-3.053 2.062c-1.17.5-2.418.75-3.747.75Zm.012-1.8c2.158 0 3.995-.762 5.512-2.288 1.517-1.524 2.276-3.366 2.276-5.524s-.759-3.995-2.276-5.512C16.007 4.959 14.17 4.2 12.012 4.2c-2.158 0-4 .759-5.524 2.276C4.963 7.993 4.2 9.83 4.2 11.988c0 2.158.763 4 2.288 5.524 1.525 1.526 3.366 2.288 5.524 2.288Z"
                          />
                        </svg>
                        {sidebarOpen && (
                          <>
                            Time Sheet
                            <ChevronDownIcon
                              className={clsx(
                                open && "rotate-180",
                                "ml-auto h-5 w-5 shrink-0 text-white"
                              )}
                              aria-hidden="true"
                            />
                          </>
                        )}
                      </Disclosure.Button>
                      {sidebarOpen && (
                        <Disclosure.Panel as="ul" className="mt-1">
                          <li>
                            {/* 44px */}
                            <Disclosure.Button
                              as="a"
                              href="#"
                              className={clsx(
                                false ? "bg-gray-50" : "hover:bg-gray-50",
                                "flex items-center space-x-3 rounded-md py-2 pl-[3.75rem] pr-2 text-sm leading-6 text-gray-500"
                              )}
                            >
                              <EyeIcon className="h-6 w-6" />
                              <span>View Timesheet</span>
                            </Disclosure.Button>
                            <Disclosure.Button
                              as="a"
                              href="#"
                              className={clsx(
                                false ? "bg-gray-50" : "hover:bg-gray-50",
                                "flex items-center space-x-3 rounded-md py-2 pl-[3.75rem] pr-2 text-sm leading-6 text-gray-500"
                              )}
                            >
                              <PlusCircleIcon className="h-6 w-6" />
                              <span>Add Timesheet</span>
                            </Disclosure.Button>
                          </li>
                        </Disclosure.Panel>
                      )}
                    </>
                  )}
                </Disclosure>
              </li>
              <li>
                <Disclosure as="div">
                  {({ open }) => (
                    <>
                      <Disclosure.Button
                        className={clsx(
                          false
                            ? "bg-[#FCAF17] text-white"
                            : "text-gray-500 hover:bg-gray-50",
                          sidebarOpen ? "gap-x-3 px-6" : "justify-center",
                          "flex w-full items-center rounded-md p-2 text-left text-sm font-semibold leading-6"
                        )}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width={24}
                          height={24}
                          fill="none"
                          className="h-6 w-6 shrink-0 text-gray-500"
                        >
                          <g
                            fill="currentColor"
                            fillRule="evenodd"
                            clipPath="url(#a)"
                            clipRule="evenodd"
                          >
                            <path d="M22.287 18.107H7.711c-.915 0-1.653.871-1.653 1.95v1.948c0 1.077.737 1.949 1.653 1.949h14.576c.912 0 1.652-.872 1.652-1.949v-1.948c0-1.079-.738-1.95-1.652-1.95Zm-11.818 4.55a1.685 1.685 0 0 1-1.673-1.696c0-.94.75-1.698 1.673-1.698.919 0 1.669.758 1.669 1.698s-.75 1.697-1.67 1.697Zm4.51-.016a1.617 1.617 0 0 1-1.614-1.62c0-.895.723-1.621 1.614-1.621.89 0 1.614.726 1.614 1.621 0 .896-.725 1.62-1.614 1.62Zm4.568.048c-.947 0-1.718-.742-1.718-1.662 0-.922.771-1.666 1.718-1.666.946 0 1.717.744 1.717 1.666 0 .92-.771 1.662-1.717 1.662ZM17.967 12.031l.032-3.02h-6.873l-1.25-3.146-.006-.018-.007.003-3.88-4.044.522-1.35L5.21-.048 1.822 9.377A3.552 3.552 0 0 0 .42 14.103c.9 1.719 3.454 2.889 5.16 1.973 1.321-.709-.78-5.108-2.384-6.404l2.233-6.429 3.244 3.383 1.921 6.877v1.494c0 2.41 1.546 1.416 1.546 1.416h9.047s1.266.585 1.266-1.51v-1.829c0-1.3-1.407-1.062-1.407-1.062l-3.078.02Zm-1.42 3.062h-4.642v-4.688h4.642v4.688Z" />
                          </g>
                          <defs>
                            <clipPath id="a">
                              <path fill="#fff" d="M0 0h24v24H0z" />
                            </clipPath>
                          </defs>
                        </svg>
                        {sidebarOpen && (
                          <>
                            Machines
                            <ChevronDownIcon
                              className={clsx(
                                open && "rotate-180",
                                "ml-auto h-5 w-5 shrink-0 text-gray-500"
                              )}
                              aria-hidden="true"
                            />
                          </>
                        )}
                      </Disclosure.Button>
                      {sidebarOpen && (
                        <Disclosure.Panel as="ul" className="mt-1">
                          <li>
                            {/* 44px */}
                            <Disclosure.Button
                              as="a"
                              href="#"
                              className={clsx(
                                false ? "bg-gray-50" : "hover:bg-gray-50",
                                "flex items-center space-x-3 rounded-md py-2 pl-[3.75rem] pr-2 text-sm leading-6 text-gray-500"
                              )}
                            >
                              <EyeIcon className="h-6 w-6" />
                              <span>View Machines</span>
                            </Disclosure.Button>
                            <Disclosure.Button
                              as="a"
                              href="#"
                              className={clsx(
                                false ? "bg-gray-50" : "hover:bg-gray-50",
                                "flex items-center space-x-3 rounded-md py-2 pl-[3.75rem] pr-2 text-sm leading-6 text-gray-500"
                              )}
                            >
                              <PlusCircleIcon className="h-6 w-6" />
                              <span>Add Machines</span>
                            </Disclosure.Button>
                          </li>
                        </Disclosure.Panel>
                      )}
                    </>
                  )}
                </Disclosure>
              </li>
              <li>
                <a
                  href="#"
                  className={clsx(
                    false
                      ? "bg-[#FCAF17] text-white"
                      : "text-gray-500 hover:bg-gray-50",
                    sidebarOpen ? "gap-x-3 px-6" : "justify-center",
                    "group mx-auto flex rounded-md py-2 text-sm font-semibold leading-6"
                  )}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width={24}
                    height={24}
                    fill="none"
                    className="h-6 w-6 shrink-0 text-gray-500"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M12 9.32c1.19 0 2.16-.97 2.16-2.16C14.16 5.97 13.19 5 12 5c-1.19 0-2.16.97-2.16 2.16 0 1.19.97 2.16 2.16 2.16ZM6.79 19c1.19 0 2.16-.97 2.16-2.16 0-1.19-.97-2.16-2.16-2.16-1.19 0-2.16.97-2.16 2.16 0 1.19.96 2.16 2.16 2.16ZM17.21 19c1.19 0 2.16-.97 2.16-2.16 0-1.19-.97-2.16-2.16-2.16-1.19 0-2.16.97-2.16 2.16 0 1.19.97 2.16 2.16 2.16Z"
                    />
                  </svg>
                  {sidebarOpen && "Anomalies"}
                </a>
              </li>
            </ul>
          </li>
          <li className="mt-auto border-t border-gray-200">
            <a
              href="#"
              className={clsx(
                sidebarOpen ? "gap-x-4 px-6" : "px-4",
                "flex items-center py-3 text-sm font-semibold leading-6 text-gray-900 hover:bg-gray-50"
              )}
            >
              <img
                className="rounded-full bg-gray-50"
                src={Avatar}
                alt="avatar"
              />
              <span className="sr-only">Your profile</span>
              {sidebarOpen && <span aria-hidden="true">Anil</span>}
            </a>
          </li>
        </ul>
      </nav>
    </div>
  );
}
