import { useRef, useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import React from "react";
import { timesheetActions } from "../store/actions/timeSheet.actions";
import SignaturePad from "react-signature-canvas";
import { Calendar, DateObject } from "react-multi-date-picker";
import { MDBContainer } from "mdbreact";
import { MDBTable, MDBTableHead, MDBTableBody, MDBBtn } from "mdb-react-ui-kit";
import NavBar from "./NavBar";
import Base64ToImage from "./base64ToImg";
import SideBar from "./SideBar";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import { userActions } from "../store/actions/user.actions";
import Select from "react-select";

const EditTimesheet = () => {
  const user_dt = useSelector((state) => state.users);
  const [isSubmittable, setIsSubmittable] = useState(true);
  const [timeSheetData, setTimesheetData] = useState([]);
  const selectedsheetid = window.location.href.split("id=")[1];
  const sheetData = useSelector((state) => state.SheetDataById.data);
  const daysData = useSelector((state) => state.SheetDataById.days_data);
  const vehicle_code_list2 = useSelector(
    (state) => state.OptionsList.vehicle_code_list
  );
  const machine_list2 = useSelector((state) => state.OptionsList.machine_list2);
  const po_list2 = useSelector((state) => state.OptionsList.po_list);
  const site_name_list2 = useSelector(
    (state) => state.OptionsList.site_name_list
  );
  const machine_sub_list2 = useSelector(
    (state) => state.OptionsList.machine_sub_list2
  );

  const data_saved = useSelector(
    (state) => state.updateTimesheetData.sheet_saved
  );

  const sheet_status_loading = useSelector(
    (state) => state.updateTimesheetData.sheet_status_loading
  );

  const [isDateDataset, setIsDateDataset] = useState(false);

  const [showSgnPad, setShowSgnPad] = useState(false);

  const rateList = [
    {
      key: "Wet",
      value: "Wet",
    },
    {
      key: "Dry",
      value: "Dry",
    },
  ];

  const periodList = [
    { key: "Day", value: "Day" },
    { key: "Night", value: "Night" },
    { key: "24 Hours", value: "24 hours" },
  ];

  const [hrsVal, setHrsVal] = useState(null);
  const [hrsDate, setHrsDate] = useState(null);

  const handlehourschange = (e, date) => {
    let val = e.target.value;
    if (!e.target.value) {
      val = 0;
    }
    if (e.target.value > 24) {
      val = 24;
    }
    if (e.target.value < 0) {
      val = 0;
    }

    if (!val || val.match(/^\d{1,}(\.\d{0,1})?$/)) {
      setHrsVal(val);
    }

    if (val.toString().length === 0) {
      val = null;
    }

    setTimeout(() => {
      handleTimeSheetChange(e.target.name, val, date);
    }, 1000);

    setHrsDate(date);
  };

  const MachineList = [
    "Articulated Dump Truck",
    "Hydraulic Excavator",
    "Excavator",
    "Dozer",
    "Front End Loader",
    "Grader",
    "Water Tanker",
    "Articulated Dump Truck - Water Tanker",
    "Long Reach Excavator",
  ];

  const [MachineListOptions, setMachineListoptions] = useState([]);
  const [MachineListSubListOptions, setMachineListSubListoptions] = useState(
    []
  );
  const [vehicleCodeOptions, setVehicleCodeOptions] = useState([]);

  const handleInputMachineChange = ({ target }) => {
    if (target.value) {
      const filteredOptions = machine_list2.filter((option) =>
        option.toLowerCase().startsWith(target.value.toLowerCase())
      );
      setMachineListoptions(filteredOptions);
    } else {
      setMachineListoptions(MachineListOptions);
    }
    setMachine(target.value);
    if (
      target.value === null ||
      target.value === undefined ||
      target.value.length === 0
    ) {
      setIsSubmittable(false);
    } else {
      setIsSubmittable(true);
    }
  };
  const handleInputMachineSubTypeChange = ({ target }) => {
    // if (target.value) {
    //   const filteredOptions = machine_sub_list2.filter((option) =>
    //     option.toLowerCase().startsWith(target.value.toLowerCase())
    //   );
    //   setMachineListSubListoptions(filteredOptions);
    // } else {
    //   setMachineListSubListoptions(MachineListSubListOptions);
    // }
    setMachineSubType(target.value);
    if (
      target.value === null ||
      target.value === undefined ||
      target.value.length === 0
    ) {
      setIsSubmittable(false);
    } else {
      setIsSubmittable(true);
    }
  };

  const handleInputVehicleCodeChange = (target) => {
    // if (target.value) {
    //   const filteredVCOptions = vehicle_code_list2.filter((option) =>
    //     option.toLowerCase().startsWith(target.value.toLowerCase())
    //   );
    //   setVehicleCodeOptions(filteredVCOptions);
    // } else {
    //   setVehicleCodeOptions(vehicleCodeOptions);
    // }
    setVehicleCode(target);
    if (target === null || target === undefined || target.length === 0) {
      setIsSubmittable(false);
    } else {
      setIsSubmittable(true);
    }
  };

  const handleInputSiteNameChange = (target) => {
    setSiteName(target);
    if (target === null || target === undefined || target.length === 0) {
      setIsSubmittable(false);
    } else {
      setIsSubmittable(true);
    }
  };

  const handleinvoiceChange = (target) => {
    setInvoice(target);
    // if (target === null || target === undefined || target.length === 0) {
    //   setIsSubmittable(false);
    // } else {
    //   setIsSubmittable(true);
    // }
  };
  const handleordernumberChange = (target) => {
    setOrderNumber(target);
    // if (target === null || target === undefined || target.length === 0) {
    //   setIsSubmittable(false);
    // } else {
    //   setIsSubmittable(true);
    // }
  };
  const handlecostcenterChange = (target) => {
    setCostCenter(target);
    if (target === null || target === undefined || target.length === 0) {
      setIsSubmittable(false);
    } else {
      setIsSubmittable(true);
    }
  };

  const handlemanagernameChange = (e) => {
    const { value } = e.target;
    const re = /^[A-Za-z]+$/;

    if (value === "" || re.test(value)) {
      setManagerName(value);
      if (value === null || value === undefined || value.length === 0) {
        setIsSubmittable(false);
      } else {
        setIsSubmittable(true);
      }
    } else if (re.test(value) === false) {
      const filteredValue = value.replace(/[0-9]/g, "");
      setManagerName(filteredValue);
      setIsSubmittable(true);
    }
    // setManagerName(target);
    // if (target === null || target === undefined || target.length === 0) {
    //   setIsSubmittable(false);
    // } else {
    //   setIsSubmittable(true);
    // }
  };

  const handleInputPOChange = (val) => {
    // if (target.value) {
    //   const filteredOptions = PoList.filter((option) =>
    //     option.toLowerCase().startsWith(target.value.toLowerCase())
    //   );
    //   setPoListOptions(filteredOptions);
    // } else {
    //   setPoListOptions(PoListOptions);
    // }
    setPo(val);
    if (val === null || val === undefined || val.length === 0) {
      setIsSubmittable(false);
    } else {
      setIsSubmittable(true);
    }
  };
  const [isAlertVisible, setIsAlertVisible] = useState(false);

  const [signatureName, setSignatureName] = useState(null);
  const [signatureImg, setSignatureImg] = useState(null);

  const savesignature = () => {
    setSignatureName(sigCanvas.current.toDataURL());
  };
  const clearSignature = () => {
    setShowSgnPad(true);
    setSignatureName(null);
    setValidationMessages([]);
    setIsSubmittable(false);
    if (sigCanvas.current) {
      sigCanvas.current.clear();
    }
  };
  const handleSignature = () => {
    savesignature();

    setIsSubmittable(true);
  };
  const timesheet_loading = useSelector(
    (state) => state.timesheet.timesheet_loading
  );
  const timesheet_id = useSelector((state) => state.timesheet.data);
  let newDate = new Date();
  let month = newDate.getMonth() + 1;
  let year = newDate.getFullYear();
  const [firstDate, setFirstDate] = useState(`${year}/${month}/1`);
  const alert_type = useSelector((state) => state.timesheet.alert_type);
  const [alertMsg, setAlertMsg] = useState(false);
  const sigCanvas = useRef({});
  const dispatch = useDispatch();
  const [validationMessages, setValidationMessages] = useState([]);
  const [isMonthChanged, setIsMonthChanged] = useState(false);

  const [timesheetYear, setTimesheetYear] = useState(null);
  const [timesheetMonth, setTimesheetMonth] = useState(null);

  const [machine, setMachine] = useState(null);
  const [machineSubType, setMachineSubType] = useState(null);
  const [vehicleCode, setVehicleCode] = useState(null);
  const [siteName, setSiteName] = useState(null);
  const [sheetMsg, setSheetMsg] = useState(null);

  const company =
    user_dt.items !== undefined ? user_dt.items.company_name : null;
  const [orderNumber, setOrderNumber] = useState(null);

  const [costCenter, setCostCenter] = useState(null);
  const [managerName, setManagerName] = useState(null);
  const [sheetStatus, setSheetStatus] = useState(null);
  const [foreman, setForeman] = useState(null);

  const [po, setPo] = useState(null);
  const [invoice, setInvoice] = useState(null);
  const [totalHours, setTotalHours] = useState(null);
  const [daysPerMonth, setDaysPerMonth] = useState(null);
  const [perDay, setPerDay] = useState(null);
  const [numericMonth, setNumericMonth] = useState(month);
  const [numericyear, setNumericyear] = useState(year);
  const [updateDisable, setUpdateDisable] = useState(false);

  const handleSigantureChange = (target) => {
    setSignatureName(target);
    if (target === null || target === undefined || target.length === 0) {
      setIsSubmittable(false);
    } else {
      setIsSubmittable(true);
    }
  };

  function getDaysInMonth(year, month) {
    setTimesheetData([]);
    let dateArry = [];
    let len = 0;
    len = new Date(year, month, 0).getDate();
    setDaysPerMonth(len);
    for (let i = 1; i <= len; i++) {
      let monthLong = new Date(
        String(year + "/" + month + "/" + i)
      ).toLocaleDateString("en-us", { month: "long" });
      let dayLong = new Date(
        String(year + "/" + month + "/" + i)
      ).toLocaleDateString("en-us", { weekday: "long" });
      dateArry.push({
        day: dayLong,
        date:
          i +
          "-" +
          monthLong.toString().substring(0, 3) +
          "-" +
          year.toString(),
        hours: null,
        rate: "Wet",
        period: "Day",
      });
    }
    setTimesheetData(dateArry);
  }

  const handleTimeSheetChange = (name, value, date) => {
    if (!value || value === 0) {
      value = null;
    }
    let updatedList = timeSheetData.map((item) => {
      if (item.date === date) {
        return { ...item, [name]: value };
      }

      return item;
    });
    setTimesheetData(updatedList);
    const total = updatedList.reduce(function (cnt, o) {
      return (
        cnt +
        (o.hours !== null && o.hours !== "null" && o.hours !== ""
          ? parseFloat(o.hours)
          : 0)
      );
    }, 0);
    if (
      total === null ||
      total === undefined ||
      total === 0 ||
      total.toString() === "NaN"
    ) {
      setIsSubmittable(false);
    } else {
      setIsSubmittable(true);
    }

    setTotalHours(total);
    setPerDay(
      parseFloat(total / parseInt(sheetData["days_per_month"])).toFixed(2)
    );
  };
  const handleMonthChange = (event) => {
    setPerDay(null);
    setTotalHours(null);
    setAlertMsg(false);
    setIsMonthChanged(true);
    setTimesheetData([]);
    setFirstDate(event);
    var selectedYear = new Date(String(event)).toLocaleDateString("en-us", {
      year: "numeric",
    });
    var selectedMonth = new Date(String(event)).toLocaleDateString("en-us", {
      month: "numeric",
    });
    getDaysInMonth(selectedYear, selectedMonth);
    setNumericyear(selectedYear);
    setNumericMonth(selectedMonth);
  };

  const onInputChange = (e) => {
    const { value } = e.target;
    const re = /^[A-Za-z]+$/;
    if (value === "" || re.test(value)) {
      const filteredValue = value.replace(/[0-9]/g, "");
      setForeman(filteredValue);
      // setForeman(value);
      if (value === null || value === undefined || value.length === 0) {
        setIsSubmittable(false);
      } else {
        setIsSubmittable(true);
      }
    } else if (re.test(value) === false) {
      const filteredValue = value.replace(/[0-9]/g, "");

      setForeman(filteredValue);
    }
  };

  if (isDateDataset === false) {
    if (daysData) {
      setTimesheetData(daysData);
      setIsDateDataset(true);
    }
    if (sheetData) {
      setVehicleCodeOptions(vehicle_code_list2 ? vehicle_code_list2 : []);
      setMachineListoptions(machine_list2 ? machine_list2 : []);
      setSheetMsg(sheetData["sheet_message"]);
      setMachine(sheetData["machine"]);
      setMachineSubType(sheetData["machine_sub_type"]);
      setForeman(sheetData["foreman"]);
      setSignatureImg(sheetData["signature"]);
      setSignatureName(sheetData["signature"]);
      // setTimeout(() => {
      sigCanvas.current.fromDataURL(sheetData["signature"]);
      // }, 2000);

      setPo(sheetData["po"]);
      setInvoice(sheetData["invoice"]);
      setOrderNumber(sheetData["order_number"]);
      setCostCenter(sheetData["cost_center"]);
      setPerDay(sheetData["per_day"]);
      setDaysPerMonth(sheetData["days_per_month"]);
      setTotalHours(sheetData["total_hours"]);
      setManagerName(sheetData["manager_name"]);
      setUpdateDisable(sheetData["is_approved"]);
      setTimesheetYear(sheetData["year"]);
      setTimesheetMonth(sheetData["month"]);
      setVehicleCode(sheetData["vehicle_code"]);
      setSiteName(sheetData["site_name"]);
    }
  }

  const submit = () => {
    let signature_name = signatureName;
    if (signatureName) {
      signature_name = signatureName;
    } else {
      signature_name = sigCanvas.current
        .getTrimmedCanvas()
        .toDataURL("image/png");
    }
    let dataDict = {
      sheet_data: {
        vehicle_code:
          vehicleCode && vehicleCode !== "Select"
            ? vehicleCode
            : sheetData["vehicle_code"],
        machine: machine ? machine : sheetData["machine"],
        site_name: siteName ? siteName : sheetData["site_name"],
        machine_sub_type: machineSubType
          ? machineSubType
          : sheetData["machine"],
        company: company ? company : sheetData["company"],
        foreman: foreman ? foreman : sheetData["foreman"],
        po: po ? po : sheetData["po"],
        cost_center: costCenter ? costCenter : sheetData["cost_center"],
        order_number: orderNumber,
        viewer_id: parseInt(sheetData["viewer"]),
        manager_name: managerName ? managerName : sheetData["manager_name"],
        // signature: sigCanvas.current.getTrimmedCanvas().toDataURL("image/png"),
        signature: signature_name,
        // signature: signatureName
        //   ? signatureName
        //   : sigCanvas.current.getTrimmedCanvas().toDataURL("image/png"),
        invoice: invoice,
        status: "Complete",
        total_hours: totalHours ? totalHours : sheetData["total_hours"],
        total: totalHours ? totalHours : sheetData["total_hours"],
        per_day: perDay ? perDay : sheetData["per_day"],
        days_per_month: daysPerMonth
          ? daysPerMonth
          : sheetData["days_per_month"],

        year: sheetData["year"],
        month: sheetData["month"],
        month_year: sheetData["month_year"],
      },
      days_data: timeSheetData,
    };

    let messages = [];
    // if (!selectedViewer) {
    //     messages.push("Viewer is required");
    // }

    if (!machine || machine === "Select") {
      messages.push("Machine is required");
    }
    if (!machineSubType || machineSubType === "Select") {
      messages.push("Machine Subtype is required");
    }
    if (!vehicleCode) {
      messages.push("Vehicle Code is required");
    }
    if (vehicleCode === "Select") {
      messages.push("Vehicle Code is required");
    }

    if (!siteName) {
      messages.push("Site Name is required");
    }
    if (siteName === "Select") {
      messages.push("Site Name is required");
    }
    // if (!costCenter) {
    //   messages.push("Cost Center is required");
    // }
    // if (!orderNumber) {
    //   messages.push("Reference Number is required");
    // }
    if (!managerName) {
      messages.push("Name is required");
    }
    if (!company) {
      messages.push("Company is required");
    }
    if (!foreman) {
      messages.push("Foreman is required");
    }
    // if (!invoice) {
    //   messages.push("Invoice is required");
    // }
    if (!po || po === "Select") {
      messages.push("P.O is required");
    }

    if (timeSheetData.length > 0) {
      let count = 0;
      timeSheetData.map((item) => {
        if (item.hours !== null && item.hours !== "null" && item !== 0) {
          count += 1;
          return count;
        }
      });
      if (count === 0) {
        messages.push("Hours is required");
      }
    }

    if (messages.length > 0) {
      const error_violation = document.getElementById("msg_div");
      window.scrollTo({
        top: error_violation.offsetTop,
        behavior: "smooth",
      });
      setValidationMessages(messages);
    } else {
      setIsMonthChanged(false);
      setAlertMsg(true);
      setValidationMessages([]);
      dispatch(timesheetActions.updateTimesheetData(dataDict, selectedsheetid));
      if (timesheet_id && isMonthChanged === false) {
        setAlertMsg(false);
        setIsAlertVisible(true);
        setTimeout(() => {
          setIsAlertVisible(false);
        }, 4000);
      }
    }
  };
  const handleGoBack = () => {
    window.location.assign(`/list-timesheet`);
  };

  useEffect(() => {
    dispatch(timesheetActions.getOptionsList());
    dispatch(userActions.getUserData());
    if (selectedsheetid) {
      dispatch(timesheetActions.getSheetById(selectedsheetid));
    }
    if (sheetData) {
      getDaysInMonth(sheetData["year"], sheetData["month"]);
    }
    // const defaultSignatureDataURL =
    //   "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK8AAAB8CAYAAAAfOOD0AAAAAXNSR0IArs4c6QAADWhJREFUeF7tXT3oN0cRfoKNokUEAwpKIiSFYMCAQgQlSho7FZTESoNYJ4ViJSoiCGmSQmwEkyoWKbQQ7VQUEkihjVUEDRFMISgY0CKoPH9vw7zz7t7t98fdHLy8f363uzf77HNzs7Ozs3fArhEI/AjAl9SDvw3gWyOEWfWZd6wq+KJyfwLAL3dkfz+APy/at+5iG3n7QX5EXErySQC/6ifS2k8y8vYZP03cZwA8tmlh3nMXf+M9uyIQMPJGgFRY5B4AfxJtSO36X9W2ad4EsI28CWBlFH0KwOOinrRpNalZzMYjAWQDKwGsxKLSVOAkjFpVTsboWfimaJP3SG67IhEw8kYClVhMEvdvAD7i8SLQ6yDtXWcHJz7qusWNvPXHXk/OQnastndtspY4FkbeRMAOiscS1+c2Mx9v4lgYeRMB2ykeS1w2YfZuBdyNvBVA3GxXuXJ2tNT7cwCfEo+mXXxXHVGu04qRt85Y049L1xevmInXCwAeNE9DGfhG3jL8WFt6Dbi0ywna0aU9DbH1jtq91H0jb9lwMzKMEWK8Uvy0UlOzrpE3YxyMvBmgbVX2ln2PWjXyHiEUcd/IGwFSoIj89MfYubIZTd7U+vlSn6imkTdvMKWrK8VccE8z8ubhfkstI286iCn+3FDrRt503G+rYeRNB1ESL3dJV3sbjvzC6VJeoIaRN22Q5d6zEg+B3sNm5E0bh5vSRt540I5CHONbun152Mibgt5W1sgbD5qMAivd8fAogOfEoz8O4LfxolhJ07zxHHgVwHu34jXcWnrSl2s7x/fghCVN8x4PqrRPawXQyJU5SmDkPR4H8zYkYqRJVmouuMcbeRMHwlfcNG8YRL38W8NccE/TZoNN2DLIbOQNgyYnaDmraHvD8VUAT4oCTwN4ImP8Ll3FyPv/4aeWlZshH1HB4rVtUr2T4nkAn780EzM6Pyt5HZke2vr0yhZySA3oS4fkAsH1/w4S/u62nZOk/PtuD2l9EPq2rWdAfUsVTV4zGzIQnY28JNkPlNbT3XIkJIlJxLcCeHdG31OqvAbgPSkVDsra8nAFMGcir9ZGFbpXtYmfAvhMpRZt23sFIGchry9fLbvntKwzByp0ObuJWj7eHwL4spKilgsuu3MrVpyBvNrnSRxfBPA1sWTqyEszgX/TFiaxqQnvrAA82zp6QWp5HLTWpfgzjEMFGPs2MQNoOrY1Z2Z/NGFzHoXXN3jfoSaA2mShPU05uMvX2dM1/Lw+06iWRu/LnAmeNpq8eiFgxKx7L1ujNGdKZQslly5tdwIajRFhNHm1JsrRuqXIac0vyVSTvPo5Tu7RY1CK34j6N2d3jAbudwA+JHr/ewAPdETDZy7IvAvyfonZEPKk2EQtfrD5heT86Ivb/OSZ2chb25+6B01MsjuCxRy6BK6EaC8DuFcJU7ITI37I1y+pScuJM7+Ow8nr00glJEkZqj1zQbbjVuRyT+nx2dT0pnw0RdiLlt1diRyteX3ar4dG0u65EpPgiFe+F3Q07kcyj74vv3iUxXl/blEgo0GkVuJSqfaxtp6BS1/rHwHc13C0LAN6PLjkAc00d8AiycpJvPd4r9HkZbd8ixQU+tlGJ0Lq1byWZorPZBjhUYmnz5iSzq6VZ3QcKrAZyEvBSSgZkuggPOxABtZS67Y0FyiazyyaAfMM2JpVyY6wmwXIkPlAxGoSWGrdWsu9e6NqGdDD6GiltWsi+JqZhbyUbY/AXwDw48J3vySrY+6jLbmIH7lsbSubm4m8ewT+B4DPFp7LW5LVsRZ5r27vFmvbmcnrCCxnnE7ekh0N2vbs9dJqzXvlE3/0xLzYHOw1iKmaK2RC5BC4RlbHVPld+b+KqLS/AHhfbkML16uqbWfXvE6+EIFJgm9Eno4+OmpNejZq7sRYhcvatq3q3ZlV8x4R+A0A3z3wA2viVgUugj2jX5wIEZsVaaZtV9G8RwTeW8gYTVzKftWsOFU8CTGv1eyaVxKYgTS+S2tUbeP21rhORj2IZ5+s+Xza+qT7GE5Gl1mFvOzQxwD8JtAzt+Awk19VD+ZKWEcTaFtFpHdIrpAWexJiBFgNUF+sgOsnfcFuM+abMZ8xIDQq03s1r1E3gs36gmhaxaN4hViNvOzE3koc7ycvMzYadRkv3GMpulE3vM36QkpJXG/0VyvBViQvsWCiuu9s2XIkNv8B8JZWYCW2+08A3KXM6yzB5yQt0w18euvXUEWxGnlpV2n7SnNq1ARNyqHNm9V9vNr1xb2G7NPNRshR1yrk9ZkK/ET9DMAHt015EsOWMboxY3WW/LvsB213uVlgBuVwMwazk5eg8e3mjlF3ETxpX+mJg7N76ZoadWlPw+iXKRUHh7kkLZUFvQhd7do9wWcmr29bOklL8urL54UYqSH01p+ZcXZY+nYzOEVws1s39Q1oXX42UEMAxsTzzhT43TKrem1O7JG2q+srtWOzkDcEYMpOYp/27eIsV6CvEtPgs2en1rSa3KPJu0faHPtKr7CN8K92W9tP1VRb+b1w0ynNg1A/R5FXu16cfKV+Q5/27T1ZmjWmIURab06EzBeja7Xe5A2RtiaAerLU28c648qaL/GJ07K5mYC6EtX3sJ7k7QWgPiaK/e4Z0SUnayNsbjnOvq33ObtRhhN1FHl92rampvX1S26/4f1eJNJmy6gDsX2YzxCsVPUlaK159ZtfatPGdn7UxE1+XUbtWfsegK8LoFpmH4odjyblWpJXRx6luL1KOxuTvrT0Gb760t7u2V/K4ov7WN6u3RukVuSVxO2lbXU/a5x1kULwkf5dPUnlORffHx04kwJeTtkW5JWfzlHEJRbadGgdljhi50RoQhbMrJhDklnr1Cav3j0wEkRttvwbwNsaDkRvF5nv7LqR8RwNofU3XZO8Ekx+tngQ9OgIpH+pgPVWLrOeJkPIV365VFK1yKtNhaa7RhNe8aZJL4Qc2rfcalUvFI/Q6nkJUPcvWoO8+vPcSrvloqMnbi3kky9JK/MktPn0ksQlGUrJO8M5akek7qF9W9u7oQMIL0vcUvJqTTArkL6AlJrat7W96zv2gGN3ORtXa6kSzTsi3+2Rlg3db6l9W275CRF3VkWROz5Z9XLJqydoI/eLxXS8pfZttWvC5wozjStGO5e8M0VOxZDXt2hRw3RoYTKEXGHsg2ncQvKupnVddx8F8Jzoew2bsXbgecijQLFrvGyxL/oS5XI0r5xZ1yBAT6DkF6NG4EytfGQk7VMiE43EpIacPTHu9qxU8q6qdR2gtV1a2i6N2eWsBzfkBmO5Sy33prI+lbxy8HsFeKf2aa987QNOtDcgJuCbWtb9YzIV3+GJMe3UxGXJtlLIK+2xEbtyawBcm7yUSa/g8Tfiw8/9K5vQd2+E9RFV94tnIX9lgriQGng3bSOFvHLgV9S6LT0OoeNnUwfvNPvLUjueUz6WvHoWHFsvR6aWdVpoXspLfHxnx6X0xSZmKWglxDbIidqqWpfQtA4iyiHxafeYJXIxuXiMBj2L1iU4embfcnevm5SRnNLWfRcAxjvzd/cveeCsQlxU2U+E/3Flres+7/JUIXNFLfwWHGleqakYp/qBTVss3OVbvAOrek1Wxr+a7EfkbRV0Uq0DGQ21jALLEMeq5CKwR149M19tKTiEibZ7bZafy57B9ULk9WW6mT3sMQXKHluDUuSxshkI+Mg7S5LmjO5EV9Ev59MAnoiubQWnQMBHXp195ayTGnlOGo9memCKETEhohHQ5PVFOK3uHguBITNJnvUFjSbCigU1eX1BJmcNgtZfmLP2c0VeRsksyevTumeeibeKc4gC3gqVIyDJ69vwd2ZtZOQt58/QFhx5fR6Gs9uBKx70N5Qssz3ckdeXH+CsEzU3Bkbe2diYKI8jr++wk7OsqIUgeQHAg9vNUSn4E4fLiksEHHm1FmKZo7iH1ZF8GcC9WyfMz7vgaDqC+lxkZydv7Z3ECw7/2iI7gsroMfbo7JM19lG/sGd/Wddmqkf6EHnP7N+1CdtJaEzy+txkz29p+U/STW83zNuw+OiGyHuFCYyFRZ6AvFcKxpHDpe18s3kXIzMHzEfes29M1KbSFSaoi1HzWNyQ2XD2CZttBTrmxvQlQt6Gsy9S6BXFs7+s0xMxR8C9RYozLg/TXHgSwOcUWGeP48jhxvR19mIbzqaNfPEbboAsXf70VL1dQBkSSb8nNZO8zqCRGDHHJHi6b66fFpSzIHG1XRs6fWbFgHQSlaRl8uYQadn/1wHcf4IsQIvSr0xs6dv0HffE1mXOWEcEztbpTpvlolyU6aGNtDFyUX5+Wdg/uxZEQDvmQ3Yhs3Xz86oze/M33nMkZ3tvB/AHAMwGLi8STBKFWcNdmXcC+PumJX8tKsny7m/3Arn/HwdwZwL2ljI/AayZi/pWlfYmNjP35Ug2y4N7hNBi90NLor743sW69ubXwJF2JjNnRSynkzlEXn6SXwLARMih6zUAv9gODXGfdJc4ec9ckPdY78NbsmVnBrjDR1gudFKOM1NoYtBkoPnChM3ucgeaTAe4CVQPgb1gFJKJJsTDAN7YHvns9ls9CeJacsS2yVUcXpco9T9XkhTJ2BLUigAAAABJRU5ErkJggg==";
    // // Set the default signature
    // if (sigCanvas.current) {
    //   sigCanvas.current.fromDataURL(defaultSignatureDataURL);
    // }
    const resizeSignature = () => {
      const canvas = sigCanvas.current.getCanvas();
      const ctx = canvas.getContext("2d");
      const scaleFactor = 0.5; // Adjust the scaling factor as needed (e.g., 0.5 for 50% size)

      // Backup the current content of the canvas
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

      // Scale down the canvas
      canvas.width = canvas.width * scaleFactor;
      canvas.height = canvas.height * scaleFactor;

      // Redraw the signature at the new size
      ctx.putImageData(imageData, 0, 0);
    };
    window.addEventListener("resize", resizeSignature);

    // Call the resize function initially to set the size
    resizeSignature();

    // Don't forget to remove the event listener when the component is unmounted
  }, []);

  return (
    <div className="flex">
      <SideBar />
      <main className="w-full min-w-[50rem] overflow-x-auto bg-gray-100 py-10">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="px-4 sm:px-6 lg:px-8">
            <div className="lg:flex lg:items-center">
              <div className="space-y-4 sm:flex-auto">
                <h1 className="text-3xl font-semibold leading-6 text-gray-900">
                  Update Timesheet
                </h1>
                <p className="min-width-350 mt-2 text-sm text-gray-500">
                  You can update your timesheet here.
                </p>
              </div>
              <div className="mt-4 text-right lg:ml-16 lg:mt-0 lg:w-3/4 ">
                <button className="go-back-btn" onClick={handleGoBack}>
                  <i className="fa fa-arrow-left" aria-hidden="true"></i> Go
                  Back
                </button>
              </div>
            </div>
            {sheetMsg && (
              <div className="msg-notification   mx-auto ml-0 mr-0 mt-20 pl-0  pr-0 text-center ">
                {sheetMsg}
              </div>
            )}
            <div className="mt-8 rounded-lg bg-white p-6">
              <div className="space-y-6">
                <div>
                  <div className="pb-4">
                    <h2 className="text-lg font-semibold leading-7 text-gray-900">
                      <div className="d-flex justify-content-center ">
                        {timesheetYear && timesheetMonth && (
                          <Calendar
                            currentDate={
                              new DateObject({
                                year: timesheetYear,
                                month: timesheetMonth,
                              })
                            }
                            disabled
                          />
                        )}
                      </div>
                    </h2>
                  </div>
                  <hr className="-mx-6" />

                  <div className="mt-4 grid grid-cols-1 gap-x-6 gap-y-3 sm:grid-cols-3">
                    <div>
                      <label
                        htmlFor="machine"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Machine
                      </label>
                      <div className="mt-2">
                        <select
                          defaultValue={machine}
                          onChange={(event) => handleInputMachineChange(event)}
                          name="machine"
                          id="machine"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                        >
                          {machine_list2
                            ? machine_list2.map((item, index) => (
                                <option
                                  value={item}
                                  key={index}
                                  selected={item === machine}
                                >
                                  {item}
                                </option>
                              ))
                            : []}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="machine"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Machine Subtype
                      </label>
                      <div className="mt-2">
                        <select
                          defaultValue={machine}
                          onChange={(event) =>
                            handleInputMachineSubTypeChange(event)
                          }
                          name="machineSubType"
                          id="machineSubType"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                        >
                          {machine_sub_list2
                            ? machine_sub_list2.map((item, index) => (
                                <option
                                  value={item}
                                  key={index}
                                  selected={item === machineSubType}
                                >
                                  {item}
                                </option>
                              ))
                            : []}
                        </select>
                      </div>
                    </div>

                    {/* <div>
                      <label
                        htmlFor="Company"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Company
                      </label>
                      <div className="mt-2">
                        <input
                          type="text"
                          name="Company"
                          id="Company"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          defaultValue={company}
                          disabled
                        />
                      </div>
                    </div> */}

                    <div>
                      <label
                        htmlFor="site-name"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Foreman
                      </label>
                      <div className="mt-2">
                        <input
                          type="text"
                          name="Foreman"
                          id="Foreman"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          placeholder="Foreman"
                          value={foreman}
                          onChange={onInputChange}
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="purchase-order-number"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Purchase Order Number
                      </label>
                      <div className="mt-2">
                        <Select
                          disabled={po_list2 ? false : true}
                          onChange={(event) => handleInputPOChange(event.value)}
                          options={po_list2 ? po_list2 : []}
                          value={
                            po
                              ? { value: po, label: po }
                              : { value: "Select", label: "Select" }
                          }
                          name="purchase-order-number"
                          id="purchase-order-number"
                          className="select2 block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                        />

                        {/* {po_list2 &&
                            po_list2.map((item, index) => (
                              <option
                                value={item}
                                key={index}
                                selected={item === po}
                              >
                                {item}
                              </option>
                            ))}
                        </select> */}
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="invoice"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Invoice Number
                      </label>
                      <div className="mt-2">
                        <input
                          type="text"
                          name="invoice"
                          id="invoice"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          defaultValue={invoice}
                          onChange={(event) =>
                            handleinvoiceChange(event.target.value)
                          }
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="order_number"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Reference Number
                      </label>
                      <div className="mt-2">
                        <input
                          type="text"
                          name="order_number"
                          id="order_number"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          defaultValue={orderNumber}
                          onChange={(event) =>
                            handleordernumberChange(event.target.value)
                          }
                        />
                      </div>
                    </div>
                    {/* <div>
                      <label
                        htmlFor="cost_center"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Cost Center
                      </label>
                      <div className="mt-2">
                        <input
                          type="text"
                          name="cost_center"
                          id="cost_center"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          defaultValue={costCenter}
                          onChange={(event) =>
                            handlecostcenterChange(event.target.value)
                          }
                        />
                      </div>
                    </div> */}
                    <div>
                      <label
                        htmlFor="vechile_code"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Vehicle Code
                      </label>
                      <div className="mt-2">
                        <Select
                          disabled={vehicle_code_list2 ? false : true}
                          onChange={(event) =>
                            handleInputVehicleCodeChange(event.value)
                          }
                          options={vehicle_code_list2 ? vehicle_code_list2 : []}
                          value={
                            vehicleCode
                              ? { value: vehicleCode, label: vehicleCode }
                              : { value: "Select", label: "Select" }
                          }
                          name="vehicleCode"
                          id="vehicleCode"
                          className="select2 block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                        />
                        {/* {vehicle_code_list2
                            ? vehicle_code_list2.map((item, index) => (
                                <option
                                  value={item}
                                  key={index}
                                  selected={item === vehicleCode}
                                >
                                  {item}
                                </option>
                              ))
                            : []}
                        </select> */}
                      </div>
                    </div>
                    <div>
                      <label
                        htmlFor="SiteName"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Site Name
                      </label>
                      <div className="mt-2">
                        <Select
                          disabled={site_name_list2 ? false : true}
                          onChange={(event) =>
                            handleInputSiteNameChange(event.value)
                          }
                          options={site_name_list2 ? site_name_list2 : []}
                          value={
                            siteName
                              ? { value: siteName, label: siteName }
                              : { value: "Select", label: "Select" }
                          }
                          name="purchase-order-number"
                          id="purchase-order-number"
                          className="select2 block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                        />
                        {/* {site_name_list2
                            ? site_name_list2.map((item, index) => (
                                <option
                                  value={item}
                                  key={index}
                                  selected={item === siteName}
                                >
                                  {item}
                                </option>
                              ))
                            : []}
                        </select> */}
                      </div>
                    </div>

                    <div></div>

                    <div className="col-span-3 my-6 flow-root rounded-lg border border-gray-200 bg-white">
                      <div className="overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                          <div className="relative">
                            <table className="min-w-full table-fixed divide-y divide-gray-200">
                              <thead>
                                <tr>
                                  <th
                                    scope="col"
                                    className="border-r border-gray-200 py-3.5 pl-5 pr-3 text-left text-sm font-normal text-gray-400"
                                  >
                                    <div className="flex items-center space-x-1">
                                      <span>Day</span>
                                      <button type="button">
                                        <ChevronDownIcon className="h-4 w-4" />
                                      </button>
                                    </div>
                                  </th>
                                  <th
                                    scope="col"
                                    className="border-r border-gray-200 px-3 py-3.5 text-left text-sm font-normal text-gray-400"
                                  >
                                    <div className="flex items-center space-x-1">
                                      <span>Date</span>
                                      <button type="button">
                                        <ChevronDownIcon className="h-4 w-4" />
                                      </button>
                                    </div>
                                  </th>
                                  <th
                                    scope="col"
                                    className="border-r border-gray-200 px-3 py-3.5 text-left text-sm font-normal text-gray-400"
                                  >
                                    <div className="flex items-center space-x-1">
                                      <span>Hours</span>
                                      <button type="button">
                                        <ChevronDownIcon className="h-4 w-4" />
                                      </button>
                                    </div>
                                  </th>
                                  <th
                                    scope="col"
                                    className="border-r border-gray-200 px-3 py-3.5 text-left text-sm font-normal text-gray-400"
                                  >
                                    <div className="flex items-center space-x-1">
                                      <span>Rate</span>
                                      <button type="button">
                                        <ChevronDownIcon className="h-4 w-4" />
                                      </button>
                                    </div>
                                  </th>
                                  <th
                                    scope="col"
                                    className="border-r border-gray-200 px-3 py-3.5 text-left text-sm font-normal text-gray-400"
                                  >
                                    <div className="flex items-center space-x-1">
                                      <span>Period</span>
                                      <button type="button">
                                        <ChevronDownIcon className="h-4 w-4" />
                                      </button>
                                    </div>
                                  </th>
                                </tr>
                              </thead>
                              <tbody>
                                {timeSheetData && timeSheetData.length > 0
                                  ? timeSheetData.map((Data, index) => (
                                      <tr key={Data}>
                                        <td className="whitespace-nowrap py-4 pl-5 pr-3 text-sm text-gray-500">
                                          {Data.day}
                                        </td>
                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                          {Data.date}
                                        </td>
                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                          <div className="max-w-[6rem]">
                                            <input
                                              type="number"
                                              name="hours"
                                              id="hours"
                                              className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                                              min={0}
                                              placeholder="0"
                                              key={Data.hours}
                                              value={
                                                Data.date === hrsDate
                                                  ? hrsVal
                                                  : Data.hours
                                              }
                                              onChange={(event) =>
                                                handlehourschange(
                                                  event,
                                                  Data.date
                                                )
                                              }
                                            />
                                          </div>
                                        </td>
                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                          <select
                                            className="form-control table-input-box d-flex mx-auto"
                                            name="rate"
                                            value={Data.rate}
                                            onChange={(event) =>
                                              handleTimeSheetChange(
                                                event.target.name,
                                                event.target.value,
                                                Data.date
                                              )
                                            }
                                          >
                                            {rateList.map((data, key) => (
                                              <option
                                                key={key}
                                                value={data.key}
                                              >
                                                {data.value}
                                              </option>
                                            ))}
                                          </select>
                                        </td>
                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                          <select
                                            className="form-control table-input-box d-flex mx-auto"
                                            name="period"
                                            value={Data.period}
                                            onChange={(event) =>
                                              handleTimeSheetChange(
                                                event.target.name,
                                                event.target.value,
                                                Data.date
                                              )
                                            }
                                          >
                                            {periodList.map((item, key) => (
                                              <option
                                                value={item.value}
                                                key={key}
                                              >
                                                {item.value}
                                              </option>
                                            ))}
                                          </select>
                                        </td>
                                      </tr>
                                    ))
                                  : null}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="total-hours"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Total Hours
                      </label>
                      <div className="mt-2">
                        <input
                          type="text"
                          name="total-hours"
                          id="total-hours"
                          disabled={true}
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          value={totalHours}
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="days-per-month"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Days Per Month
                      </label>
                      <div className="mt-2">
                        <input
                          type="text"
                          name="days-per-month"
                          id="days-per-month"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          disabled={true}
                          value={daysPerMonth}
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="per-day"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Average Hours Per Day
                      </label>
                      <div className="mt-2">
                        <input
                          type="text"
                          name="per-day"
                          id="per-day"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          disabled={true}
                          value={perDay}
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="total"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Total
                      </label>
                      <div className="mt-2">
                        <input
                          type="text"
                          name="total"
                          id="total"
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          // placeholder="14"
                          disabled={true}
                          value={totalHours}
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="name"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Name
                      </label>
                      <div className="mt-2">
                        <input
                          className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-[#FCAF17] sm:text-sm sm:leading-6"
                          type="text"
                          id="manager_name"
                          name="manager_name"
                          value={managerName}
                          // onChange={(event) =>
                          //   handlemanagernameChange(event.target.value)
                          // }
                          onChange={handlemanagernameChange}
                        />
                      </div>
                    </div>
                    <div className="sm:col-span-3">
                      <label
                        htmlFor="signature"
                        className="block text-sm leading-6 text-gray-700"
                      >
                        Signature
                      </label>
                      <div className=" mt-2 ">
                        {/* <SignaturePad
                          onChange={handleSignature}
                          ref={sigCanvas}
                          canvasProps={{
                            className: "signatureCanvas ",
                          }}
                        /> */}
                        {signatureName &&
                        signatureName !== null &&
                        !showSgnPad &&
                        signatureName !==
                          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAAtJREFUGFdjYAACAAAFAAGq1chRAAAAAElFTkSuQmCC" &&
                        signatureName !==
                          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQIW2NgAAIAAAUAAR4f7BQAAAAASUVORK5CYII=" &&
                        signatureName !==
                          "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAAaADAAQAAAABAAAAAQAAAAD5Ip3+AAAAC0lEQVQIHWNgAAIAAAUAAY27m/MAAAAASUVORK5CYII=" ? (
                          <Base64ToImage
                            base64String={signatureName}
                            cls={true}
                          />
                        ) : (
                          <SignaturePad
                            penColor={"black"}
                            canvasProps={{
                              className: showSgnPad
                                ? "signatureCanvas"
                                : "signatureCanvas2",
                            }}
                            onChange={handleSignature}
                            ref={sigCanvas}
                          />
                        )}
                        <span
                          className="clear-btn"
                          type="clearSignature"
                          id="clearSignature"
                          onClick={clearSignature}
                        >
                          Clear
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                {updateDisable !== true ? (
                  <button
                    type="button"
                    className="focus-visible:outline-bg-[#FCAF17] mt-6 inline-flex justify-center rounded-md bg-[#FCAF17] px-7 py-2.5 text-sm font-semibold text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2"
                    onClick={() => submit()}
                    disabled={timesheet_loading ? true : false}
                  >
                    {sheet_status_loading && (
                      <span className="fa fa-spinner fa-spin"></span>
                    )}
                    {timesheet_loading && (
                      <span className="fa fa-spinner fa-spin"></span>
                    )}{" "}
                    Update
                  </button>
                ) : null}
              </div>
              <div
                className="clr-red col-sm-12 col-lg-12 col-xs-12 col-md-12 d-flex justify-content-center mt-20"
                id="msg_div"
              >
                <ul>
                  {validationMessages.map((vm) => (
                    <li key={vm}>{vm}</li>
                  ))}
                </ul>
              </div>

              {alertMsg === true &&
                data_saved === true &&
                sheet_status_loading === false && (
                  <div>
                    <p className="success-msg ">
                      Timesheet Updated Successfully
                    </p>
                  </div>
                )}

              {data_saved === false && sheet_status_loading === false && (
                <div>
                  <p className="fail-msg">
                    Something went wrong, Please try again
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default EditTimesheet;
