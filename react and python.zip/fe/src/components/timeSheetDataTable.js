import DataTable from "react-data-table-component";
import TimesheetPopUp from "./secondTimesheetPopup";
import NavBar from "./NavBar";
import { useEffect, useState } from "react";
import { datatableCustomStyles } from "../dataTableStyle";
import DaysDataTablePopUp from "./daysDataPopUp";
import { MDBBtn, MDBIcon } from "mdb-react-ui-kit";
import Nav from "react-bootstrap/Nav";
import { useDispatch, useSelector } from "react-redux";
import { timesheetActions } from "../store/actions/timeSheet.actions";
import { userActions } from "../store/actions/user.actions";
import SelectOptionDropDown from "./SelectOptionDropDown";
import moment from "moment";
import DateRangePicker from "react-bootstrap-daterangepicker";
import "bootstrap-daterangepicker/daterangepicker.css";
import { handleLongString } from "../helpers/Helper";
import SideBar from "./SideBar";
function TimesheetDataTable() {
  const selectedsheetid = window.location.href.split("id=")[1];
  const timeSheetStatus = window.location.href.split("status=")[1];
  const user_dt = useSelector((state) => state.users);

  const user_role =
    user_dt.items !== undefined && user_dt.items["role_detail"]["role"];

  const statusList = [
    { label: "Pending", value: "Pending", type: "sheetStatus" },
    { label: "Approved", value: "Approved", type: "sheetStatus" },
    {
      label: "Request Clarification",
      value: "Request Clarification",
      type: "sheetStatus",
    },
  ];
  const companyList = [
    {
      label: "Red Top Asset Management",
      value: "Red Top Asset Management",
      type: "sheetComapny",
    },
  ];
  const [sheetStatus, setSheetStatus] = useState(null);
  const [filterDate, setFilterDate] = useState(null);

  const [reset, setReset] = useState(false);
  const [startDate, setStartDate] = useState(false);
  const [placeholder, setplaceholder] = useState("SELECT DATE");
  const [endDate, setEndDate] = useState(false);
  const HandleClearFilters = () => {
    setplaceholder("SELECT DATE");
    setReset(!reset);
    dispatch(timesheetActions.getTimesheetlist(null, null, null));
  };

  const handleCallback = (start, end, label) => {
    let s_date = null;
    let e_date = null;
    setStartDate(moment(start).format("DD-MM-YYYY"));
    s_date = moment(start).format("DD-MM-YYYY");
    setplaceholder(
      `${moment(start).format("DD-MM-YY")}~${moment(end).format("DD-MM-YY")} `
    );
    localStorage.setItem(
      "sheet_start_date",
      moment(start).format("DD-MM-YYYY")
    );
    setEndDate(moment(end).format("DD-MM-YYYY"));
    e_date = moment(end).format("DD-MM-YYYY");
    localStorage.setItem("sheet_end_date", moment(end).format("DD-MM-YYYY"));
    dispatch(
      timesheetActions.getTimesheetlist(
        localStorage.getItem("sheetStatus")
          ? localStorage.getItem("sheetStatus")
          : null,
        s_date,
        e_date
      )
    );
  };

  const dispatch = useDispatch();
  const timesheet_list_loading = useSelector(
    (state) => state.TimesheetList.timesheet_loading
  );
  const timesheet_list = useSelector((state) => state.TimesheetList.data);
  const [isDataTablePopUp, setDataTablePopUp] = useState(false);
  const [sheetData, setSheetdata] = useState(null);
  const openDataTablePopUp = (sheet_data) => {
    setDataTablePopUp(true);
    setSheetdata(sheet_data);
  };

  function getMonthName(monthNumber) {
    const date = new Date();
    date.setMonth(monthNumber - 1);

    return date.toLocaleString("en-US", {
      month: "long",
    });
  }

  const TableColumns = [
    {
      name: "MONTH",
      minWidth: "50px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature">
          <pre className="wrd-break input-text-cstm" title={row.month}>
            {getMonthName(row.month)}
          </pre>
        </div>
      ),
    },
    {
      name: "YEAR",
      minWidth: "20px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature">
          <pre className="wrd-break input-text-cstm" title={row.year}>
            {row.year}
          </pre>
        </div>
      ),
    },
    {
      name: "FOREMAN",
      minWidth: "50px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature">
          <pre className="wrd-break input-text-cstm" title={row.foreman}>
            {row.foreman}
          </pre>
        </div>
      ),
    },
    // {
    //     name: "COMPANY",
    //     minWidth: "180px",
    //     selector: "risk",
    //     sortable: false,
    //     center: false,
    //     cell: (row) => (
    //         <div className="input-text-cstm cs-dt-customer-feature hbotQl">
    //             <pre
    //                 className="wrd-break input-text-cstm"
    //                 title={row.comapany}
    //             >
    //                 {row.company}
    //             </pre>
    //         </div>
    //     ),
    // },
    {
      name: "MACHINE",
      minWidth: "150px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-featur hbotQl">
          <pre className="wrd-break input-text-cstm" title={row.machine}>
            {row.machine}
          </pre>
        </div>
      ),
    },
    {
      name: "PURCHASE ORDER NUMBER",
      minWidth: "40px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature">
          <pre className="wrd-break input-text-cstm" title={row.po}>
            {row.po}
          </pre>
        </div>
      ),
    },
    {
      name: "INVOICE",
      minWidth: "50px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature">
          <pre className="wrd-break input-text-cstm" title={row.invoice}>
            {row.invoice}
          </pre>
        </div>
      ),
    },
    // {
    //     name: "STATUS",
    //     minWidth: "60px",
    //     selector: "risk",
    //     sortable: false,
    //     center: false,
    //     cell: (row) => (
    //         <div className="input-text-cstm cs-dt-customer-feature">
    //             <pre
    //                 className="wrd-break input-text-cstm"
    //                 title={row.status}
    //             >
    //                 {row.status}
    //             </pre>
    //         </div>
    //     ),
    // },
    {
      name: "ORDER NO",
      minWidth: "100px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature">
          <pre className="wrd-break input-text-cstm" title={row.order_number}>
            {row.order_number}
          </pre>
        </div>
      ),
    },
    {
      name: "COST CENTER",
      minWidth: "120px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature">
          <pre className="wrd-break input-text-cstm" title={row.cost_center}>
            {row.cost_center}
          </pre>
        </div>
      ),
    },
    {
      name: "MANAGER",
      minWidth: "50px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature ">
          <pre className="wrd-break input-text-cstm" title={row.manager_name}>
            {row.manager_name}
          </pre>
        </div>
      ),
    },
    {
      name: "STATUS",
      minWidth: "140px",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature">
          <pre className="wrd-break input-text-cstm" title={row.is_approved}>
            {row.is_approved === false && row.is_auditable === false
              ? `Pending`
              : row.is_approved === true && row.is_auditable === false
              ? `Approved`
              : `Clarification Requested`}
          </pre>
        </div>
      ),
    },
    {
      name: "",
      selector: "risk",
      sortable: false,
      center: false,
      cell: (row) => (
        <div className="input-text-cstm cs-dt-customer-feature cstm-btn-style">
          {user_dt.items !== undefined
            ? user_dt.items.role_detail.role === "Contractor" && (
                <MDBBtn
                  className="btn view-btn"
                  //   disabled={
                  //       row.is_approved === true ? true : false
                  //   }
                  // onClick={() => openDataTablePopUp(row.days_data)}
                >
                  <Nav.Link href={`${"/edit-timesheet"}/id=${row.id}`}>
                    Edit
                    {/* {row.is_approved === true
                                          ? `Approved`
                                          : `Edit`} */}
                  </Nav.Link>
                </MDBBtn>
              )
            : null}
          {user_dt.items !== undefined
            ? user_dt.items.role_detail.role === "Approver" && (
                <MDBBtn
                  className="btn view-btn"
                  onClick={() => openDataTablePopUp(row.days_data)}
                  //   disabled={
                  //       row.is_approved === true ? true : false
                  //   }
                >
                  Preview
                  {/* <Nav.Link href={`${"/view-timesheet"}/id=${row.id}`}> */}
                  {/* {row.is_approved === true
                                      ? `Approved`
                                      : `Preview`} */}
                  {/* <MDBIcon className="fas fa-eye"></MDBIcon> */}
                  {/* </Nav.Link> */}
                </MDBBtn>
              )
            : null}
        </div>
      ),
    },
    user_dt.items !== undefined
      ? user_dt.items.role_detail.role === "CFO" && {
          name: "APPROVED AT",
          minWidth: "140px",
          selector: "risk",
          sortable: false,
          center: false,
          cell: (row) => (
            <div className="input-text-cstm cs-dt-customer-feature">
              <pre
                className="wrd-break input-text-cstm"
                title={row.approved_on}
              >
                {row.approved_on
                  ? moment(row.approved_on).format("DD-MM-YYYY hh:mm A")
                  : `N/A`}
              </pre>
            </div>
          ),
        }
      : {},
    user_dt.items !== undefined
      ? user_dt.items.role_detail.role === "CFO" && {
          name: "APPROVED BY",
          minWidth: "140px",
          selector: "risk",
          sortable: false,
          center: false,
          cell: (row) => (
            <div className="input-text-cstm cs-dt-customer-feature">
              <pre
                className="wrd-break input-text-cstm"
                title={row.approved_by_name}
              >
                {row.approved_by_name ? row.approved_by_name : `N/A`}
              </pre>
            </div>
          ),
        }
      : {},

    user_dt.items !== undefined
      ? user_dt.items.role_detail.role === "CFO" && {
          name: "",
          minWidth: "140px",
          selector: "risk",
          sortable: false,
          center: false,
          cell: (row) => (
            <div className="input-text-cstm cs-dt-customer-feature cstm-btn-style">
              <MDBBtn
                className="btn view-btn"
                onClick={() => openDataTablePopUp(row.days_data)}
              >
                View
              </MDBBtn>
            </div>
          ),
        }
      : {},

    // {
    //     name: "VIEW",
    //     selector: "risk",
    //     sortable: false,
    //     center: false,
    //     cell: (row) => (
    //         <div className="input-text-cstm cs-dt-customer-feature cstm-btn-style">
    //             <MDBBtn
    //                 className="btn view-btn"
    //                 onClick={() => openDataTablePopUp(row.days_data)}
    //             >
    //                 {/* <Nav.Link href={`${"/view-timesheet"}/id=${row.id}`}> */}
    //                 Preview
    //                 {/* <MDBIcon className="fas fa-eye"></MDBIcon> */}
    //                 {/* </Nav.Link> */}
    //             </MDBBtn>
    //         </div>
    //     ),
    // },
  ];
  const handleclosepopup = (rslt) => {
    setDataTablePopUp(rslt);
  };
  useEffect(() => {
    dispatch(userActions.getUserData());

    setReset(false);
    localStorage.removeItem("sheetStatus");
    localStorage.removeItem("sheet_start_date");
    localStorage.removeItem("sheet_end_date");
    if (selectedsheetid) {
      const new_dt = [
        {
          timesheet: selectedsheetid,
        },
      ];
      openDataTablePopUp(new_dt);
    } else if (timeSheetStatus) {
      dispatch(timesheetActions.getTimesheetlist(timeSheetStatus, null, null));
    } else {
      dispatch(timesheetActions.getTimesheetlist());
    }
  }, [reset]);

  return (
    <>
      {/* <NavBar /> */}
      <div className="App">
        <SideBar />

        <main>
          {isDataTablePopUp && (
            // <DaysDataTablePopUp
            //     hideDaysDataTablePopUp={hideDaysDataTablePopUp}
            //     data={sheetData}
            // />
            <TimesheetPopUp
              ppmodal={true}
              data={sheetData}
              hideTmsPopUp={handleclosepopup}
            />
          )}
          <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row m-top-40 m-0 p-0">
            <div className="col-sm-11 col-lg-11 col-xs-11 col-md-11 row border-box d-flex  m-0 mx-auto mt-20 p-0 ">
              <div className="custFeedRow2 col-sm-12 col-md-12 col-lg-12 mt-1 bg-white p-4">
                <h2 className="clr-gray text-center">
                  <p className="m-0 p-0"> Timesheet List</p>
                </h2>

                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 add-sheet-btn">
                  {user_dt.items !== undefined ? (
                    user_dt.items.role_detail.role !== "Approver" &&
                    user_dt.items.role_detail.role !== "CFO" ? (
                      <Nav.Link href="/save-timesheet">
                        <MDBIcon className=" fa fa-plus"></MDBIcon> Add
                        Timesheet
                      </Nav.Link>
                    ) : null
                  ) : null}
                </div>
                <div className=" col-sm-12 col-md-12 col-lg-12 list-sheet-filters d-flex justify-content-center">
                  <div className=" ">
                    <SelectOptionDropDown
                      defaultText="STATUS"
                      optionsList={statusList && statusList}
                      reset={reset}
                    />
                  </div>
                  {user_role !== undefined &&
                    user_role !== false &&
                    user_role === "CFO" && (
                      <div className=" ">
                        <SelectOptionDropDown
                          defaultText="COMPANY"
                          optionsList={companyList && companyList}
                          reset={reset}
                        />
                      </div>
                    )}
                  <div className="date-range">
                    <DateRangePicker onCallback={handleCallback}>
                      <button
                        type="button"
                        className="custom-select-container_calendar "
                      >
                        {handleLongString(placeholder, 12)}{" "}
                      </button>
                    </DateRangePicker>
                  </div>
                  <div className="">
                    <MDBBtn
                      className="reset-btns rst-btn"
                      onClick={HandleClearFilters}
                    >
                      Reset
                    </MDBBtn>
                  </div>
                </div>

                <div className="  col-12 mt-5">
                  {timesheet_list_loading ? (
                    <div className=" d-flex justify-content-center mt-4">
                      <span className="fa fa-spinner fa-spin dataSourceLoader"></span>
                    </div>
                  ) : (
                    <DataTable
                      noHeader
                      columns={TableColumns}
                      pagination={true}
                      keyField={"id"}
                      paginationPerPage={10}
                      data={timesheet_list}
                      customStyles={datatableCustomStyles}
                      className="dashboard-table"
                    />
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </>
  );
}

export { TimesheetDataTable };
