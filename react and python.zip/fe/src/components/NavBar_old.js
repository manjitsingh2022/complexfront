import React, { useState, useEffect } from "react";
// import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
// import Navbar from "react-bootstrap/Navbar";
import logo from "../images/logo.png";
import user from "../images/user.jpg";
import { NavLink, Link } from "react-router-dom";
import Popup from "reactjs-popup";
import "reactjs-popup/dist/index.css";
import EditProfileIcon from "../assets/icons/editProfileIcon";
import SettingIcon from "../assets/icons/Settingicon";
import MyProfileIcon from "../assets/icons/myProfileIcon";
import HelpIcon from "../assets/icons/helpIcon";
import LogoutIcon from "../assets/icons/logoutIcon";
import { history } from "../helpers/history";
import { userActions } from "../store/actions/user.actions";
import { useDispatch, useSelector } from "react-redux";

function NavBar() {
    const dispatch = useDispatch();
    const [path, setPath] = useState("/");
    const user_dt = useSelector((state) => state.users);
    const [userRole, setUserRole] = useState(null);

    const logOut = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user_role");

        history.push("/login");
        window.location.href = "/login";
    };

    useEffect(() => {
        setPath(window.location.pathname);
        dispatch(userActions.getUserData());
        setUserRole(
            localStorage.getItem("user_role")
                ? localStorage.getItem("user_role")
                : null
        );
    }, []);

    return (
        <>
            <main className="top-border-box nav_header">
                <section className="header__content ">
                    <Link to="/">
                        <img
                            className="logo m-l-34"
                            src={logo}
                            alt="Timesheet"
                        />
                    </Link>
                    <Nav className="header__nav ">
                        <ul className="nav__list wdth-85">
                            <li>
                                <NavLink
                                    className={
                                        path === "/"
                                            ? "nav-selcted"
                                            : "hover-underline-animation"
                                    }
                                    to="/"
                                >
                                    Dashboard
                                </NavLink>
                            </li>

                            {userRole
                                ? userRole === "Contractor" && (
                                      <li>
                                          <NavLink
                                              className={
                                                  path === "/view-document"
                                                      ? "nav-selcted"
                                                      : "hover-underline-animation"
                                              }
                                              to="/view-document"
                                          >
                                              Documents
                                          </NavLink>
                                      </li>
                                  )
                                : null}
                            {/* {userRole
                                ? userRole ===
                                      "Contractor" && (
                                      <li>
                                          <NavLink
                                              className={
                                                  path === "/upload"
                                                      ? "nav-selcted"
                                                      : "hover-underline-animation"
                                              }
                                              to="/upload"
                                          >
                                              Upload
                                          </NavLink>
                                      </li>
                                  )
                                : null} */}
                            {/* {userRole
                                ? userRole ===
                                      "Contractor" && (
                                      <li>
                                          <NavLink
                                              className={
                                                  path === "/anomalies"
                                                      ? "nav-selcted"
                                                      : "hover-underline-animation"
                                              }
                                              to="/anomalies"
                                          >
                                              Anomalies
                                          </NavLink>
                                      </li>
                                  )
                                : null} */}

                            {userRole
                                ? userRole === "Contractor" && (
                                      <li>
                                          <NavLink
                                              className={
                                                  path === "/save-timesheet"
                                                      ? "nav-selcted"
                                                      : "hover-underline-animation"
                                              }
                                              to="/save-timesheet"
                                          >
                                              Add Timesheet
                                          </NavLink>
                                      </li>
                                  )
                                : null}
                            {userRole
                                ? (userRole === "Approver" ||
                                      userRole === "Contractor") && (
                                      <li>
                                          <NavLink
                                              className={
                                                  path === "/list-timesheet"
                                                      ? "nav-selcted"
                                                      : "hover-underline-animation"
                                              }
                                              to="/list-timesheet"
                                          >
                                              Timesheets
                                          </NavLink>
                                      </li>
                                  )
                                : null}

                            {userRole
                                ? userRole === "Contractor" && (
                                      <li>
                                          <NavLink
                                              className={
                                                  path === "/machines"
                                                      ? "nav-selcted"
                                                      : "hover-underline-animation"
                                              }
                                              to="/machines"
                                          >
                                              Machines
                                          </NavLink>
                                      </li>
                                  )
                                : null}

                            {userRole
                                ? (userRole === "Approver" ||
                                      userRole === "Contractor") && (
                                      <li>
                                          <NavLink
                                              className={
                                                  path === "/add-machine"
                                                      ? "nav-selcted"
                                                      : "hover-underline-animation"
                                              }
                                              to="/add-machine"
                                              onClick={() => {
                                                  window.location.assign(
                                                      "/add-machine"
                                                  );
                                              }}
                                          >
                                              {/* <a href="/add-machine">
                                                  {" "}
                                                  Add Machine{" "}
                                              </a> */}
                                              Add Machine
                                          </NavLink>
                                      </li>
                                  )
                                : null}
                            {/* {userRole
                                ? userRole ===
                                      "Contractor" && (
                                      <li>
                                          <NavLink
                                              className={
                                                  path === "/telematics"
                                                      ? "nav-selcted"
                                                      : "hover-underline-animation"
                                              }
                                              to="/telematics"
                                          >
                                              Telematics
                                          </NavLink>
                                      </li>
                                  )
                                : null} */}
                        </ul>
                    </Nav>
                    <div className="header__user">
                        <p className="user__name">
                            <span>
                                {user_dt.items !== undefined
                                    ? user_dt.items.name
                                    : "Anil G."}
                            </span>
                        </p>
                        <img
                            src={user}
                            alt="Timesheet"
                            height={50}
                            width={50}
                        />
                        <p className="user__name menu-popup-top">
                            <Popup
                                className="menu-popup-top"
                                trigger={
                                    <button className="menu-btn">
                                        {" "}
                                        <i
                                            className="fa fa-bars fnt-24"
                                            aria-hidden="true"
                                        ></i>
                                    </button>
                                }
                                position="bottom"
                            >
                                <div className="crsr-pointer-menu">
                                    <MyProfileIcon /> My Profile
                                </div>
                                <div className="crsr-pointer-menu">
                                    {" "}
                                    <EditProfileIcon />
                                    Edit Profile
                                </div>
                                <div className="crsr-pointer-menu">
                                    {" "}
                                    <Nav.Link href="/change-password">
                                        <SettingIcon /> Settings
                                    </Nav.Link>
                                </div>
                                <div className="crsr-pointer-menu">
                                    <HelpIcon />
                                    Help
                                </div>
                                <div
                                    className="crsr-pointer-menu"
                                    onClick={logOut}
                                >
                                    <LogoutIcon />
                                    <span>Logout</span>
                                </div>
                            </Popup>
                        </p>
                        <div></div>
                    </div>
                </section>
            </main>
        </>
    );
}

export default NavBar;
