import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { userActions } from "../store/actions/user.actions";
import { history } from "../helpers/history";
import LoginNavBar from "./LoginNavBar";

function LoginPage() {
    const [inputs, setInputs] = useState({
        email: "",
        password: "",
    });
    const [submitted, setSubmitted] = useState(false);
    const { email, password } = inputs;
    const loggingIn = useSelector((state) => state.authentication.loggingIn);
    const error = useSelector((state) => state.authentication.message);

    const dispatch = useDispatch();

    useEffect(() => {
        if (localStorage.getItem("token")) {
            history.push("/");
        }
    }, []);

    function handleChange(e) {
        const { name, value } = e.target;
        setInputs((inputs) => ({ ...inputs, [name]: value }));
    }

    function handleSubmit(e) {
        e.preventDefault();

        setSubmitted(true);
        if (email && password) {
            const { from } = { from: { pathname: "/" } };
            dispatch(userActions.login(email, password, from));
        }
    }

    return (
        <>
            <LoginNavBar />
            <main className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row m-top-40 ">
                <div className="col-sm-10 col-lg-10 col-xs-10 col-md-10 row mr-0 ml-0 pr-0 pl-0  mt-20 border-box d-flex mx-auto width-70 ">
                    <div className="wrapper mrg-bt-60 ">
                        <div className="content-wrapper">
                            <section className="content mt-5">
                                <div className="container-fluid ">
                                    <div className="row ">
                                        <div className="col-md-3 col-lg-3 col-sm-12"></div>
                                        <div className="col-md-6 col-lg-6 col-sm-12">
                                            {error ? (
                                                <div className="alert alert-danger">
                                                    {error}
                                                </div>
                                            ) : null}
                                            <span className="register-heading">
                                                Sign in{" "}
                                            </span>
                                            <form
                                                name="form"
                                                onSubmit={handleSubmit}
                                            >
                                                <div className="form-group mt-4">
                                                    <p className="form-label">
                                                        Email
                                                    </p>
                                                    <input
                                                        type="email"
                                                        name="email"
                                                        value={email}
                                                        onChange={handleChange}
                                                        className={
                                                            "inpt-box form-control mt15" +
                                                            (submitted && !email
                                                                ? " is-invalid"
                                                                : "")
                                                        }
                                                    />
                                                    {submitted && !email && (
                                                        <div className="text-danger">
                                                            Email is required
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="form-group mt-4">
                                                    <p className="form-label">
                                                        Password
                                                    </p>
                                                    <input
                                                        type="password"
                                                        name="password"
                                                        value={password}
                                                        onChange={handleChange}
                                                        className={
                                                            "form-control inpt-box mt15" +
                                                            (submitted &&
                                                            !password
                                                                ? " is-invalid"
                                                                : "")
                                                        }
                                                    />
                                                    {submitted && !password && (
                                                        <div className="text-danger">
                                                            Password is required
                                                        </div>
                                                    )}
                                                </div>

                                                <div className="form-group mt30">
                                                    <center className="">
                                                        <button className="btn btn-sky2">
                                                            {loggingIn && (
                                                                <span className="fa fa-spinner fa-spin mr-1"></span>
                                                            )}
                                                            <span className="btn-fnt">
                                                                Sign in{" "}
                                                            </span>
                                                        </button>
                                                    </center>
                                                </div>
                                            </form>
                                        </div>
                                        <div className="col-md-3 col-lg-3 col-sm-12"></div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </main>
        </>
    );
}

export { LoginPage };
