import { useState, useEffect } from "react";
import NavBar from "./NavBar";
import { MDBBtn } from "mdb-react-ui-kit";
import Select from "react-select";
import { useDispatch, useSelector } from "react-redux";
import { machineActions } from "../store/actions/machine.action";
import MachinepopUp from "./MachinePopUp";
import PaginationCustom from "./PaginationCustom";
import PaginationPageNum from "./PaginationPageNum";
import harvester from "../assets/icons/Harvester.png";
import bulldozer from "../assets/icons/Bulldozer.png";
import BackhoeLoader from "../assets/icons/BackhoeLoader.png";
import Telehandler from "../assets/icons/Telehandler.png";
import Excavator from "../assets/icons/Excavator.png";
import SteerLoader from "../assets/icons/SteerLoader.png";
import SingleManLift from "../assets/icons/SingleManLift.png";
import Forklift from "../assets/icons/Forklift.png";
import Scissor from "../assets/icons/Scissor.png";
import SimpleMachine from "../assets/icons/SimpleMachine.png";
import ArticulatedDumpTruck from "../assets/icons/ArticulatedDumpTruck.png";
import SelectOptionDropDown from "./SelectOptionDropDown";
import image from "../assets/icons/machines-img.svg";
import { handleLongString } from "../helpers/Helper";
import MachinePopUp from "./secondMachinePopup";
import SideBar from "./SideBar";
function Machines() {
    const [reset, setReset] = useState(false);
    const updatePageNo = (newState) => {
        setPage(newState);
    };
    const user_dt = useSelector((state) => state.users);
    const companyList = [
        {
            label: "Red Top Asset Management",
            value: "Red Top Asset Management",
            type: "machComapny",
        },
        {
            label: "Quartz Plant Hire",
            value: "Quartz Plant Hire",
            type: "machComapny",
        },
        {
            label: "KLT Machinery and Plant Hire",
            value: "KLT Machinery and Plant Hire",
            type: "machComapny",
        },
    ];
    const user_role =
        user_dt.items !== undefined && user_dt.items["role_detail"]["role"];
    const [selectedType, setSelectedType] = useState("");
    const [selectedSubType, setSelectedSubType] = useState("");
    const [searchItem, setSearchitem] = useState("");

    const [searchValue, setSearchValue] = useState(null);

    const HandleSelectTypeChange = (type) => {
        setSelectedType(type);
        setPage(1);
        dispatch(
            machineActions.getMachinelist(type, selectedSubType, searchItem, 1)
        );
    };
    const HandleSelectSubTypeChange = (subtype) => {
        setSelectedSubType(subtype);
        setPage(1);
        dispatch(
            machineActions.getMachinelist(selectedType, subtype, searchItem, 1)
        );
    };

    const HandleSearchChange = (search) => {
        localStorage.setItem("search", search);
        setSearchitem(search);
        setPage(1);
        setSearchValue(search);

        dispatch(
            machineActions.getMachinelist(
                localStorage.getItem("machineType")
                    ? localStorage.getItem("machineType")
                    : null,
                localStorage.getItem("machineSubtype")
                    ? localStorage.getItem("machineSubtype")
                    : null,

                search,
                localStorage.getItem("machComapny")
                    ? localStorage.getItem("machComapny")
                    : null,
                1
            )
        );
    };

    const HandleClearFilters = () => {
        setReset(!reset);
        HandleSearchChange("");
        dispatch(machineActions.getMachinelist(null, null, null, null, page));
    };

    const handlePageChange = (pageNo) => {
        if (pageNo === "-") {
            dispatch(
                machineActions.getMachinelist(
                    localStorage.getItem("machineType")
                        ? localStorage.getItem("machineType")
                        : null,
                    localStorage.getItem("machineSubtype")
                        ? localStorage.getItem("machineSubtype")
                        : null,
                    localStorage.getItem("search")
                        ? localStorage.getItem("search")
                        : null,
                    localStorage.getItem("machComapny")
                        ? localStorage.getItem("machComapny")
                        : null,
                    page - 1
                )
            );
        }

        if (pageNo === "+") {
            dispatch(
                machineActions.getMachinelist(
                    localStorage.getItem("machineType")
                        ? localStorage.getItem("machineType")
                        : null,
                    localStorage.getItem("machineSubtype")
                        ? localStorage.getItem("machineSubtype")
                        : null,
                    localStorage.getItem("search")
                        ? localStorage.getItem("search")
                        : null,
                    localStorage.getItem("machComapny")
                        ? localStorage.getItem("machComapny")
                        : null,
                    page + 1
                )
            );
        }
    };

    const [page, setPage] = useState(1);

    const handlePageChange2 = (pageNo) => {
        setPage(pageNo);
        dispatch(
            machineActions.getMachinelist(
                localStorage.getItem("machineType")
                    ? localStorage.getItem("machineType")
                    : null,
                localStorage.getItem("machineSubtype")
                    ? localStorage.getItem("machineSubtype")
                    : null,
                localStorage.getItem("search")
                    ? localStorage.getItem("search")
                    : null,
                localStorage.getItem("machComapny")
                    ? localStorage.getItem("machComapny")
                    : null,
                pageNo
            )
        );
    };

    const renderPageNumbers = () => {
        const elements = [];
        let new_no_of_pages = 1;
        let page_start = 1;
        if (no_of_pages > 10) {
            page_start = page;
            new_no_of_pages += 8 + page;
            if (new_no_of_pages >= no_of_pages) {
                new_no_of_pages = no_of_pages;
            }
            let page_diff = no_of_pages - page_start;

            if (page_diff <= 9) {
                page_start = no_of_pages - 10;
            }
        } else {
            new_no_of_pages = no_of_pages;
        }

        for (let i = page_start; i <= new_no_of_pages; i++) {
            elements.push(
                <PaginationPageNum
                    key={i}
                    active={page === i}
                    onClick={() => handlePageChange2(i)}
                >
                    {i}
                </PaginationPageNum>
            );
        }
        return elements;
    };
    const dispatch = useDispatch();
    const machine_type = useSelector((state) => state.MachineList.machine_type);
    const machine_list = useSelector((state) => state.MachineList.machine_data);
    const no_of_pages = useSelector((state) => state.MachineList.no_of_pages);
    const machine_loading = useSelector(
        (state) => state.MachineList.machine_loading
    );
    const machine_sub_type = useSelector(
        (state) => state.MachineList.machine_sub_type
    );

    const [machineData, setMachineData] = useState(null);
    const [machinePopUp, setMachinePopUp] = useState(false);

    const openMachinePopUp = (machine_data) => {
        setMachinePopUp(true);
        setMachineData(machine_data);
    };

    const hideMachinePopUp = (type, is_deleted) => {
        setMachinePopUp(false);
        if (is_deleted) {
            dispatch(
                machineActions.getMachinelist(null, null, null, null, page)
            );
        }
    };
    const handleclosepopup = (rslt) => {
        setMachinePopUp(rslt);
    };

    useEffect(() => {
        localStorage.removeItem("machineType");
        localStorage.removeItem("machineSubtype");
        localStorage.removeItem("search");
        localStorage.removeItem("machComapny");
        dispatch(machineActions.getMachinelist(null, null, null, null, page));
        setReset(false);
    }, [reset]);

    return (
        <>
            {/* <NavBar /> */}
            <div className="App">
                <SideBar />
                {machinePopUp && (
                    // <MachinepopUp
                    // hideMachinePopUp={hideMachinePopUp}
                    // data={machineData}
                    // hidepopup={handleclosepopup}
                    // />
                    <MachinePopUp
                        ppmodal={true}
                        data={machineData}
                        hideMachinePopUp={handleclosepopup}
                    />
                )}

                <main className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row ">
                    <div className="col-sm-10 col-lg-10 col-xs-10 col-md-10 row border-box d-flex doc-wdth mx-auto ml-0 mr-0 mt-20 pl-0 pr-0 ">
                        <div className="main__container">
                            <div className="view-documentation__selects wdth-96 d-flex justify-content-center ">
                                <div className="machines__selects">
                                    <input
                                        className="search_input"
                                        type="search"
                                        placeholder={"SEARCH FOR ..."}
                                        onChange={(event) =>
                                            HandleSearchChange(
                                                event.target.value
                                            )
                                        }
                                        value={searchValue}
                                    />
                                </div>
                                {user_role !== undefined &&
                                    user_role !== false &&
                                    user_role === "CFO" && (
                                        <div
                                            title="CONTRACTOR"
                                            className={
                                                machine_loading &&
                                                `disabledbutton`
                                            }
                                        >
                                            <div className="">
                                                <SelectOptionDropDown
                                                    defaultText="CONTRACTOR"
                                                    optionsList={
                                                        companyList &&
                                                        companyList
                                                    }
                                                    updatePageNo={updatePageNo}
                                                    reset={reset}
                                                />
                                            </div>
                                        </div>
                                    )}
                                <div
                                    title="MACHINE TYPE"
                                    className={
                                        machine_loading && `disabledbutton`
                                    }
                                >
                                    <div className="hght">
                                        <SelectOptionDropDown
                                            className="select-options-height2"
                                            defaultText="MACHINE TYPE"
                                            optionsList={
                                                machine_type && machine_type
                                            }
                                            reset={reset}
                                            updatePageNo={updatePageNo}
                                            mchn="mchntype"
                                        />
                                    </div>
                                </div>
                                <div
                                    title="MACHINE SUBTYPE"
                                    className={
                                        localStorage.getItem("machineType") ===
                                            null || machine_loading
                                            ? " disabledbutton"
                                            : ""
                                    }
                                >
                                    <SelectOptionDropDown
                                        defaultText="MACHINE SUBTYPE"
                                        optionsList={
                                            machine_sub_type && machine_sub_type
                                        }
                                        reset={reset}
                                        updatePageNo={updatePageNo}
                                        mchn="mchntype"
                                    />
                                </div>
                                <div
                                    className={
                                        machine_loading && `disabledbutton`
                                    }
                                >
                                    <MDBBtn
                                        className="reset-btns rst-btn"
                                        onClick={HandleClearFilters}
                                    >
                                        Reset
                                    </MDBBtn>
                                </div>
                            </div>
                            {/* <div className="col-sm-8 col-lg-8 col-xs-8 col-md-8 d-flex mx-auto row mr-l-18 ">
                            <div className="col-sm-12 col-lg-3 col-xs-12 col-md-3">
                                <div className="machines__selects">
                                    <input
                                        className="search_input"
                                        type="search"
                                        placeholder={"SEARCH FOR ..."}
                                        updatePageNo={updatePageNo}
                                        onChange={(event) =>
                                            HandleSearchChange(event)
                                        }
                                    />
                                </div>
                            </div>
                            {user_role !== undefined &&
                                user_role !== false &&
                                user_role === "CFO" && (
                                    <div
                                        title="COMPANY"
                                        className={
                                            machine_loading
                                                ? "col-sm-12 col-lg-3 col-xs-12 col-md-3  machine-drop-down disabledbutton"
                                                : "col-sm-12 col-lg-3 col-xs-12 col-md-3  machine-drop-down"
                                        }
                                    >
                                        <SelectOptionDropDown
                                            defaultText="COMPANY"
                                            optionsList={
                                                companyList && companyList
                                            }
                                            updatePageNo={updatePageNo}
                                            reset={reset}
                                        />
                                    </div>
                                )}
                            <div
                                className={
                                    machine_loading
                                        ? "col-sm-12 col-lg-3 col-xs-12 col-md-3  machine-drop-down disabledbutton"
                                        : "col-sm-12 col-lg-3 col-xs-12 col-md-3  machine-drop-down"
                                }
                            >
                                <SelectOptionDropDown
                                    defaultText="TYPE"
                                    optionsList={machine_type && machine_type}
                                    reset={reset}
                                    updatePageNo={updatePageNo}
                                />
                            </div>
                            <div
                                className={
                                    localStorage.getItem("machineType") ===
                                        null || machine_loading
                                        ? "col-sm-12 col-lg-3 col-xs-12 col-md-3  machine-drop-down disabledbutton"
                                        : "col-sm-12 col-lg-3 col-xs-12 col-md-3  machine-drop-down"
                                }
                            >
                                <SelectOptionDropDown
                                    defaultText="SUB TYPE"
                                    optionsList={
                                        machine_sub_type && machine_sub_type
                                    }
                                    reset={reset}
                                    updatePageNo={updatePageNo}
                                />
                            </div>
                            <div className="col-sm-12 col-lg-1 col-xs-12 col-md-1">
                                <MDBBtn
                                    className="reset-btns"
                                    onClick={HandleClearFilters}
                                >
                                    Reset
                                </MDBBtn>
                            </div>
                        </div> */}

                            {machine_loading ? (
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mr-top80px  d-flex justify-content-center mt-4">
                                    <span className="fa fa-spinner fa-spin dataSourceLoader"></span>
                                </div>
                            ) : (
                                <>
                                    <div className="col-sm-11 col-lg-11 col-xs-11 col-md-11  row machines__documents2">
                                        {machine_list &&
                                        machine_list.length > 0 ? (
                                            machine_list.map((data) => (
                                                <div
                                                    className=" col-sm-4 col-lg-4 col-xs-4 col-md-4 document_wrapper  row"
                                                    onClick={() =>
                                                        openMachinePopUp(data)
                                                    }
                                                >
                                                    <div className="dsply-flex">
                                                        {/* {data.name === "Dozer" && (
                                                        <img
                                                            src={bulldozer}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "Articulated Dump Truck" && (
                                                        <img
                                                            src={
                                                                ArticulatedDumpTruck
                                                            }
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "BELL DUMPER ( B8 )" && (
                                                        <img
                                                            src={bulldozer}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}

                                                    {data.name ===
                                                        "Harvester" && (
                                                        <img
                                                            src={harvester}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "Telehandler" && (
                                                        <img
                                                            src={Telehandler}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "Backhoe Loader" && (
                                                        <img
                                                            src={BackhoeLoader}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "Hydraulic Excavator" && (
                                                        <img
                                                            src={Excavator}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "Steer Loader" && (
                                                        <img
                                                            src={SteerLoader}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "Single Man Lift" && (
                                                        <img
                                                            src={SingleManLift}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "Forklift" && (
                                                        <img
                                                            src={Forklift}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "Scissor Lift" && (
                                                        <img
                                                            src={Scissor}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )}
                                                    {data.name ===
                                                        "Simple Machine" && (
                                                        <img
                                                            src={SimpleMachine}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                    )} */}
                                                        {/* {data.name !==
                                                        "Articulated Dump Truck" ||
                                                        data.name !==
                                                            "Simple Machine" ||
                                                        data.name !==
                                                            "Scissor Lift" ||
                                                        data.name !==
                                                            "Forklift" ||
                                                        data.name !==
                                                            "Single Man Lift" ||
                                                        data.name !==
                                                            "Steer Loader" ||
                                                        data.name !==
                                                            "Backhoe Loader" ||
                                                        data.name !==
                                                            "Telehandler" || (
                                                            <img
                                                                src={
                                                                    ArticulatedDumpTruck
                                                                }
                                                                alt="icon"
                                                                className="machine-icon"
                                                            />
                                                        )} */}
                                                        <img
                                                            src={image}
                                                            alt="icon"
                                                            className="machine-icon"
                                                        />
                                                        <div className="machine-info">
                                                            <p className="document-text mr-b-10 m-0 p-0">
                                                                {
                                                                    data.vehicle_code
                                                                }
                                                            </p>
                                                            <p
                                                                className="document-text mr-b-10 m-0 p-0"
                                                                title={
                                                                    data.machine_type
                                                                }
                                                            >
                                                                {handleLongString(
                                                                    data.machine_type,
                                                                    20
                                                                )}
                                                            </p>

                                                            <p className="document-text mr-b-10 m-0 p-0">
                                                                {
                                                                    data.machine_sub_type
                                                                }
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))
                                        ) : (
                                            <>
                                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mr-top80px  d-flex justify-content-center mt-4"></div>
                                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mr-top80px  d-flex justify-content-center mt-4">
                                                    No data found
                                                </div>
                                            </>
                                        )}
                                    </div>
                                </>
                            )}
                        </div>
                        <div className="txt-cntr">
                            <PaginationCustom
                                onClickPrev={() => (
                                    setPage(page - 1), handlePageChange("-")
                                )}
                                onClickNext={() => (
                                    setPage(page + 1), handlePageChange("+")
                                )}
                                disabledPrev={page === 1}
                                disabledNext={page === no_of_pages}
                            >
                                {renderPageNumbers()}
                            </PaginationCustom>
                        </div>
                    </div>
                </main>
            </div>
        </>
    );
}

export default Machines;
