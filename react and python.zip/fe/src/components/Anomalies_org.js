import { useState, useEffect } from "react";
import NavBar from "./NavBar";
import { useDispatch, useSelector } from "react-redux";
import { anomalieActions } from "../store/actions/anomalies.actions";
import { MDBBtn } from "mdb-react-ui-kit";
import concIcon from "../assets/icons/conc.svg";
import doneIcon from "../assets/icons/done.svg";
import expirIcon from "../assets/icons/expir.svg";
import infoIcon from "../assets/icons/info.svg";
import pendIcon from "../assets/icons/pend.svg";
import warnIcon from "../assets/icons/warn.svg";
import DateRangePicker from "react-bootstrap-daterangepicker";
import "bootstrap-daterangepicker/daterangepicker.css";
import AnomaliesPopUp from "./AnomaliesPopUp";
import PaginationCustom from "./PaginationCustom";
import PaginationPageNum from "./PaginationPageNum";
import SelectOptionDropDown from "./SelectOptionDropDown";
import moment from "moment";
import { handleLongString } from "../helpers/Helper";
import redIcon from "../assets/icons/Urgent.png";
import yellowIcon from "../assets/icons/Not_urgent.png";
import greenIcon from "../assets/icons/Not_applicable.png";
import AnomalyPopUp from "./secondAnomaliesPopup";
import SideBar from "./SideBar";
function Anomalies() {
    const options = ["John Paul", "David Fincher", "Willie Engelbrecht"];
    const [page, setPage] = useState(1);
    const AnomaliesStatus = window.location.href.split("status=")[1];

    const updatePageNo = (newState) => {
        setPage(newState);
    };
    const companyList = [
        {
            label: "Red Top Asset Management",
            value: "Red Top Asset Management",
            type: "anmComapny",
        },
        {
            label: "Quartz Plant Hire",
            value: "Quartz Plant Hire",
            type: "anmComapny",
        },
        {
            label: "KLT Machinery and Plant Hire",
            value: "KLT Machinery and Plant Hire",
            type: "anmComapny",
        },
    ];
    const dispatch = useDispatch();
    const siteTypelist = useSelector((state) => state.AnomalieList.site_type);
    const documentList = useSelector(
        (state) => state.AnomalieList.document_type
    );
    const statuslist = useSelector((state) => state.AnomalieList.status);
    const anomalieslistloading = useSelector(
        (state) => state.AnomalieList.anomalie_loading
    );
    const anomalieData = useSelector(
        (state) => state.AnomalieList.anomalie_data
    );
    const auditsData = useSelector((state) => state.AnomalieList.audits_data);
    const no_of_pages = useSelector((state) => state.AnomalieList.no_of_pages);

    const [selectdMonth, setSelectdMonth] = useState(null);
    const [selectstatus, setSelectedStatus] = useState(null);
    const [anomalieDataList, setAnomalieData] = useState(null);
    const [siteType, setSiteType] = useState(null);
    const [docType, setDocType] = useState(null);
    const [statusType, setStatusType] = useState(null);
    const [selectedItem, setSelectedItem] = useState({});
    const [anomaliePopUp, setAnomaliePopUp] = useState(false);

    const openAnomaliePopUp = (anomalie_data) => {
        setAnomaliePopUp(true);
        setAnomalieData(anomalie_data);
    };

    const hideAnomaliePopUp = () => {
        setAnomaliePopUp(false);
    };

    const svg = (
        <svg
            width="40"
            height="28"
            viewBox="0 2 28 28"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                d="M9.8125 27.125L7.4375 23.0625L2.71875 22.0938L3.25 17.5L0.25 14L3.25 10.5312L2.71875 5.9375L7.4375 4.96875L9.8125 0.875L14 2.8125L18.1875 0.875L20.5938 4.96875L25.2812 5.9375L24.75 10.5312L27.75 14L24.75 17.5L25.2812 22.0938L20.5938 23.0625L18.1875 27.125L14 25.1875L9.8125 27.125ZM10.6562 24.6562L14 23.25L17.4375 24.6562L19.5312 21.5312L23.1875 20.5938L22.8125 16.875L25.3438 14L22.8125 11.0625L23.1875 7.34375L19.5312 6.46875L17.375 3.34375L14 4.75L10.5625 3.34375L8.46875 6.46875L4.8125 7.34375L5.1875 11.0625L2.65625 14L5.1875 16.875L4.8125 20.6562L8.46875 21.5312L10.6562 24.6562ZM12.6562 18.1562L19.75 11.125L18.3438 9.84375L12.6562 15.4688L9.6875 12.375L8.25 13.7812L12.6562 18.1562Z"
                fill="#1DAD2C"
            />
        </svg>
    );

    // const renderPageNumbers = () => {
    //     const elements = [];
    //     for (let i = 1; i <= no_of_pages; i++) {
    //         elements.push(
    //             <PaginationPageNum
    //                 key={i}
    //                 active={page === i}
    //                 onClick={() => setPage(i)}
    //             >
    //                 {i}
    //             </PaginationPageNum>
    //         );
    //     }
    //     return elements;
    // };

    const handlePageChange = (pageNo) => {
        if (pageNo === "-") {
            dispatch(
                anomalieActions.getAnomalielist(
                    localStorage.getItem("site")
                        ? localStorage.getItem("site")
                        : null,
                    localStorage.getItem("document")
                        ? localStorage.getItem("document")
                        : null,
                    localStorage.getItem("anm_status")
                        ? localStorage.getItem("anm_status")
                        : null,
                    localStorage.getItem("anm_start_date")
                        ? localStorage.getItem("anm_start_date")
                        : null,
                    localStorage.getItem("anm_end_date")
                        ? localStorage.getItem("anm_end_date")
                        : null,
                    localStorage.getItem("anmComapny")
                        ? localStorage.getItem("anmComapny")
                        : null,
                    page - 1
                )
            );
        }

        if (pageNo === "+") {
            dispatch(
                anomalieActions.getAnomalielist(
                    localStorage.getItem("site")
                        ? localStorage.getItem("site")
                        : null,
                    localStorage.getItem("document")
                        ? localStorage.getItem("document")
                        : null,
                    localStorage.getItem("anm_status")
                        ? localStorage.getItem("anm_status")
                        : null,
                    localStorage.getItem("anm_start_date")
                        ? localStorage.getItem("anm_start_date")
                        : null,
                    localStorage.getItem("anm_end_date")
                        ? localStorage.getItem("anm_end_date")
                        : null,
                    localStorage.getItem("anmComapny")
                        ? localStorage.getItem("anmComapny")
                        : null,
                    page + 1
                )
            );
        }
    };

    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState("");
    const [placeholder, setplaceholder] = useState("SELECT DATE");
    const handleCallback = (start, end, label) => {
        setPage(1);
        let s_date = null;
        let e_date = null;

        setStartDate(moment(start).format("YYYY-MM-DD"));
        s_date = moment(start).format("YYYY-MM-DD");
        setplaceholder(
            `${moment(start).format("YYYY-MM-DD")}~${moment(end).format(
                "YYYY-MM-DD"
            )} `
        );
        localStorage.setItem(
            "anm_start_date",
            moment(start).format("YYYY-MM-DD")
        );
        setEndDate(moment(end).format("YYYY-MM-DDY"));
        e_date = moment(end).format("YYYY-MM-DD");
        localStorage.setItem("anm_end_date", moment(end).format("YYYY-MM-DD"));
        dispatch(
            anomalieActions.getAnomalielist(
                localStorage.getItem("site")
                    ? localStorage.getItem("site")
                    : null,
                localStorage.getItem("document")
                    ? localStorage.getItem("document")
                    : null,
                localStorage.getItem("anm_status")
                    ? localStorage.getItem("anm_status")
                    : null,
                s_date,
                e_date,
                localStorage.getItem("anmComapny")
                    ? localStorage.getItem("anmComapny")
                    : null,
                1
            )
        );
    };
    const [reset, setReset] = useState(false);

    const HandleClearFilters = () => {
        setplaceholder("SELECT DATE");
        setReset(!reset);
        dispatch(
            anomalieActions.getAnomalielist(
                null,
                null,
                null,
                null,
                null,
                null,
                page
            )
        );
    };

    const handlePageChange2 = (pageNo) => {
        setPage(pageNo);
        anomalieActions.getAnomalielist(
            localStorage.getItem("site") ? localStorage.getItem("site") : null,
            localStorage.getItem("document")
                ? localStorage.getItem("document")
                : null,
            localStorage.getItem("anm_status")
                ? localStorage.getItem("anm_status")
                : null,
            localStorage.getItem("anm_start_date")
                ? localStorage.getItem("anm_start_date")
                : null,
            localStorage.getItem("anm_end_date")
                ? localStorage.getItem("anm_end_date")
                : null,
            localStorage.getItem("anmComapny")
                ? localStorage.getItem("anmComapny")
                : null,
            pageNo
        );
    };
    const renderPageNumbers = () => {
        const elements = [];
        let new_no_of_pages = 1;
        let page_start = 1;
        if (no_of_pages > 10) {
            page_start = page;
            new_no_of_pages += 8 + page;
            if (new_no_of_pages >= no_of_pages) {
                new_no_of_pages = no_of_pages;
            }
            let page_diff = no_of_pages - page_start;

            if (page_diff <= 9) {
                page_start = no_of_pages - 10;
            }
        } else {
            new_no_of_pages = no_of_pages;
        }

        for (let i = page_start; i <= new_no_of_pages; i++) {
            elements.push(
                <PaginationPageNum
                    key={i}
                    active={page === i}
                    onClick={() => handlePageChange2(i)}
                >
                    {i}
                </PaginationPageNum>
            );
        }
        return elements;
    };
    const handleclosepopup = (rslt) => {
        setAnomaliePopUp(rslt);
    };

    useEffect(() => {
        if (AnomaliesStatus) {
            dispatch(
                anomalieActions.getAnomalielist(
                    siteType,
                    docType,
                    "Urgent",
                    null,
                    null,
                    null,
                    page
                )
            );
        } else {
            dispatch(
                anomalieActions.getAnomalielist(
                    siteType,
                    docType,
                    statusType,
                    null,
                    null,
                    null,
                    page
                )
            );
        }
        localStorage.removeItem("site");
        localStorage.removeItem("document");
        localStorage.removeItem("anm_status");
        localStorage.removeItem("anm_start_date");
        localStorage.removeItem("anm_end_date");
        localStorage.removeItem("anmComapny");

        setReset(false);
    }, [reset]);
    return (
        <>
            {/* <NavBar /> */}
            <div className="App">
                <SideBar />

                {anomaliePopUp && (
                    // <AnomaliesPopUp
                    //     hideAnomaliePopUp={hideAnomaliePopUp}
                    //     data={anomalieDataList}
                    //     anomalie_data={anomalieData}
                    //     audit_data={auditsData}
                    // />
                    <AnomalyPopUp
                        ppmodal={true}
                        data={anomalieDataList}
                        anomalie_data={anomalieData}
                        hideAnomPopUp={handleclosepopup}
                    />
                )}
                <main className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row">
                    <div className="col-sm-10 col-lg-10 col-xs-10 col-md-10 row mr-0 ml-0 pr-0 pl-0 mt-20 border-box d-flex mx-auto wdth-90 ">
                        <div className="">
                            <div className="text-center mr-b-20 anomalies__title">
                                {svg} List of Anomalies
                            </div>
                            <div className="view-documentation__selects wdth-96 d-flex justify-content-center mx-auto">
                                <div
                                    className={
                                        anomalieslistloading
                                            ? `disabledbutton`
                                            : "custom-select-container_anom"
                                    }
                                    title="CONTRACTOR"
                                >
                                    <SelectOptionDropDown
                                        defaultText="CONTRACTOR"
                                        optionsList={companyList && companyList}
                                        PageNo={page}
                                        updatePageNo={updatePageNo}
                                        reset={reset}
                                    />
                                </div>
                                <div
                                    className={
                                        anomalieslistloading
                                            ? `disabledbutton`
                                            : "custom-select-container_anom"
                                    }
                                >
                                    <SelectOptionDropDown
                                        defaultText="STATUS"
                                        optionsList={statuslist && statuslist}
                                        reset={reset}
                                        PageNo={page}
                                        updatePageNo={updatePageNo}
                                    />
                                </div>

                                <div
                                    className={
                                        anomalieslistloading
                                            ? `disabledbutton`
                                            : `date-range `
                                    }
                                >
                                    <DateRangePicker
                                        onCallback={handleCallback}
                                    >
                                        <button
                                            type="button"
                                            className="  txt-alg-cntr custom-select-container_calendar"
                                        >
                                            {handleLongString(placeholder, 12)}
                                        </button>
                                    </DateRangePicker>
                                </div>
                                <div className="">
                                    <MDBBtn
                                        className="reset-btns-anom"
                                        onClick={HandleClearFilters}
                                    >
                                        Reset
                                    </MDBBtn>
                                </div>
                            </div>
                            <div className=" anomalies__selects width-73  mx-auto">
                                {/* <div className="custom-select-container_anom "> */}
                                {/*                                
                                <SelectOptionDropDown
                                    defaultText="SITE"
                                    optionsList={siteTypelist && siteTypelist}
                                    reset={reset}
                                /> */}
                                {/* </div> */}
                                {/* <div
                                className={
                                    anomalieslistloading
                                        ? `disabledbutton`
                                        : "custom-select-container_anom"
                                }
                                title="CONTRACTOR"
                            >
                                <SelectOptionDropDown
                                    defaultText="CONTRACTOR"
                                    optionsList={companyList && companyList}
                                    PageNo={page}
                                    updatePageNo={updatePageNo}
                                    reset={reset}
                                />
                            </div> */}
                                {/* <div
                                className={
                                    anomalieslistloading
                                        ? `disabledbutton`
                                        : "custom-select-container_anom"
                                }
                            >
                                <SelectOptionDropDown
                                    defaultText="STATUS"
                                    optionsList={statuslist && statuslist}
                                    reset={reset}
                                    PageNo={page}
                                    updatePageNo={updatePageNo}
                                />
                            </div> */}
                                {/* <div
                                className={
                                    anomalieslistloading
                                        ? `disabledbutton`
                                        : `date-range `
                                }
                            >
                                <DateRangePicker onCallback={handleCallback}>
                                    <button
                                        type="button"
                                        className="  txt-alg-cntr custom-select-container_calendar"
                                    >
                                        {handleLongString(placeholder, 12)}
                                    </button>
                                </DateRangePicker>
                            </div>
                            <div className="">
                                <MDBBtn
                                    className="reset-btns-anom"
                                    onClick={HandleClearFilters}
                                >
                                    Reset
                                </MDBBtn>
                            </div> */}
                            </div>
                            {anomalieslistloading ? (
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mr-top80px  d-flex justify-content-center mt-4">
                                    <span className="fa fa-spinner fa-spin dataSourceLoader mb50 "></span>
                                </div>
                            ) : (
                                <>
                                    <div className="col-sm-9 col-lg-8 col-xs-9 col-md-8 d-flex mr-b-50  mx-auto mt-20 row anomalies__items">
                                        {anomalieData &&
                                        anomalieData.length > 0 ? (
                                            anomalieData.map((data) => (
                                                <div
                                                    className=" col-sm-6 col-lg-6 col-xs-6 col-md-6 mr-b-10px crsr-pointer mr-b-15px row"
                                                    onClick={() =>
                                                        openAnomaliePopUp(data)
                                                    }
                                                >
                                                    <div className="dsply-flex ">
                                                        {/* {data.INV_PO_Price_Anomaly_Status ===
                                                    "Not Applicable" ? (
                                                        <button className="anm-status-btn-green"></button>
                                                    ) : null}
                                                    {data.INV_PO_Price_Anomaly_Status ===
                                                    "Urgent" ? (
                                                        <button className="anm-status-btn-red"></button>
                                                    ) : null}
                                                    {data.INV_PO_Price_Anomaly_Status ===
                                                    "Not Urgent" ? (
                                                        <button className="anm-status-btn-yellow"></button>
                                                    ) : null}
                                                    {data.INV_PO_Price_Anomaly_Status ===
                                                    "No Anomaly" ? (
                                                        <button className="anm-status-btn-green"></button>
                                                    ) : null}
                                                    {data.INV_PO_Price_Anomaly_Status !==
                                                        "No Anomaly" &&
                                                        data.INV_PO_Price_Anomaly_Status !==
                                                            "Not Urgent" &&
                                                        data.INV_PO_Price_Anomaly_Status !==
                                                            "Urgent" &&
                                                        data.INV_PO_Price_Anomaly_Status !==
                                                            "Not Applicable" && (
                                                            <button className="anm-status-btn-gray"></button>
                                                        )} */}
                                                        {/* {data.anomalies_status ===
                                                "pend" && ( */}
                                                        <img
                                                            src={
                                                                data.INV_PO_Price_Anomaly_Status ===
                                                                "Urgent"
                                                                    ? redIcon
                                                                    : data.INV_PO_Price_Anomaly_Status ===
                                                                      "Not Urgent"
                                                                    ? yellowIcon
                                                                    : data.INV_PO_Price_Anomaly_Status ===
                                                                      "no Anomaly"
                                                                    ? greenIcon
                                                                    : data.INV_PO_Price_Anomaly_Status ===
                                                                      "Not Applicable"
                                                                    ? greenIcon
                                                                    : null
                                                            }
                                                            alt="icon"
                                                            className="anomalies-img_wrapper anom-img"
                                                        />
                                                        {/* )} */}
                                                        {/* {data.anomalies_status ===
                                                "conc" && (
                                                <img
                                                    src={concIcon}
                                                    alt="icon"
                                                    className="anomalies-img_wrapper"
                                                />
                                            )}
                                            {data.anomalies_status ===
                                                "warn" && (
                                                <img
                                                    src={warnIcon}
                                                    alt="icon"
                                                    className="anomalies-img_wrapper"
                                                />
                                            )}
                                            {data.anomalies_status ===
                                                "done" && (
                                                <img
                                                    src={doneIcon}
                                                    alt="icon"
                                                    className="anomalies-img_wrapper"
                                                />
                                            )}
                                            {data.anomalies_status ===
                                                "info" && (
                                                <img
                                                    src={infoIcon}
                                                    alt="icon"
                                                    className="anomalies-img_wrapper"
                                                />
                                            )}
                                            {data.anomalies_status ===
                                                "expire" && (
                                                <img
                                                    src={expirIcon}
                                                    alt="icon"
                                                    className="anomalies-img_wrapper"
                                                />
                                            )} */}
                                                        <div className="anomalies-info">
                                                            <p className="anomalies-text p-0 m-0 anomalies_wrapper">
                                                                {data.reason}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))
                                        ) : (
                                            <>
                                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mr-top80px  d-flex justify-content-center mt-4">
                                                    <span className="mb50 ">
                                                        No data found
                                                    </span>
                                                </div>
                                            </>
                                        )}
                                    </div>
                                </>
                            )}
                        </div>
                        <div className="txt-cntr">
                            <PaginationCustom
                                onClickPrev={() => (
                                    setPage(page - 1), handlePageChange("-")
                                )}
                                onClickNext={() => (
                                    setPage(page + 1), handlePageChange("+")
                                )}
                                disabledPrev={page === 1}
                                disabledNext={page === no_of_pages}
                            >
                                {renderPageNumbers()}
                            </PaginationCustom>
                        </div>
                    </div>
                </main>
            </div>
        </>
    );
}

export default Anomalies;
