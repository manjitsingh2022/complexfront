import { useState, useEffect } from "react";
import NavBar from "./NavBar";
import Select from "react-select";
import { useDispatch, useSelector } from "react-redux";
import { documentActions } from "../store/actions/document.actions";
import { MDBBtn } from "mdb-react-ui-kit";
import quote from "../assets/icons/quote_icon.svg";
import timesheet from "../assets/icons/timesheet_icon.svg";
import po from "../assets/icons/po_icon.svg";
import invoice from "../assets/icons/invoice_icon.svg";
import po2 from "../assets/icons/image.png";
import pOPrder from "../assets/icons/pOrder.png";

import DocumentpopUp from "./documentPopUp";
import PaginationCustom from "./PaginationCustom";
import PaginationPageNum from "./PaginationPageNum";
import "react-month-picker/css/month-picker.css";
import SelectOptionDropDown from "./SelectOptionDropDown";
import moment from "moment";

import DateRangePicker from "react-bootstrap-daterangepicker";
import "bootstrap-daterangepicker/daterangepicker.css";
import "bootstrap/dist/css/bootstrap.css";
import { Placeholder } from "react-bootstrap";
import { handleLongString } from "../helpers/Helper";
import DocumentPopUp from "./secondDocumentPopup";
import SideBar from "./SideBar";
function ViewDocument() {
    const user_dt = useSelector((state) => state.users);

    const user_role =
        user_dt.items !== undefined && user_dt.items["role_detail"]["role"];

    const [reset, setReset] = useState(false);
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState("");
    const [placeholder, setplaceholder] = useState("SELECT DATE");
    const handleCallback = (start, end, label) => {
        setPage(1);
        let s_date = null;
        let e_date = null;

        setStartDate(moment(start).format("YYYY-MM-DD"));
        s_date = moment(start).format("YYYY-MM-DD");
        setplaceholder(
            `${moment(start).format("YYYY-MM-DD")}~${moment(end).format(
                "YYYY-MM-DD"
            )} `
        );
        localStorage.setItem("start_date", moment(start).format("YYYY-MM-DD"));
        setEndDate(moment(end).format("YYYY-MM-DDY"));
        e_date = moment(end).format("YYYY-MM-DD");
        localStorage.setItem("end_date", moment(end).format("YYYY-MM-DD"));
        dispatch(
            documentActions.getDocumentlist(
                localStorage.getItem("file_type")
                    ? localStorage.getItem("file_type")
                    : null,
                localStorage.getItem("docComapny")
                    ? localStorage.getItem("docComapny")
                    : null,
                localStorage.getItem("foreman")
                    ? localStorage.getItem("foreman")
                    : null,
                localStorage.getItem("doc-machine")
                    ? localStorage.getItem("doc-machine")
                    : null,
                1,
                s_date,
                e_date,
                localStorage.getItem("year")
                    ? localStorage.getItem("year")
                    : null
            )
        );
    };

    const dispatch = useDispatch();
    const doc_type_list = useSelector(
        (state) => state.DocumentList.doc_type_list
    );
    const mach_type_list = useSelector((state) => state.DocumentList.mach_list);
    const mach_sub_type_list = useSelector(
        (state) => state.DocumentList.mach_sub_list
    );
    const hire_type_list = useSelector((state) => state.DocumentList.hire_list);

    // const machineList = useSelector((state) => state.DocumentList.machine);
    const companylist = useSelector((state) => state.DocumentList.company);
    const companyList = [
        {
            label: "Red Top Asset Management",
            value: "Red Top Asset Management",
            type: "docComapny",
        },
        {
            label: "Quartz Plant Hire",
            value: "Quartz Plant Hire",
            type: "docComapny",
        },
        {
            label: "KLT Machinery and Plant Hire",
            value: "KLT Machinery and Plant Hire",
            type: "docComapny",
        },
    ];
    // const foremanList = useSelector((state) => state.DocumentList.foreman);
    const foremanList = [];
    const machineList = [];

    // const yearList = useSelector((state) => state.DocumentList.yearList);
    const yearList = [
        // { label: 1990, value: "1990", type: "year" },
        // { label: 1991, value: "1991", type: "year" },
        // { label: 1992, value: "1992", type: "year" },
        // { label: 1993, value: "1993", type: "year" },
        // { label: 1994, value: "1994", type: "year" },
        // { label: 1995, value: "1995", type: "year" },
        // { label: 1996, value: "1996", type: "year" },
        // { label: 1997, value: "1997", type: "year" },
        // { label: 1998, value: "1998", type: "year" },
        // { label: 1999, value: "1999", type: "year" },
        // { label: 2000, value: "2000", type: "year" },
        // { label: 2001, value: "2001", type: "year" },
        // { label: 2002, value: "2002", type: "year" },
        // { label: 2003, value: "2003", type: "year" },
        // { label: 2004, value: "2004", type: "year" },
        // { label: 2005, value: "2005", type: "year" },
        // { label: 2006, value: "2006", type: "year" },
        // { label: 2007, value: "2007", type: "year" },
        // { label: 2008, value: "2008", type: "year" },
        // { label: 2009, value: "2009", type: "year" },
        // { label: 2010, value: "2010", type: "year" },
        // { label: 2011, value: "2011", type: "year" },
        // { label: 2012, value: "2012", type: "year" },
        // { label: 2013, value: "2013", type: "year" },
        // { label: 2014, value: "2014", type: "year" },
        // { label: 2015, value: "2015", type: "year" },
        // { label: 2016, value: "2016", type: "year" },
        // { label: 2017, value: "2017", type: "year" },
        // { label: 2018, value: "2018", type: "year" },
        // { label: 2019, value: "2019", type: "year" },
        // { label: 2020, value: "2020", type: "year" },
        { label: 2021, value: "2021", type: "year" },
        { label: 2022, value: "2022", type: "year" },
        { label: 2023, value: "2023", type: "year" },
    ];
    const machineData = useSelector((state) => state.DocumentList.machine_data);
    const no_of_pages = useSelector((state) => state.DocumentList.no_of_pages);
    const audit_data = useSelector((state) => state.DocumentList.audit_data);
    const doc_data = useSelector((state) => state.DocumentList.data);
    const data_loading = useSelector(
        (state) => state.DocumentList.document_loading
    );

    const [selectdMonth, setSelectdMonth] = useState(null);
    const [fileType, setFiletype] = useState(null);
    const [companyType, setCompanyType] = useState(null);
    const [foremanType, setForemanType] = useState(null);
    const [machineType, setMachineType] = useState(null);
    const [documentdata, setDocumentdata] = useState(null);
    const [documentPopUp, setDocumentPopUp] = useState(false);
    const openDocumentPopUp = (document_data) => {
        setDocumentPopUp(true);
        setDocumentdata(document_data);
        localStorage.setItem("m-popup", true);
    };
    const hideDocumentPopUp = () => {
        setDocumentPopUp(false);
    };

    const [page, setPage] = useState(1);
    const updatePageNo = (newState) => {
        setPage(newState);
    };

    const handlePageChange2 = (pageNo) => {
        setPage(pageNo);
        dispatch(
            documentActions.getDocumentlist(
                localStorage.getItem("file_type")
                    ? localStorage.getItem("file_type")
                    : null,
                localStorage.getItem("docComapny")
                    ? localStorage.getItem("docComapny")
                    : null,
                foremanType,
                localStorage.getItem("doc-machine")
                    ? localStorage.getItem("doc-machine")
                    : null,
                pageNo,
                localStorage.getItem("start_date")
                    ? localStorage.getItem("start_date")
                    : null,
                localStorage.getItem("end_date")
                    ? localStorage.getItem("end_date")
                    : null,
                localStorage.getItem("year")
                    ? localStorage.getItem("year")
                    : null
            )
        );
    };

    const renderPageNumbers = () => {
        const elements = [];
        let new_no_of_pages = 1;
        let page_start = 1;
        if (no_of_pages > 10) {
            page_start = page;
            new_no_of_pages += 8 + page;
            if (new_no_of_pages >= no_of_pages) {
                new_no_of_pages = no_of_pages;
            }
            let page_diff = no_of_pages - page_start;

            if (page_diff <= 9) {
                page_start = no_of_pages - 10;
            }
        } else {
            new_no_of_pages = no_of_pages;
        }

        for (let i = page_start; i <= new_no_of_pages; i++) {
            elements.push(
                <PaginationPageNum
                    key={i}
                    active={page === i}
                    onClick={() => handlePageChange2(i)}
                >
                    {i}
                </PaginationPageNum>
            );
        }
        return elements;
    };
    const handlePageChange = (pageNo) => {
        if (pageNo === "-") {
            dispatch(
                documentActions.getDocumentlist(
                    localStorage.getItem("file_type")
                        ? localStorage.getItem("file_type")
                        : null,
                    localStorage.getItem("docComapny")
                        ? localStorage.getItem("docComapny")
                        : null,
                    foremanType,
                    localStorage.getItem("doc-machine")
                        ? localStorage.getItem("doc-machine")
                        : null,
                    page - 1,
                    localStorage.getItem("start_date")
                        ? localStorage.getItem("start_date")
                        : null,
                    localStorage.getItem("end_date")
                        ? localStorage.getItem("end_date")
                        : null,
                    localStorage.getItem("year")
                        ? localStorage.getItem("year")
                        : null
                )
            );
        }

        if (pageNo === "+") {
            dispatch(
                documentActions.getDocumentlist(
                    localStorage.getItem("file_type")
                        ? localStorage.getItem("file_type")
                        : null,
                    localStorage.getItem("docComapny")
                        ? localStorage.getItem("docComapny")
                        : null,
                    foremanType,
                    localStorage.getItem("doc-machine")
                        ? localStorage.getItem("doc-machine")
                        : null,
                    page + 1,
                    localStorage.getItem("start_date")
                        ? localStorage.getItem("start_date")
                        : null,
                    localStorage.getItem("end_date")
                        ? localStorage.getItem("end_date")
                        : null,
                    localStorage.getItem("year")
                        ? localStorage.getItem("year")
                        : null
                )
            );
        }
    };

    const HandleClearFilters = () => {
        setplaceholder("SELECT DATE");
        setReset(!reset);

        dispatch(
            documentActions.getDocumentlist(
                null,
                null,
                null,
                null,
                page,
                null,
                null,
                null
            )
        );
    };
    const handleclosepopup = (rslt) => {
        setDocumentPopUp(rslt);
    };

    useEffect(() => {
        dispatch(
            documentActions.getDocumentlist(
                fileType,
                companyType,
                foremanType,
                machineType,
                page,
                selectdMonth
            )
        );
        localStorage.removeItem("machine");
        localStorage.removeItem("doc-machine");
        localStorage.removeItem("docComapny");
        localStorage.removeItem("foreman");
        localStorage.removeItem("filetype");
        localStorage.removeItem("company");
        localStorage.removeItem("start_date");
        localStorage.removeItem("end_date");
        localStorage.removeItem("year");
        localStorage.removeItem("m-popup");
        setReset(false);
    }, [reset]);
    return (
        <>
            {" "}
            {/* <NavBar /> */}
            <div className="App">
                <SideBar />
                {documentPopUp && (
                    // <DocumentpopUp
                    //     hideDocumentPopUp={hideDocumentPopUp}
                    //     data={documentdata}
                    //     audit_data={audit_data}
                    // />
                    <DocumentPopUp
                        ppmodal={true}
                        data={documentdata}
                        hideDocPopUp={handleclosepopup}
                    />
                )}
                <main className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row p-0 m-0  m-top-40">
                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row mr-0 ml-0 pr-0 pl-0 mt-20 border-box d-flex mx-auto doc-wdth">
                        <div className="main__container">
                            <div className="view-documentation__selects wdth-96 d-flex justify-content-center ">
                                <div
                                    title="DATA TYPE"
                                    className={data_loading && `disabledbutton`}
                                >
                                    <SelectOptionDropDown
                                        defaultText="DATA TYPE"
                                        optionsList={
                                            doc_type_list && doc_type_list
                                        }
                                        reset={reset}
                                        updatePageNo={updatePageNo}
                                    />
                                </div>

                                {user_role !== undefined &&
                                    user_role !== false &&
                                    user_role === "CFO" && (
                                        <div
                                            title="COMPANY"
                                            className={
                                                data_loading && `disabledbutton`
                                            }
                                        >
                                            <div
                                                className=""
                                                title="CONTRACTOR"
                                            >
                                                <SelectOptionDropDown
                                                    defaultText="CONTRACTOR"
                                                    optionsList={
                                                        companyList &&
                                                        companyList
                                                    }
                                                    updatePageNo={updatePageNo}
                                                    reset={reset}
                                                />
                                            </div>
                                        </div>
                                    )}

                                <div
                                    title="MACHINE TYPE"
                                    className={data_loading && `disabledbutton`}
                                >
                                    <SelectOptionDropDown
                                        defaultText="MACHINE TYPE"
                                        optionsList={
                                            mach_type_list && mach_type_list
                                        }
                                        updatePageNo={updatePageNo}
                                        reset={reset}
                                    />
                                </div>
                                {/* <div className=" " title="MACHINE SUB TYPE">
                                <SelectOptionDropDown
                                    defaultText="MACHINE SUB TYPE"
                                    optionsList={
                                        mach_sub_type_list && mach_sub_type_list
                                    }
                                    reset={reset}
                                />
                            </div> */}
                                <div
                                    className={data_loading && `disabledbutton`}
                                >
                                    <SelectOptionDropDown
                                        defaultText="Year"
                                        optionsList={yearList && yearList}
                                        reset={reset}
                                        PageNo={page}
                                        updatePageNo={updatePageNo}
                                    />
                                </div>
                                <div
                                    className={
                                        data_loading
                                            ? `disabledbutton`
                                            : `date-range `
                                    }
                                >
                                    <DateRangePicker
                                        // initialSettings={{ showDropdowns: true }}
                                        onCallback={handleCallback}
                                    >
                                        <button
                                            type="button"
                                            className="  txt-alg-cntr custom-select-container_calendar"
                                        >
                                            {handleLongString(placeholder, 12)}
                                        </button>
                                    </DateRangePicker>
                                </div>
                                <div
                                    className={data_loading && `disabledbutton`}
                                >
                                    <MDBBtn
                                        className="reset-btns rst-btn"
                                        onClick={HandleClearFilters}
                                    >
                                        Reset
                                    </MDBBtn>
                                </div>
                            </div>

                            {data_loading ? (
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mr-top80px col d-flex justify-content-center mt-4">
                                    <span className="fa fa-spinner fa-spin dataSourceLoader"></span>
                                </div>
                            ) : (
                                <>
                                    <div className="col-sm-10 col-lg-10 col-xs-10 col-md-10  row view-documentation__documents">
                                        {doc_data && doc_data.length > 0 ? (
                                            doc_data.map((data) => (
                                                <div
                                                    className=" col-sm-3 col-lg-3 col-xs-3 col-md-3 p-0 m-0 document_wrapper"
                                                    onClick={() =>
                                                        openDocumentPopUp(data)
                                                    }
                                                >
                                                    <div className="document-img_wrapper">
                                                        {/* {data.file_type === 1 && ( */}
                                                        {/* <img
                                                        src={timesheet}
                                                        alt="icon"
                                                        className=""
                                                    /> */}
                                                        {/* )} */}
                                                        {/* {data.file_type === 2 && (
                                                        <img
                                                            src={quote}
                                                            alt="icon"
                                                            className=""
                                                        />
                                                    )} */}
                                                        {data.document_type ===
                                                            "Invoice" && (
                                                            <img
                                                                src={invoice}
                                                                alt="icon"
                                                                className=""
                                                            />
                                                        )}
                                                        {data.document_type ===
                                                            "Purchase Order" && (
                                                            <img
                                                                src={pOPrder}
                                                                alt="icon"
                                                                className="po-img"
                                                            />
                                                        )}
                                                    </div>
                                                    <div className="document-info">
                                                        <p className="document-text p-0 m-0 mr-b-5px mr-t-10">
                                                            {data.supplier_code}
                                                        </p>
                                                        <p className="document-text p-0 m-0 mr-b-5px">
                                                            {data.document_type}
                                                        </p>

                                                        <p className="document-text p-0 m-0 mr-b-5px">
                                                            {data.document_no}
                                                        </p>
                                                        <p className="document-text p-0 m-0 mr-b-5px">
                                                            {data.machine_type}
                                                        </p>
                                                    </div>
                                                </div>
                                            ))
                                        ) : (
                                            <>
                                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mr-top80px  d-flex justify-content-center mt-4"></div>
                                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mr-top80px  d-flex justify-content-center mt-4 rl-110 ">
                                                    No data found
                                                </div>
                                            </>
                                        )}
                                    </div>
                                </>
                            )}
                        </div>
                        <div className="txt-cntr">
                            <PaginationCustom
                                onClickPrev={() => (
                                    setPage(page - 1), handlePageChange("-")
                                )}
                                onClickNext={() => (
                                    setPage(page + 1), handlePageChange("+")
                                )}
                                disabledPrev={page === 1}
                                disabledNext={page === no_of_pages}
                            >
                                {renderPageNumbers()}
                            </PaginationCustom>
                        </div>
                    </div>
                </main>
            </div>
        </>
    );
}

export default ViewDocument;
