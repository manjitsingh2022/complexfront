import React, { useState, useEffect } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { anomalieActions } from "../store/actions/anomalies.actions";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";

function AnomalyPopUp(props) {
    const anomalie_data = props.data;
    const [anomaliePopUp, setAnomaliePopUp] = useState(true);
    const handleClose = () => {
        props.hideAnomPopUp(false);
        setAnomaliePopUp(false);
    };
    useEffect(() => {
        setAnomaliePopUp(props.ppmodal);
    }, []);

    return (
        <>
            <Modal show={anomaliePopUp} onHide={handleClose} size="xl">
                <Modal.Header closeButton>
                    <Modal.Title className="wdth-94">
                        <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 ">
                            <h4 className="txt-alg-cntr p-0 m-0">
                                Anomalies Details
                            </h4>
                        </div>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 mt15  d-flex justify-content-center row">
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">
                                Invoice-PO Price Difference
                            </h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INV_PO_Price_Difference ||
                                anomalie_data.INV_PO_Price_Difference === 0
                                    ? anomalie_data.INV_PO_Price_Difference
                                    : `N/A`}
                            </p>
                        </div>

                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">
                                Invoice Purchase Order Price Anomaly Indicator
                            </h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INV_PO_Price_Anomaly_Indicator ===
                                    false ||
                                anomalie_data.INV_PO_Price_Anomaly_Indicator ===
                                    true
                                    ? anomalie_data.INV_PO_Price_Anomaly_Indicator.toString()
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 ">
                            <h5 className="m-l-16px">
                                Invoice Purchase Order Price Anomaly Status
                            </h5>
                            <p className=" mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INV_PO_Price_Anomaly_Status
                                    ? anomalie_data.INV_PO_Price_Anomaly_Status
                                    : `N/A`}
                            </p>
                        </div>

                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">
                                Reason for Price Anomaly
                            </h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INV_PO_Price_Anomaly_Reason
                                    ? anomalie_data.INV_PO_Price_Anomaly_Reason
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Wet Day Rate</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.WetDayRate
                                    ? anomalie_data.WetDayRate
                                    : `N/A`}
                            </p>
                        </div>

                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Dry Day Rate</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.DryDayRate
                                    ? anomalie_data.DryDayRate
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">PO-Wet Rate Difference</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.PO_Wet_Rate_Difference
                                    ? anomalie_data.PO_Wet_Rate_Difference
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">PO-Dry Rate Difference</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.PO_Dry_Rate_Difference
                                    ? anomalie_data.PO_Dry_Rate_Difference
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Invoice Number</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INV_Invoice
                                    ? anomalie_data.INV_Invoice
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Invoice Date</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INV_InvoiceDate
                                    ? moment(
                                          anomalie_data.INV_InvoiceDate
                                      ).format("YYYY-MM-DD")
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Invoice Due Date</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INV_DueDate
                                    ? moment(anomalie_data.INV_DueDate).format(
                                          "YYYY-MM-DD"
                                      )
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Original Invoice Value</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INV_OrigInvValue
                                    ? anomalie_data.INV_OrigInvValue
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">
                                Invoice Transaction Value
                            </h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INVPay_TrnValue
                                    ? anomalie_data.INVPay_TrnValue
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">
                                Invoice Transaction Type
                            </h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INVPay_TrnType === "P" &&
                                    "Payment"}
                                {anomalie_data.INVPay_TrnType === "A" &&
                                    "Adjustment"}
                                {anomalie_data.INVPay_TrnType === "C" &&
                                    "Credit Note"}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Linked Document Number</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.INV_Reference
                                    ? anomalie_data.INV_Reference
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Purchase Order Number</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.PODet_PurchaseOrder
                                    ? anomalie_data.PODet_PurchaseOrder
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">
                                Purchase Order Entry Date
                            </h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.POHdr_OrderEntryDate
                                    ? moment(
                                          anomalie_data.POHdr_OrderEntryDate
                                      ).format("YYYY-MM-DD")
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">
                                Purchase Order Due Date
                            </h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.POHdr_OrderDueDate
                                    ? moment(
                                          anomalie_data.POHdr_OrderDueDate
                                      ).format("YYYY-MM-DD")
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">
                                Purchase Order Stock Code
                            </h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.PODet_MStockCode
                                    ? anomalie_data.PODet_MStockCode
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Purchase Order Price</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.PODet_MPrice
                                    ? anomalie_data.PODet_MPrice
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Machine Type</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.MachineType
                                    ? anomalie_data.MachineType
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Machine Subtype</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.MachineSubType
                                    ? anomalie_data.MachineSubType
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                            <h5 className="m-l-16px">Hire Type</h5>
                            <p className="mr-t-10 clr-gray m-l-16px">
                                {anomalie_data.HireType
                                    ? anomalie_data.HireType
                                    : `N/A`}
                            </p>
                        </div>
                        <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6"></div>
                    </div>
                </Modal.Body>
            </Modal>
        </>
    );
}

export default AnomalyPopUp;
