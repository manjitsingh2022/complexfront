import { useState } from "react";
import Select from "react-select";
import PrimaryBtn from "./PrimaryBtn";
import docTypeIcon from "../assets/images/document-type.svg";
import macTypeIcon from "../assets/images/machine-type.svg";
import yearIcon from "../assets/images/year.svg";

const documentType = [
    { value: "Purchase Order", label: "Purchase Order" },
    { value: "Invoice", label: "Invoice" },
];
const machineType = [
    { value: "FEL", label: "FEL" },
    { value: "Not Specified", label: "Not Specified" },
    { value: "WATER TANKER", label: "WATER TANKER" },
    { value: "ADT", label: "ADT" },
    { value: "EXCAVATOR", label: "EXCAVATOR" },
    { value: "DOZER", label: "DOZER" },
    { value: "GRADER", label: "GRADER" },
];
const yearType = [
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
];
const docPlaceholder = (
    <span>
        <img src={docTypeIcon} alt="doctype" />
        Document Type
    </span>
);
const macPlaceholder = (
    <span>
        <img src={macTypeIcon} alt="mactype" />
        Machine Type
    </span>
);
const yearPlaceholder = (
    <span>
        <img src={yearIcon} alt="year" />
        Year
    </span>
);
const DocumentDropdowns = () => {
    const [selectedDocumentOption, setDocumentSelectedOption] = useState(null);
    const [selectedMachineOption, setMachineSelectedOption] = useState(null);
    const [selectedYearOption, setYearSelectedOption] = useState(null);
    const dropdownStyle = {
        control: (baseStyles, state) => ({
            ...baseStyles,
            borderColor: state.isFocused ? "var(--primary-color)" : "#E6EAEF",
            "&:hover": {
                borderColor: state.isFocused
                    ? "var(--primary-color)"
                    : "#E6EAEF",
                cursor: "pointer",
            },
            borderRadius: "8px",
            boxShadow: state.isFocused
                ? "0 0 0 1px var(--primary-color)"
                : "none",
            height: "42px",
            paddingInline: "25px",
        }),
        indicatorSeparator: (baseStyles) => ({
            ...baseStyles,
            display: "none",
        }),
        placeholder: (baseStyles) => ({
            ...baseStyles,
            "& span": {
                display: "flex",
                alignItems: "center",
                gap: "8px",
            },
        }),
        indicatorContainer: (baseStyles) => ({
            ...baseStyles,
            padding: "0",
        }),
        menu: (baseStyles) => ({
            ...baseStyles,
            padding: "8px",
            background: "#FFFFFF",
            border: "1px solid #E6EAEF",
            boxShadow: "0px 8px 20px rgba(3, 11, 22, 0.08)",
            borderRadius: "8px",
        }),
        menuList: (baseStyles) => ({
            ...baseStyles,
            padding: "0",
        }),
        menuPortal: (baseStyles) => ({
            ...baseStyles,
            background: "var(--primary-color)",
        }),
        option: (baseStyles) => ({
            ...baseStyles,
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
            borderRadius: "8px",
            height: "44px",
            "&:before": {
                content: `''`,
                display: "block",
                width: "10px",
                height: "10px",
                marginRight: "12px",
                borderRadius: "100%",
                background: "#E6EAEF",
            },
            "&:hover": {
                background: "#F2F4F6",
                color: "var(--text-color)",
                cursor: "pointer",
            },
            "&:hover:before": {
                background: "var(--primary-color)",
            },
        }),
    };

    const resetAll = () => {
        setDocumentSelectedOption(null);
        setMachineSelectedOption(null);
        setYearSelectedOption(null);
    };

    return (
        <section className="dropdowns">
            <Select
                styles={dropdownStyle}
                value={selectedDocumentOption}
                onChange={setDocumentSelectedOption}
                options={documentType}
                placeholder={docPlaceholder}
            />
            <Select
                styles={dropdownStyle}
                value={selectedMachineOption}
                onChange={setMachineSelectedOption}
                options={machineType}
                placeholder={macPlaceholder}
            />
            <Select
                styles={dropdownStyle}
                value={selectedYearOption}
                onChange={setYearSelectedOption}
                options={yearType}
                placeholder={yearPlaceholder}
            />
            <PrimaryBtn onClick={resetAll} className="dropdowns__btn">
                Reset
            </PrimaryBtn>
        </section>
    );
};

export default DocumentDropdowns;
