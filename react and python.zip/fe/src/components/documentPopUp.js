import { useState, useRef, useEffect } from "react";
import {
    MDBBtn,
    MDBModal,
    MDBModalDialog,
    MDBModalContent,
    MDBModalBody,
    MDBModalFooter,
    MDBModalTitle,
    MDBModalHeader,
} from "mdb-react-ui-kit";
import docImg from "../assets/images/document.png";
import telData from "../assets/images/Telematics-data.png";
import telData2 from "../assets/images/Telematics-data-2.png";
import image1 from "../assets/icons/machines-img1.svg";
import AuditTable from "./DocumentAuditTable";
import quote from "../assets/icons/quote_icon.svg";
import timesheet from "../assets/icons/timesheet_icon.svg";
import po from "../assets/icons/po_icon.svg";
import invoice from "../assets/icons/invoice_icon.svg";
import { handleLongString } from "../helpers/Helper";
import moment from "moment";
import useOutsideClick from "./OutsideClick";
import { NonceProvider } from "react-select";

const DocumentpopUp = (props) => {
    const [documentPopUp, setDocumentPopUp] = useState(true);
    const stock_code = props.data.stock_code;
    const detail = props.data.detail;
    const pay_suplier = props.data.pay_suplier;
    const pay_invoice = props.data.pay_invoice;
    const hire_type = props.data.hire_type;
    // const pinCode = props.data.pin_code;
    // const startTime = props.data.start_time;
    // const endTime = props.data.end_time;
    // const odometer = props.data.odometer;
    // const fuel = props.data.Fuel;
    // const driver = props.data.driver;
    const doc_data = props.data;

    const auditsData = [
        { id: 1, what: "Mark", when: "Otto", who: "@mdo" },
        { id: 2, what: "David", when: "Ritt", who: "@ghs" },
        { id: 3, what: "Bob", when: "Dro", who: "@fzr" },
    ];

    const [viewdocumentPage, setViewDocumentPage] = useState(true);
    const [viewAuditPage, setViewAuditPage] = useState(false);
    const [viewTemplatePage, setViewTemplatePage] = useState(false);

    const HandleDocumentActive = () => {
        setViewDocumentPage(true);
        setViewAuditPage(false);
        setViewTemplatePage(false);
    };

    const HandleAuditActive = () => {
        setViewDocumentPage(false);
        setViewAuditPage(true);
        setViewTemplatePage(false);
    };

    const HandleTemplateActive = () => {
        setViewDocumentPage(false);
        setViewAuditPage(false);
        setViewTemplatePage(true);
    };

    const toggle = () => {
        setDocumentPopUp(false);
        props.hideDocumentPopUp(documentPopUp);
        // props.HandleCloseModel(true);
    };
    const ref = useRef();

    useOutsideClick(ref, () => {
        // if (documentPopUp === false) {
        //     alert("You clicked outside");
        // }
        // let d = null;
        // d = localStorage.getItem("m-popup");
        // if (d) {
        //     alert("You clicked outside");
        // }
        // props.hideDocumentPopUp(documentPopUp);
    });

    return (
        <MDBModal show={documentPopUp} setShow={documentPopUp}>
            <MDBModalDialog size="lg" ref={ref}>
                <MDBModalContent onClick={null}>
                    <MDBModalHeader>
                        <MDBModalTitle className="wdth-94">
                            <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 ">
                                <h4 className="txt-alg-cntr p-0 m-0">
                                    Finance Details
                                </h4>
                            </div>
                        </MDBModalTitle>
                        <MDBBtn
                            className="btn-close cls-btn"
                            color="none"
                            onClick={toggle}
                        ></MDBBtn>
                    </MDBModalHeader>
                    <MDBModalBody>
                        <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 ">
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row text-center p-0 m-0 mr-b-10px">
                                {/* <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 text-right">
                                    <img
                                        src={invoice}
                                        alt="icon"
                                        className="document-img_wrapper-2 </p>
                                        "
                                    />
                                </div> */}
                                {/* <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 text-left popup-head pt13">
                                    <p className="p-0 m-0 mr-top-4">
                                        {props.data.supplier_code}
                                    </p>
                                    <p className="p-0 m-0 mr-top-4">
                                        {props.data.document_type}
                                    </p>
                                    <p className="p-0 m-0 mr-top-4">
                                        {props.data.document_no}
                                    </p>

                                    <p className="p-0 m-0 mr-top-4">
                                        {props.data.invoice_date}
                                    </p>
                                    <p className="p-0 m-0 mr-top-4">
                                        {props.data.invoice_due}
                                    </p>
                                    <p className="p-0 m-0 mr-top-4">
                                        {props.data.org_value}
                                    </p>
                                    <p className="p-0 m-0 mr-top-4">
                                        {props.data.total_adjustment}
                                    </p>
                                    <p className="p-0 m-0 mr-top-4">
                                        {props.data.transaction}
                                    </p>

                                    <p className="p-0 m-0 mr-top-4">
                                        {props.data.linked_doc_no}
                                    </p>
                                </div> */}
                            </div>
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row">
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-3">
                                    {/* <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                        <p
                                            className={
                                                viewdocumentPage
                                                    ? "nav-selcted"
                                                    : "hover-underline-animation crsr-pointer "
                                            }
                                            onClick={HandleDocumentActive}
                                        >
                                            document
                                        </p>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                        <p
                                            className={
                                                viewAuditPage
                                                    ? "nav-selcted"
                                                    : "hover-underline-animation crsr-pointer "
                                            }
                                            onClick={HandleAuditActive}
                                        >
                                            Audits
                                        </p>
                                    </div> */}
                                    {/* <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                        <p
                                            className={
                                                viewTemplatePage
                                                    ? "nav-selcted"
                                                    : "hover-underline-animation crsr-pointer "
                                            }
                                            onClick={HandleTemplateActive}
                                        >
                                            Telematics data
                                        </p>
                                    </div> */}
                                </div>

                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 mt16 row  ">
                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                        <h5 className="m-l-16px">
                                            Supplier Code
                                        </h5>
                                        <p className="mr-t-10 clr-gray m-l-16px">
                                            {props.data.supplier_code
                                                ? props.data.supplier_code
                                                : `N/A`}
                                        </p>
                                    </div>
                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                        <h5 className="m-l-16px">Type</h5>
                                        <p className="mr-t-10 clr-gray m-l-16px">
                                            {props.data.document_type
                                                ? props.data.document_type
                                                : `N/A`}
                                        </p>
                                    </div>
                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                        <h5 className="m-l-16px">Number</h5>
                                        <p className="mr-t-10 clr-gray m-l-16px">
                                            {props.data.document_no
                                                ? props.data.document_no
                                                : `N/A`}
                                        </p>
                                    </div>
                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 ">
                                        <h5 className="m-l-16px">Date</h5>
                                        <p className=" mr-t-10 clr-gray m-l-16px">
                                            {props.data.invoice_date
                                                ? moment(
                                                      props.data.invoice_date
                                                  ).format("DD.MM.YYYY hh.mm A")
                                                : `N/A`}
                                        </p>
                                    </div>

                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                        <h5 className="m-l-16px">Due Date</h5>
                                        <p className="mr-t-10 clr-gray m-l-16px">
                                            {props.data.invoice_due
                                                ? moment(
                                                      props.data.invoice_due
                                                  ).format("DD.MM.YYYY hh.mm A")
                                                : `N/A`}
                                        </p>
                                    </div>
                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                        <h5 className="m-l-16px">
                                            Original Value
                                        </h5>
                                        <p className="mr-t-10 clr-gray m-l-16px">
                                            {props.data.org_value
                                                ? props.data.org_value
                                                : `N/A`}
                                        </p>
                                    </div>

                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                        <h5 className="m-l-16px">
                                            Adjustments
                                        </h5>
                                        <p className="mr-t-10 clr-gray m-l-16px">
                                            {props.data.total_adjustment
                                                ? props.data.total_adjustment
                                                : `N/A`}
                                        </p>
                                    </div>
                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                        <h5 className="m-l-16px">
                                            Transaction Type
                                        </h5>
                                        <p className="mr-t-10 clr-gray m-l-16px">
                                            {props.data.transaction
                                                ? props.data.transaction
                                                : `N/A`}
                                        </p>
                                    </div>

                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                        <h5 className="m-l-16px">
                                            Linked Document
                                        </h5>
                                        <p className="mr-t-10 clr-gray m-l-16px">
                                            {props.data.document_type
                                                ? props.data.document_type
                                                : `N/A`}
                                        </p>
                                    </div>
                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6">
                                        <h5 className="m-l-16px">
                                            Linked Document Number
                                        </h5>
                                        <p className="mr-t-10 clr-gray m-l-16px">
                                            {props.data.linked_doc_no
                                                ? props.data.linked_doc_no
                                                : `N/A`}
                                        </p>
                                    </div>
                                </div>

                                {viewTemplatePage && (
                                    <div className="col-sm-12 col-lg-9 col-xs-12 col-md-9  ">
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                            <img
                                                className="tel-data_img"
                                                src={telData}
                                                alt="telematics data"
                                            />
                                        </div>
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0 row">
                                            <div className="col-sm-12 col-lg-6 col-xs-12 col-md-6 p-0 m-0 mt-20">
                                                {/* <p className="p-0 m-0">
                                                    Start time : &nbsp;{" "}
                                                    {startTime}
                                                </p>
                                                <p className="p-0 m-0">
                                                    End time : &nbsp; {endTime}
                                                </p>
                                                <p className="p-0 m-0">
                                                    Odometer : &nbsp; {odometer}
                                                </p>
                                                <p className="p-0 m-0">
                                                    Driver : &nbsp; {driver}
                                                </p>
                                                <p className="p-0 m-0">
                                                    Fuel : &nbsp; {fuel}
                                                </p> */}
                                            </div>
                                            <div className="col-sm-12 col-lg-6 col-xs-12 col-md-6 p-0 m-0 mt-20">
                                                <img
                                                    className="tem-image-width tem-image-width2"
                                                    src={telData2}
                                                    alt="telematics data"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                )}
                                {viewAuditPage && (
                                    <div className="col-sm-12 col-lg-9 col-xs-12 col-md-9  ">
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 row m-0 audit-text">
                                            <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 text-center">
                                                <p className="mr-r-43"> What</p>
                                            </div>
                                            <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 text-center">
                                                <p> When</p>
                                            </div>
                                            <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 text-center">
                                                <p className="mr-l-74"> Who</p>
                                            </div>
                                        </div>
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                            <AuditTable data={auditsData} />
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </MDBModalBody>

                    {/* <MDBModalFooter>
                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0 close-btn3 mx-auto">
                            <MDBBtn className="close-btn2" onClick={toggle}>
                                Close
                            </MDBBtn>
                        </div>
                    </MDBModalFooter> */}
                </MDBModalContent>
            </MDBModalDialog>
        </MDBModal>
    );
};
export default DocumentpopUp;
