import { useEffect, useState } from "react";
import React from "react";
import { MDBContainer } from "mdbreact";
import NavBar from "./NavBar";
import { history } from "../helpers/history";
import Clock from "react-clock";
import ReactWeather, {
    useVisualCrossing,
    useWeatherBit,
} from "react-open-weather";
import { MDBIcon } from "mdb-react-ui-kit";
import "react-clock/dist/Clock.css";
import { userActions } from "../store/actions/user.actions";
import { machineActions } from "../store/actions/machine.action";
import { useDispatch, useSelector } from "react-redux";
import { timesheetActions } from "../store/actions/timeSheet.actions";
import moment from "moment";
import Nav from "react-bootstrap/Nav";
import weatherIcon from "../assets/images/weather.png";
import weatherIcon2 from "../assets/icons/soncevo-oblacno.png";
import { WeathertActions } from "../store/actions/weather.actions";
import axios from "axios";

const Dashboard = () => {
    let weathericon = "";
    let weathertemp = "";
    // let wind = "";
    // let windgusts = "";
    const [wind, setWind] = useState(null);
    const [windgusts, setWindgusts] = useState(null);

    const weatherdata = useSelector((state) => state.weatherReducer.data);

    const moveToTimesheet = (tm_url) => {
        window.location.assign(tm_url);
    };

    const moveToListTimesheet = (ltm_url) => {
        window.location.assign(ltm_url);
    };
    const sheetCounts = useSelector(
        (state) => state.getMessagesById.sheet_counts
    );
    const tdyDate = new Date();
    const crntDate = String(tdyDate.getDate()).padStart(2, "0");
    const crntMonth = tdyDate.toLocaleString("default", { month: "short" });
    const crntDay = tdyDate.toLocaleString("default", { weekday: "long" });

    const msgData = useSelector((state) => state.getMessagesById.data);
    const mchnMsgData = useSelector(
        (state) => state.getMachineMessagesById.data
    );
    const dispatch = useDispatch();
    const [clockValue, setClockValue] = useState(new Date());
    const [currentLat, setCurrentLat] = useState(null);
    const [currentLon, setCurrentLon] = useState(null);
    const [isWeather, setIsWeather] = useState(true);

    const user_dt = useSelector((state) => state.users);
    let widgetArr = [1, 2];

    const [wData, setWData] = useState(null);
    useEffect(() => {
        if (navigator.geolocation) {
            let weatherUnit = "metric";
            navigator.geolocation.getCurrentPosition((position) => {
                axios
                    .get(
                        `https://api.openweathermap.org/data/2.5/weather?lat=${position.coords.latitude}&lon=${position.coords.longitude}&appid=a7aec0005ad81a470818c6ecdd2c313b&units=${weatherUnit}`
                    )
                    .then((response) => {
                        setWData(response.data.wind);
                        setWind(response.data.wind["speed"]);
                        setWindgusts(response.data.wind["gust"]);
                    });
            });
        }

        dispatch(userActions.getUserData());
        // dispatch(WeathertActions.getCurrentWeather());

        if (user_dt) {
            dispatch(timesheetActions.getMessagesById());
            dispatch(machineActions.getMachineMessagesById());
        }

        history.push("/");

        const interval = setInterval(() => setClockValue(new Date()), 1000);

        return () => {
            clearInterval(interval);
        };

        // if (user_dt){

        // }
    }, [currentLat, currentLon]);

    return (
        <>
            <NavBar />
            <main className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row justify-content-center m-top-40">
                <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 p-0 m-0 text-center">
                    <span className="ml-2 ovrview-heading">
                        Welcome,{" "}
                        {user_dt.items !== undefined
                            ? user_dt.items.name.charAt(0).toUpperCase() +
                              user_dt.items.name.slice(1) +
                              " (" +
                              user_dt.items.role_detail.role +
                              ")"
                            : null}{" "}
                    </span>
                </div>
                <div className="col-sm-11 col-lg-11 col-xs-11 col-md-11 row justify-content-center border-box5 mr-btm-40 m-top-40 pd-0 pr-0 pl-0">
                    <div className="col-sm-9 col-lg-9 col-xs-9 col-md-9 row  ml-0  pl-0  ">
                        <MDBContainer>
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0 justify-content-center mt30 mb50 row">
                                <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 mt-3 crsr-pointer justify-content-center mx-auto d-flex txt-alg-cntr">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                                        <p
                                            className="cstm-inpt-text p-0 m-0 pd-top10 pl20 pr20 dshbd-head gry-clr"
                                            onClick={() => {
                                                moveToListTimesheet(
                                                    `/list-timesheet`
                                                );
                                            }}
                                        >
                                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                                Total Timesheets
                                                <i
                                                    className="fa fa-bars fnt-24 bar-icon flt-right"
                                                    aria-hidden="true"
                                                ></i>
                                            </div>
                                            <div className="row align-items-center justify-content-center">
                                                {/* <div className="col-5  text-center sheet-count icon-1 ">
                                                    <MDBIcon className="fa fa-file "></MDBIcon>
                                                </div> */}

                                                <div className="col-12 ">
                                                    <div className="row">
                                                        <div className="col-12 text-center  sheet-count">
                                                            {sheetCounts ? (
                                                                <p className="mt-4">
                                                                    {
                                                                        sheetCounts[
                                                                            "total_sheets"
                                                                        ]
                                                                    }
                                                                </p>
                                                            ) : (
                                                                <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {/* <div className="sheet-count mt-20">
                                            {sheetCounts ? (
                                                sheetCounts["total_sheets"]
                                            ) : (
                                                <span className=" mar-left-40-px fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                            )}
                                        </div> */}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 mt-3 crsr-pointer txt-alg-cntr justify-content-cente  mx-auto d-flex">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                                        <p
                                            className="cstm-inpt-text p-0 m-0 pd-top10 pl20 pr20 dshbd-head gry-clr"
                                            onClick={() => {
                                                moveToListTimesheet(
                                                    `/list-timesheet/?status=Approved`
                                                );
                                            }}
                                        >
                                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                                {/* <MDBIcon className="fas fa-check-square	"></MDBIcon>{" "} */}
                                                Approved Timesheets
                                                <i
                                                    className="fa fa-bars fnt-24 bar-icon flt-right"
                                                    aria-hidden="true"
                                                ></i>
                                            </div>
                                            <div className="row align-items-center justify-content-center">
                                                {/* <div className="col-5  text-center sheet-count icon-1 ">
                                                    <MDBIcon className="fa fa-check-square "></MDBIcon>
                                                </div> */}
                                                <div className="col-12">
                                                    <div className="row">
                                                        <div className="col-12 text-center  sheet-count">
                                                            {sheetCounts ? (
                                                                <p className="mt-4 ">
                                                                    {
                                                                        sheetCounts[
                                                                            "approved_sheets"
                                                                        ]
                                                                    }
                                                                </p>
                                                            ) : (
                                                                <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {/* <div className="sheet-count mt-20 ">
                                            {sheetCounts ? (
                                                sheetCounts["approved_sheets"]
                                            ) : (
                                                <span className=" mar-left-40-px fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                            )}
                                        </div> */}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0 justify-content-center mt30 mb50 row">
                                <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 mt-3 crsr-pointer justify-content-center mx-auto d-flex txt-alg-cntr">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                                        <p
                                            className="cstm-inpt-text p-0 m-0 pd-top10 pl20 pr20 dshbd-head gry-clr"
                                            onClick={() => {
                                                moveToListTimesheet(
                                                    `/list-timesheet/?status=Pending`
                                                );
                                            }}
                                        >
                                            {/* <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                            <MDBIcon className="fas fa-hourglass-half	"></MDBIcon>{" "}
                                            In Progress
                                        </div>
                                        <div className="sheet-count mt-20">
                                            {sheetCounts ? (
                                                sheetCounts["pending_sheets"]
                                            ) : (
                                                <span className=" mar-left-40-px fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                            )}
                                        </div> */}
                                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                                {/* <MDBIcon className="fas fa-check-square	"></MDBIcon>{" "} */}
                                                In Progress
                                                <i
                                                    className="fa fa-bars fnt-24 bar-icon flt-right"
                                                    aria-hidden="true"
                                                ></i>
                                            </div>
                                            <div className="row align-items-center justify-content-center">
                                                {/* <div className="col-5  text-center sheet-count icon-1 ">
                                                    <MDBIcon className="fa fa-hourglass-half"></MDBIcon>
                                                </div> */}
                                                <div className="col-12">
                                                    <div className="row">
                                                        <div className="col-12 text-center  sheet-count">
                                                            {sheetCounts ? (
                                                                <p className="mt-4">
                                                                    {
                                                                        sheetCounts[
                                                                            "pending_sheets"
                                                                        ]
                                                                    }
                                                                </p>
                                                            ) : (
                                                                <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                                <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 mt-3 crsr-pointer txt-alg-cntr justify-content-cente  mx-auto d-flex">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                                        <p
                                            className="cstm-inpt-text p-0 m-0 pd-top10 pl20 pr20  dshbd-head gry-clr"
                                            onClick={() => {
                                                moveToListTimesheet(
                                                    `/list-timesheet/?status=Request Clarification`
                                                );
                                            }}
                                        >
                                            {/* <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                            <MDBIcon className="fa fa-search"></MDBIcon>{" "}
                                            Request Clarification
                                        </div>
                                        <div className=" sheet-count mt-20">
                                            {sheetCounts ? (
                                                sheetCounts[
                                                    "clarification_sheets"
                                                ]
                                            ) : (
                                                <span className=" mar-left-40-px fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                            )}
                                        </div> */}
                                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                                {/* <MDBIcon className="fas fa-check-square	"></MDBIcon>{" "} */}
                                                Request Clarification
                                                <i
                                                    className="fa fa-bars fnt-24 bar-icon flt-right"
                                                    aria-hidden="true"
                                                ></i>
                                            </div>
                                            <div className="row align-items-center justify-content-center">
                                                {/* <div className="col-5  text-center sheet-count icon-1 ">
                                                    <MDBIcon className="fa fa-search"></MDBIcon>
                                                </div> */}
                                                <div className="col-12">
                                                    <div className="row">
                                                        <div className="col-12 text-center  sheet-count">
                                                            {sheetCounts ? (
                                                                <p className="mt-4">
                                                                    {
                                                                        sheetCounts[
                                                                            "clarification_sheets"
                                                                        ]
                                                                    }
                                                                </p>
                                                            ) : (
                                                                <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                                {/* <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 mt-3 crsr-pointer "> */}
                                {/* <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15  min-hgth-200 bg-clr"> */}{" "}
                                {/* </div> */}
                                {/* </div> */}
                                {/* <div className="col-sm-4 col-lg-4 col-xs-4 col-md-4 mt-3 crsr-pointer ">
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15  min-hgth-200 bg-clr">
                                    <p className="graph-head">Document Types</p>
                                    <div
                                        style={{
                                            height: "180px",
                                            width: "300px",
                                        }}
                                    >
                                        {graph_data && (
                                            <ResponsiveLine
                                                data={graph_data}
                                                margin={{
                                                    top: 0,
                                                    right: 10,
                                                    bottom: 30,
                                                    left: 30,
                                                }}
                                                xScale={{ type: "point" }}
                                                yScale={{
                                                    type: "linear",
                                                    min: "auto",
                                                    max: "auto",
                                                    stacked: true,
                                                    reverse: false,
                                                }}
                                                axisLeft={{
                                                    tickSize: 0,
                                                    tickPadding: 8,
                                                }}
                                                axisBottom={{
                                                    tickSize: 0,
                                                    tickPadding: 5,
                                                }}
                                                defs={[
                                                    {
                                                        id: "gradientC",
                                                        type: "linearGradient",
                                                        colors: [
                                                            // `{
                                                            //     offset: 0,
                                                            //     color: "#fdaf1e",
                                                            // },`
                                                            // {
                                                            //     offset: 100,
                                                            //     color: "#000",
                                                            // },
                                                        ],
                                                    },
                                                ]}
                                                fill={[
                                                    {
                                                        match: "*",
                                                        id: "gradientC",
                                                    },
                                                ]}
                                                stacked={true}
                                                lineWidth={4}
                                                pointSize={0}
                                                curve="basis"
                                                animate={true}
                                                enableGridY={false}
                                                enableGridX={false}
                                                colorBy={"id"}
                                                enableArea={true}
                                                areaBaselineValue={6}
                                                areaOpacity={0.1}
                                                motionStiffness={30}
                                                motionDamping={30}
                                                colors={"#fdaf1e"}
                                            />
                                        )}
                                    </div>
                                </div>
                            </div> */}
                                {/* {widgetArr.map((item, index) => (
                                <div
                                    className="col-sm-4 col-lg-4 col-xs-4 col-md-4 mt-3 crsr-pointer"
                                    key={index}
                                    id={item}
                                >
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15  min-hgth-200">
                                        <p className="cstm-inpt-text p-0 m-0 pd-top10 pl20 pr20">
                                            <MDBIcon className="fas fa-user-alt"></MDBIcon>
                                            <span className="pl5">
                                                BELL DUMPER ( B8 )
                                            </span>
                                        </p>
                                        <p className="cstm-inpt-text p-0 m-0 pt10 pl20 pr20">
                                            <MDBIcon className="fas fa-user-tie"></MDBIcon>
                                            <span className="pl5">
                                                SMART EARTHMOVING
                                            </span>
                                        </p>
                                        <p className="cstm-inpt-text p-0 m-0 pt10 pl20 pr20">
                                            <MDBIcon className="fas fa-user-alt"></MDBIcon>
                                            <span className="pl5">
                                                WILLIE ENGELBRECTH
                                            </span>
                                        </p>
                                        <p className="cstm-inpt-text p-0 m-0 pt10 pl20 pr20">
                                            <MDBIcon className="far fa-address-book"></MDBIcon>
                                            <span className="pl5">DW 3708</span>
                                        </p>
                                        <p className="cstm-inpt-text p-0 m-0 pt10 pl20 pr20">
                                            <MDBIcon className="fas fa-map-marker"></MDBIcon>
                                            <span className="pl5">10591</span>
                                        </p>
                                    </div>
                                </div>
                            ))}
                            <div
                                className="col-sm-4 col-lg-4 col-xs-4 col-md-4 mt-3 crsr-pointer"
                                title="Click here to add new template"
                            >
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15  text-center">
                                    <p className="cstm-inpt-text p-0 m-0 text-center top401">
                                        <MDBIcon className="fas fa-plus"></MDBIcon>
                                    </p>
                                </div>
                            </div> */}
                            </div>
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0 justify-content-center mt30 mb50 row">
                                <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 mt-3 crsr-pointer justify-content-center mx-auto d-flex txt-alg-cntr">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                                        <p
                                            className="cstm-inpt-text p-0 m-0 pd-top10 pl20 pr20 dshbd-head gry-clr"
                                            onClick={() => {
                                                moveToListTimesheet(
                                                    `/machines`
                                                );
                                            }}
                                        >
                                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                                Total Machines
                                                <i
                                                    className="fa fa-bars fnt-24 bar-icon flt-right"
                                                    aria-hidden="true"
                                                ></i>
                                            </div>
                                            <div className="row align-items-center justify-content-center">
                                                <div className="col-12 ">
                                                    <div className="row">
                                                        <div className="col-12 text-center  sheet-count">
                                                            {sheetCounts ? (
                                                                <p className="mt-4">
                                                                    {
                                                                        sheetCounts[
                                                                            "total_machines"
                                                                        ]
                                                                    }
                                                                </p>
                                                            ) : (
                                                                <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                                <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 mt-3 crsr-pointer txt-alg-cntr justify-content-cente  mx-auto d-flex">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 wdth-90 min-hgth-200">
                                        <p
                                            className="cstm-inpt-text p-0 m-0 pd-top10 pl20 pr20 dshbd-head gry-clr"
                                            onClick={() => {
                                                moveToListTimesheet(
                                                    `/view-document`
                                                );
                                            }}
                                        >
                                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 dshbd-head">
                                                Total Documents
                                                <i
                                                    className="fa fa-bars fnt-24 bar-icon flt-right"
                                                    aria-hidden="true"
                                                ></i>
                                            </div>
                                            <div className="row align-items-center justify-content-center">
                                                <div className="col-12">
                                                    <div className="row">
                                                        <div className="col-12 text-center  sheet-count">
                                                            {sheetCounts ? (
                                                                <p className="mt-4 ">
                                                                    {
                                                                        sheetCounts[
                                                                            "total_documents"
                                                                        ]
                                                                    }
                                                                </p>
                                                            ) : (
                                                                <span className="fa fa-spinner fa-spin dataSourceLoader fnt-35"></span>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </MDBContainer>
                    </div>
                    <div className="col-sm-3 col-lg-3 col-xs-3 col-md-3 row mr-0 ml-0 p-0 pl-0 m-t-l bg-clr pb30">
                        <MDBContainer className="bg-clr pr-0">
                            {/* <center>
                            <Clock className="mt-20" value={clockValue} />
                        </center> */}

                            {/* {isWeather && (
                            <div className="mt-3">
                                <ReactWeather
                                    isLoading={isLoading}
                                    errorMessage={errorMessage}
                                    data={data}
                                    lang="en"
                                    unitsLabels={{
                                        temperature: "C",
                                        windSpeed: "Km/h",
                                    }}
                                    showForecast
                                />
                            </div>
                        )} */}
                            <div className="col-sm-11 col-lg-11 col-xs-11 col-md-11 row d-flex mx-auto msg-box2">
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row d-flex mx-auto msg-box">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                        <p className="wthr-box">
                                            {crntDate} {crntMonth}, {crntDay}
                                        </p>
                                    </div>
                                    <div className="col-sm-5 col-lg-5 col-xs-5 col-md-5">
                                        <img
                                            src={weathericon}
                                            alt="icon"
                                            className="weather-icon"
                                        />
                                    </div>
                                    <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 m-0 p-0 ">
                                        <h3 className="temperature">
                                            {weathertemp}
                                            <img
                                                src={weatherIcon2}
                                                alt="icon"
                                                className="celsius-icon"
                                            />
                                        </h3>
                                    </div>
                                    <div className="col-sm-5 col-lg-5 col-xs-5 col-md-5">
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                            <p className="wind-title">Wind</p>
                                        </div>
                                    </div>
                                    <div className="col-sm-5 col-lg-5 col-xs-5 col-md-5">
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                            <p className="wthr-data">
                                                NW {wind} km/h
                                            </p>
                                        </div>
                                    </div>
                                    <div className="col-sm-5 col-lg-5 col-xs-5 col-md-5">
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                            <p className="wind-title">
                                                Wind Gusts
                                            </p>
                                        </div>
                                    </div>
                                    <div className="col-sm-5 col-lg-5 col-xs-5 col-md-5">
                                        <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12">
                                            <p className="wthr-data">
                                                {windgusts} km/h
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div className="mrg-top-btm"> </div>

                                {/* <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row">
                                    <div className="col-sm-10 col-lg-10 col-xs-10 col-md-10 pt21">
                                        <p className="wthr-box">
                                            {crntDate} {crntMonth}, {crntDay}
                                        </p>
                                    </div>
                                    <div className="col-sm-2 col-lg-2 col-xs-2 col-md-2 pt15">
                                        <i
                                            className="fa fa-bars fnt-24 bar-icon "
                                            aria-hidden="true"
                                        ></i>
                                    </div>
                                </div> */}
                                {/* <div className="col-sm-5 col-lg-5 col-xs-5 col-md-5">
                                    <img
                                        src={weatherIcon2}
                                        alt="icon"
                                        className="weather-icon"
                                    />
                                </div> */}
                                {/* <div className="col-sm-6 col-lg-6 col-xs-6 col-md-6 m-0 p-0 ">
                                    <span className="temperature">
                                        23{" "}
                                    
                                        <span className="celsius-icon">
                                            &deg;
                                        </span>{" "}
                                        C
                                    </span>
                                </div> */}
                                {/* <div className="col-sm-12 col-lg-12 col-xs-12  col-md-12 row">
                                    <div className="col-sm-5 col-lg-5 col-xs-5  col-md-5">
                                        <p className="wind-txt mr-l">Wind</p>
                                    </div>
                                    <div className="col-sm-7 col-lg-7 col-xs-7  col-md-7">
                                        <p className="wind-txt mr-l">
                                            NW 10 km/h
                                        </p>
                                    </div>
                                </div> */}
                                {/* <div className="col-sm-12 col-lg-12 col-xs-12  col-md-12 mr-t-10 row">
                                    <div className="col-sm-5 col-lg-5 col-xs-5  col-md-5">
                                        <p className="wind-txt mr-l ">
                                            Wind Gusts
                                        </p>
                                    </div>
                                    <div className="col-sm-7 col-lg-7 col-xs-7  col-md-7">
                                        <p className="wind-txt m-l-30px">
                                            20 km/h
                                        </p>
                                    </div>
                                </div> */}
                            </div>
                            {/* <div className="line col-lg-12 col-md-12 col-xs-12 col-sm-12">
                                {" "}
                                -------------------------------
                            </div> */}

                            <hr className="brdr-dash mb35" />

                            {msgData ? (
                                msgData.map((data) => (
                                    <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack msg-bx brdr-radius-15 ">
                                        <div className="col-sm-11 col-lg-11 col-xs-11 col-md-11 d-flex mx-auto msg-box">
                                            {" "}
                                            <div
                                                className="cstm-inpt-text p-0 m-0  top402"
                                                onClick={() => {
                                                    user_dt !== undefined &&
                                                    user_dt.items.role_detail
                                                        .role !== "Approver"
                                                        ? moveToTimesheet(
                                                              `/edit-timesheet/id=${data.timesheet}`
                                                          )
                                                        : moveToTimesheet(
                                                              `/list-timesheet/?id=${data.timesheet}`
                                                          );
                                                }}
                                            >
                                                <p className="msg-txt crsr-pointer">
                                                    {data.Message}
                                                    <br></br>@{" "}
                                                    {moment(
                                                        data.created_at
                                                    ).format(
                                                        "DD.MM.YYYY hh.mm A"
                                                    )}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 ">
                                    <p className="cstm-inpt-text p-0 m-0 text-center top402">
                                        No new Notification
                                    </p>
                                </div>
                            )}
                            {mchnMsgData &&
                                mchnMsgData.map((data) => (
                                    <div className=" col-sm-12 col-lg-12 col-xs-12 col-md-12 visualBack brdr-radius-15 ">
                                        <div className="col-sm-10 col-lg-10 col-xs-10 col-md-10 msg-box">
                                            {" "}
                                            <div
                                                className="cstm-inpt-text p-0 m-0  top402"
                                                // onClick={() => {
                                                //     user_dt !== undefined &&
                                                //     user_dt.items.role_detail
                                                //         .role !== "Approver"
                                                //         ? moveToTimesheet(
                                                //               `/edit-timesheet/id=${data.timesheet}`
                                                //           )
                                                //         : moveToTimesheet(
                                                //               `/list-timesheet/?id=${data.timesheet}`
                                                //           );
                                                // }}
                                            >
                                                <p className="msg-txt crsr-pointer">
                                                    {data.message}
                                                    <br></br>@{" "}
                                                    {moment(
                                                        data.created_at
                                                    ).format(
                                                        "DD.MM.YYYY hh.mm A"
                                                    )}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                        </MDBContainer>
                    </div>
                </div>
            </main>
        </>
    );
};

export default Dashboard;
