import { useRef, useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import NavBar from "./NavBar";
import { MDBContainer } from "mdbreact";
import { MDBBtn } from "mdb-react-ui-kit";
import { machineActions } from "../store/actions/machine.action";
import axios from "axios";
import * as config from "../config/config";
import getOptions from "../services/http.header";
import SideBar from "./SideBar";

const AddMachine = () => {
    const imei_list = useSelector((state) => state.getMachineImeiNo.imei_list);
    const imei_list_loading = useSelector(
        (state) => state.getMachineImeiNo.data_loading
    );
    const vechicles_data_loading = useSelector(
        (state) => state.getVehicleData.data_loading
    );
    const dataById = useSelector((state) => state.getMachineDataById.data);
    const selectedMachineid = window.location.href.split("id=")[1];
    // const [selectedMachineid, setSelectedMachineid] = useState(
    //     window.location.href.split("id=")[1]
    //         ? window.location.href.split("id=")[1]
    //         : null
    // );

    const [showMsg, setShowMsg] = useState(false);
    const user_dt = useSelector((state) => state.users);

    const type_list = useSelector((state) => state.getMachineType.type_list);
    const imei_list2 = useSelector((state) => state.getMachineType.imei_list);
    const v_codeListList = useSelector(
        (state) => state.getMachineType.v_codeListList
    );
    const datalist = useSelector((state) => state.getMachineType.data_list);

    const type_list_loading = useSelector(
        (state) => state.getMachineType.data_loading
    );
    const [typeListOpion, setTypeListOpion] = useState([]);

    const [imeiListOpion, setImeiListOpion] = useState([]);

    const addMachineMsg = useSelector((state) => state.AddMachine.msg);
    const addMachineLoading = useSelector(
        (state) => state.AddMachine.machine_loading
    );
    const addMachineCode = useSelector((state) => state.AddMachine.code);
    const vehiclesData = useSelector((state) => state.getVehicleData.data);

    const dispatch = useDispatch();
    const company =
        user_dt.items !== undefined && user_dt.items["company_name"];
    const [discription, setDiscription] = useState(null);
    const [machineMake, setMachinheMake] = useState(null);

    const [machineAge, setMachinheAge] = useState(null);
    const [machineModel, setMachinheModel] = useState(null);
    const [machineYear, setMachinheYear] = useState(null);
    const [machineType, setMachinheType] = useState(null);
    const [machineType2, setMachinheType2] = useState(null);
    const [vehicleCode, setVehicleCode] = useState(null);
    const [machineSubType, setMachinheSubType] = useState(null);
    const [imeiNo, setImeiNo] = useState(null);
    const [validationMessages, setValidationMessages] = useState([]);

    const [ImeiNames, setImeiNames] = useState([]);
    const [ImeiNames2, setImeiNames2] = useState(null);
    const [typeNames, setTypeNames] = useState([]);
    const [vehicleCodes, setVehicleCodes] = useState([]);
    const validYearRegex = /^(19|20)\d{2}$/;

    const handleTypeChange = (event) => {
        setImeiNames([]);
        setShowMsg(false);
        setMachinheType(event);
        setImeiNo("Select");
        // dispatch(machineActions.getMachineImeiNo(event));
        setMachinheMake(null);
        setMachinheYear(null);
        setMachinheModel(null);
        setMachinheAge(null);
        setVehicleCode(null);
        setDiscription(null);
        setMachinheSubType(null);

        if (event !== "Select") {
            setImeiNames((datalist) =>
                datalist.filter((val) => val["type"] === event)
            );
            let data = datalist;

            data = data
                .filter(function (item) {
                    return item.type === event;
                })
                .map(function ({ imei }) {
                    return { key: imei, value: imei };
                });
            data.splice(0, 0, { key: "Select", value: "Select" });
            setImeiNames(data);
        }
    };

    const handleVehicleCodeChange = (event) => {
        setShowMsg(false);
        let data = datalist;
        data = data
            .filter(function (item) {
                return item.v_code === event;
            })
            .map(function ({ subtype, model, make, year, age, type, imei }) {
                return {
                    subtype: subtype,
                    model: model,
                    make: make,
                    year: year,
                    age: age,
                    discription: null,
                    v_code: event,
                    type: type,
                    imei: imei,
                };
            });
        setMachinheMake(data[0]["make"]);
        setMachinheYear(data[0]["year"]);
        setMachinheModel(data[0]["model"]);
        setMachinheAge(data[0]["age"]);
        setVehicleCode(data[0]["v_code"]);
        setDiscription(null);
        setMachinheSubType(data[0]["subtype"]);
        setMachinheType2(data[0]["type"]);
        if (selectedMachineid) {
            setImeiNames2(data[0]["imei"]);
        }

        // if (event !== "Select") {
        //     setImeiNames((datalist) =>
        //         datalist.filter((val) => val["type"] === event)
        //     );
        //     let data = datalist;

        //     data = data
        //         .filter(function (item) {
        //             return item.type === event;
        //         })
        //         .map(function ({ imei }) {
        //             return { key: imei, value: imei };
        //         });
        //     data.splice(0, 0, { key: "Select", value: "Select" });
        //     setImeiNames(data);
        // }
    };

    const handleImeiNoChange = (event) => {
        setImeiNo(event);
        setShowMsg(false);
        let data = datalist;
        data = data
            .filter(function (item) {
                return item.imei === event && item.type === machineType;
            })
            .map(function ({ subtype, model, make, year, age, v_code }) {
                return {
                    subtype: subtype,
                    model: model,
                    make: make,
                    year: year,
                    age: age,
                    discription: null,
                    v_code: v_code,
                };
            });
        setMachinheMake(data[0]["make"]);
        setMachinheYear(data[0]["year"]);
        setMachinheModel(data[0]["model"]);
        setMachinheAge(data[0]["age"]);
        setVehicleCode(data[0]["v_code"]);
        setDiscription(null);
        setMachinheSubType(data[0]["subtype"]);
    };

    const [isDataById, setIsDataById] = useState(false);

    if (isDataById === false) {
        if (dataById) {
            setIsDataById(true);
        }
        if (dataById) {
            // setImeiNames([
            //     { key: dataById["imei_no"], value: dataById["imei_no"] },
            // ]);
            // setTypeNames([
            //     {
            //         key: dataById["machine_type"],
            //         value: dataById["machine_type"],
            //     },
            // ]);
            setVehicleCodes([
                {
                    key: dataById["vehicle_code"],
                    value: dataById["vehicle_code"],
                },
            ]);
            setImeiNames2(dataById["imei_no"]);
            setMachinheType2(dataById["machine_type"]);
            setMachinheMake(dataById["make"]);
            setMachinheAge(dataById["machine_age"]);
            setImeiNo(dataById["imei_no"]);
            setMachinheModel(dataById["model"]);
            setVehicleCode(dataById["vehicle_code"]);
            setDiscription(dataById["discription"]);
            setMachinheYear(dataById["year"]);
            setMachinheSubType(dataById["machine_sub_type"]);
            // setMachinheType2(data[0]["type"]);
            // setImeiNames2(data[0]["imei"]);
        }
    }

    const submit = () => {
        let dataDict = {
            vehicle_code: vehicleCode,
            global_vehicle_code: vehicleCode,
            plant: "",
            name: machineType,
            model: machineModel,
            make: machineMake,
            year: machineYear,
            contractor_company: company,
            machine_age: machineAge,
            discription: discription,
            imei_no: ImeiNames2,
            machine_sub_type: machineSubType,
            machine_type: machineType2,
        };

        let messages = [];

        if (!machineType2) {
            messages.push("Type is required");
        }
        if (!ImeiNames2) {
            messages.push("IMEI No is required");
        }

        if (!machineAge) {
            messages.push(" Age is required");
        }
        if (!machineMake) {
            messages.push(" Make is required");
        }
        if (!machineModel) {
            messages.push(" Model is required");
        }
        if (machineYear) {
            if (!validYearRegex.test(machineYear)) {
                messages.push("Please enter a valid year.");
            }
        }

        if (!machineYear) {
            messages.push(" Year is required");
        }
        if (!machineSubType) {
            messages.push(" Sub Type is required");
        }
        if (!vehicleCode) {
            messages.push(" Vehicle Code is required");
        }

        if (vehicleCode === "Select") {
            messages.push(" Vehicle Code is required");
        }

        if (messages.length > 0) {
            setShowMsg(true);
            const error_violation = document.getElementById("msg_div");
            window.scrollTo({
                top: error_violation.offsetTop,
                behavior: "smooth",
            });
            setValidationMessages(messages);
        } else {
            messages = [];
            dispatch(machineActions.addMachine(dataDict));
        }
    };
    useEffect(() => {
        // dispatch(machineActions.getMachineTypesAndSubtypes());
        if (selectedMachineid) {
            dispatch(machineActions.getMachineDataById(selectedMachineid));
        } else {
            // window.location.assign("/add-machine");
            dispatch(machineActions.getMachineType());
        }
    }, [selectedMachineid]);
    return (
        <>
            {/* <NavBar /> */}
            <div className="App">
                <SideBar />
                <main className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row">
                    <div className="col-sm-10 col-lg-10 col-xs-10 col-md-10 row mr-0 ml-0 pr-0 pl-0  mt-20 border-box d-flex mx-auto width-70">
                        <MDBContainer>
                            <div className="text-center mt-4 ">
                                <h2 className="text-center clr-gray">
                                    {selectedMachineid ? (
                                        <p className="p-0 m-0">
                                            Update Machine
                                        </p>
                                    ) : (
                                        <p className="p-0 m-0">Add Machine</p>
                                    )}
                                </h2>
                            </div>
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row p-0 m-0 d-flex justify-content-center clr-gray">
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row p-0 m-0 d-flex justify-content-center txt-alg-cntr clr-gray">
                                    {type_list_loading && (
                                        <>
                                            {" "}
                                            <span className="fa fa-spinner fa-spin"></span>
                                        </>
                                    )}
                                </div>
                            </div>
                            {/* {type_list_loading === false ||  (
                            <> */}
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row p-0 m-0 d-flex justify-content-center clr-gray">
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label htmlFor="order_number">
                                            Vehicle Code{" "}
                                        </label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        {/* <input
                                        className="input-style wdth-240"
                                        type="text"
                                        id="vehicle_code"
                                        name="vehicle_code"
                                        defaultValue={vehicleCode}
                                        disabled
                                        // onChange={(event) =>
                                        //     setVehicleCode(event.target.value)
                                        // }
                                    /> */}
                                        <select
                                            className="input-style wdth-240 select-wrapper "
                                            type="text"
                                            placeholder="Select"
                                            onChange={(event) =>
                                                handleVehicleCodeChange(
                                                    event.target.value
                                                )
                                            }
                                            // onChange={handleInputPOChange}
                                        >
                                            {selectedMachineid
                                                ? vehicleCodes.map(
                                                      (item, key) => (
                                                          <option
                                                              value={item.value}
                                                              key={key}
                                                          >
                                                              {item.value}
                                                          </option>
                                                      )
                                                  )
                                                : v_codeListList &&
                                                  v_codeListList.map(
                                                      (item, key) => (
                                                          <option
                                                              value={item.value}
                                                              key={key}
                                                          >
                                                              {item.value}
                                                          </option>
                                                      )
                                                  )}
                                        </select>
                                    </div>
                                </div>

                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label htmlFor="forman">IMEI NO</label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <input
                                            className="input-style"
                                            type="text"
                                            list="IMEI"
                                            defaultValue={ImeiNames2}
                                            onChange={(event) => (
                                                setImeiNames2(
                                                    event.target.value
                                                ),
                                                setShowMsg(false)
                                            )}
                                        />
                                        {/* <datalist id="IMEI">
                                        {imeiListOpion.map((item, index) => (
                                            <option value={item} key={index}>
                                                {item}
                                            </option>
                                        ))}
                                    </datalist> */}
                                        {/* <select
                                        className="input-style wdth-240"
                                        type="text"
                                        value={imeiNo}
                                        onChange={(event) =>
                                            handleImeiNoChange(
                                                event.target.value
                                            )
                                        }

                                        // onChange={handleInputPOChange}
                                    >
                                        {ImeiNames &&
                                            ImeiNames.map((item, key) => (
                                                <option
                                                    value={item.value}
                                                    key={key}
                                                >
                                                    {item.value}
                                                </option>
                                            ))}
                                    </select> */}
                                    </div>
                                </div>
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label htmlFor="order_number">
                                            Company{" "}
                                        </label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <input
                                            className="input-style wdth-240"
                                            type="text"
                                            id="Company"
                                            name="Company"
                                            value={company}
                                            disabled
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row p-0 m-0 d-flex justify-content-center clr-gray">
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label htmlFor="po"> Age</label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <input
                                            className="input-style5 wdth-240"
                                            type="Number"
                                            defaultValue={machineAge}
                                            onChange={(event) => (
                                                setMachinheAge(
                                                    event.target.value
                                                ),
                                                setShowMsg(false)
                                            )}
                                        />
                                    </div>
                                </div>
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label className="" htmlFor="invoice">
                                            Model
                                        </label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <input
                                            className="input-style"
                                            type="text"
                                            defaultValue={machineModel}
                                            onChange={(event) => (
                                                setMachinheModel(
                                                    event.target.value
                                                ),
                                                setShowMsg(false)
                                            )}
                                        />
                                    </div>
                                </div>
                                {/* <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                    <label className="" htmlFor="status">
                                        Plant
                                    </label>
                                </div>
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                    <input
                                        className="input-style"
                                        type="text"
                                        id="Plant"
                                        defaultValue={machinePlant}
                                        name="Plant"
                                        onChange={(event) =>
                                            setMachinhePlant(event.target.value)
                                        }
                                    />
                                </div>
                            </div> */}
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label htmlFor="company">Make</label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <input
                                            className="input-style"
                                            type="text"
                                            defaultValue={machineMake}
                                            onChange={(event) => (
                                                setMachinheMake(
                                                    event.target.value
                                                ),
                                                setShowMsg(false)
                                            )}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row p-0 m-0 d-flex justify-content-center clr-gray">
                                {/* <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                    <label htmlFor="po"> Type</label>
                                </div>
                                <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                    <select
                                        className="input-style wdth-240"
                                        type="text"
                                        onChange={(event) =>
                                            setMachinheType(event.target.value)
                                        }
                                        // onChange={handleInputPOChange}
                                    >
                                        {machine_types &&
                                            machine_types.map((item, key) => (
                                                <option
                                                    value={item.value}
                                                    key={key}
                                                >
                                                    {item.value}
                                                </option>
                                            ))}
                                    </select>
                                </div>
                            </div> */}
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label htmlFor="machine">Type</label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <input
                                            className="input-style wdth-240"
                                            type="text"
                                            list="types"
                                            defaultValue={machineType2}
                                            onChange={(event) => (
                                                setMachinheType2(
                                                    event.target.value
                                                ),
                                                setShowMsg(false)
                                            )}
                                            // onChange={handleInputTypeChange}
                                        />
                                        {/* <datalist id="types">
                                        {typeListOpion.map((item, index) => (
                                            <option value={item} key={index}>
                                                {item}
                                            </option>
                                        ))}
                                    </datalist> */}
                                        {/* <select
                                        className="input-style wdth-240"
                                        type="text"
                                        placeholder="Select"
                                        onChange={(event) =>
                                            handleTypeChange(event.target.value)
                                        }
                                        // onChange={handleInputPOChange}
                                    >
                                        {selectedMachineid
                                            ? typeNames.map((item, key) => (
                                                  <option
                                                      value={item.value}
                                                      key={key}
                                                  >
                                                      {item.value}
                                                  </option>
                                              ))
                                            : type_list &&
                                              type_list.map((item, key) => (
                                                  <option
                                                      value={item.value}
                                                      key={key}
                                                  >
                                                      {item.value}
                                                  </option>
                                              ))}
                                    </select> */}
                                    </div>
                                </div>
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label className="" htmlFor="invoice">
                                            Subtype
                                        </label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        {/* <select
                                        className="input-style"
                                        type="text"
                                        id="sub_type"
                                        name="sub_type"
                                        onChange={(event) =>
                                            setMachinheSubType(
                                                event.target.value
                                            )
                                        }
                                    >
                                        {machine_sub_type &&
                                            machine_sub_type.map(
                                                (item, key) => (
                                                    <option
                                                        value={item.value}
                                                        key={key}
                                                    >
                                                        {item.value}
                                                    </option>
                                                )
                                            )}
                                    </select> */}

                                        <input
                                            className="input-style"
                                            type="text"
                                            id="sub_type"
                                            name="sub_type"
                                            defaultValue={machineSubType}
                                            onChange={(event) => (
                                                setMachinheSubType(
                                                    event.target.value
                                                ),
                                                setShowMsg(false)
                                            )}
                                        />
                                    </div>
                                </div>
                                <div className="col-sm-12 col-lg-3 col-xs-12 col-md-12 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label className="" htmlFor="status">
                                            Year
                                        </label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <input
                                            className="input-style5"
                                            type="Number"
                                            id="year-input"
                                            maxlength="4"
                                            // id="Year"
                                            name="Year"
                                            defaultValue={machineYear}
                                            onChange={(event) => (
                                                setMachinheYear(
                                                    event.target.value
                                                ),
                                                setShowMsg(false)
                                            )}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 row p-0 m-0 d-flex justify-content-center clr-gray mrg-bt-60">
                                <div className="col-sm-9 col-lg-9 col-xs-9 col-md-9 p-0 m-0 mt-2 mb-2 ">
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <label htmlFor="order_number">
                                            Description{" "}
                                        </label>
                                    </div>
                                    <div className="col-sm-12 col-lg-12 col-xs-12 col-md-12 p-0 m-0">
                                        <textarea
                                            className="input-style4 wdth-95"
                                            type="text"
                                            id="discription"
                                            name="discription"
                                            placeholder="Type here ......"
                                            rows="3"
                                            onChange={(event) =>
                                                setDiscription(
                                                    event.target.value
                                                )
                                            }
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="col-sm-6 col-lg-12 col-xs-12 col-md-12  row mt-20">
                                <div className="col-sm-3 col-md-3 col-lg-3 col-xl-3 d-flex mx-auto text-center mr-b-10px">
                                    <MDBBtn
                                        onClick={() => submit()}
                                        className={"save-mach-btn"}
                                        type="submit"
                                        // disabled={!type_list_loading && true}
                                    >
                                        {addMachineLoading && (
                                            <span className="fa fa-spinner fa-spin"></span>
                                        )}{" "}
                                        {selectedMachineid
                                            ? `Update Machine`
                                            : `Save Machine `}
                                    </MDBBtn>
                                </div>
                            </div>
                            {/* </> */}
                            {/* )} */}
                            <div
                                className="clr-red col-sm-12 col-lg-12 col-xs-12 col-md-12 d-flex justify-content-center mt-20"
                                id="msg_div"
                            >
                                <ul>
                                    {showMsg &&
                                        validationMessages.map((vm) => (
                                            <li key={vm}>{vm}</li>
                                        ))}
                                </ul>
                            </div>
                            {addMachineMsg && addMachineLoading === false && (
                                <div>
                                    {addMachineCode &&
                                    addMachineCode === 200 ? (
                                        <p className="success-msg ">
                                            {addMachineMsg}
                                        </p>
                                    ) : (
                                        <p className="fail-msg">
                                            {addMachineMsg}
                                        </p>
                                    )}
                                </div>
                            )}
                        </MDBContainer>
                    </div>
                </main>
            </div>
        </>
    );
};
export default AddMachine;
