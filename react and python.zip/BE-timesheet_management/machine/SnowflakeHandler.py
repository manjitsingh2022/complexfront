
from snowflake.connector import connect as snow_connect
from sys import exc_info
from .serializers import MachineSerializer
from os import getenv
from logs.LogHandler import LogHelper

class SnowFlakeHelper():
    objLog = LogHelper('MachineSnowflake', 'SnowFlakeHelper')
    account_identifier = getenv("SNOWFLAKE_ACCOUNT")
    username = getenv("SNOWFLAKE_USERNAME")
    password = getenv("SNOWFLAKE_PASSWORD")
    db_name = getenv("SNOWFLAKE_DB_NEW")
    schema = getenv("SNOWFLAKE_SCHEMA_NEW")
    warehouse = getenv("SNOWFLAKE_WAREHOUSE_NEW")

    def remove_comma(self, val):
        # number_without_comma = val.replace(',', '')  # Remove comma
        # full_int = int(float(number_without_comma))
        converted_number = float(val.replace(',', ''))

        return converted_number

    def get_vehicles_Type(self, company):
        '''
        Method to get vehicles data
        '''

        try:
            type_list = [{"key": "Select", "value": "Select"}]
            vehicle_code_list = [{"label": "Select", "value": "Select"}]
            data_list = []
            data_result_dict = []
            data_machine_final = []
            imei_list = []
            dataDict = {}
            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()
            cs2 = ctx.cursor()

            try:

                cs.execute(
                    'SELECT * from "Vehicle_Master_Database" ')

                column_names = [column[0] for column in cs.description]
                data_rows = cs.fetchall()

                if data_rows:
                    for row in data_rows:
                        row_data = dict(zip(column_names, row))
                        data_result_dict.append(row_data)

                if data_result_dict:
                    _dict = {"key": "Select", "value": "Select"}
                    imei_list.append(_dict)
                    type_list.append(_dict)
                    vehicle_code_list.append(_dict)
                    for dt in data_result_dict:
                        if dt['Contractor Company'] == company:
                            data_dict = {
                                "v_code": dt['Vehicle_Code'],
                                "make": dt['Make'],
                                "model": dt['Model'],
                                "year": dt['Year'],
                                "age": dt['Machine Age'],
                                "subtype": dt['Machine Subtype'],
                                "type": dt['Machine Type'],
                                "imei": dt['IMEI number']
                                # "imei": self.remove_comma(row[1])
                            }
                            data_list.append(data_dict)

                            dct = {"key": dt['Machine Type'], "value": dt['Machine Type']}
                            if dct not in type_list:
                                type_list.append(dct)
                            dct2 = {"key": dt['IMEI number'], "value": dt['IMEI number']}
                            if dct2 not in imei_list:
                                imei_list.append(dct2)
                            dct3 = {"label": dt['Vehicle_Code'], "value": dt['Vehicle_Code']}
                            if dct3 not in vehicle_code_list:
                                vehicle_code_list.append(dct3)
                    dataDict = {"imeiList": imei_list, "v_codeListList": vehicle_code_list,
                                "typeList": type_list, "data_dict": data_list}

                return dataDict

            except:
                self.objLog.doLog(exc_info(), 'error')
                return dataDict

            finally:
                cs.close()
                ctx.close()
        except:
            self.objLog.doLog(exc_info(), 'error')
            pass

    def get_vehicles_Imei(self, company, selectedtype):
        '''
        Method to get vehicles data
        '''

        try:
            imei_list = []

            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()
            try:

                cs.execute(
                    'SELECT * from "Vehicle_Master_Database" ')
                data_rows = cs.fetchall()
                if data_rows:
                    dct = {"key": "", "value": ""}
                    imei_list.append(dct)
                    for row in data_rows:
                        if row[8] == company and row[6] == selectedtype:
                            dct = {"key": row[1], "value": row[1]}
                            if dct not in imei_list:
                                imei_list.append(dct)
                            # if row[0] not in imei_list:
                            #     dct = {"key": row[0], "value": row[0]}
                            #     imei_list.append(dct)

                    return imei_list

            except:
                self.objLog.doLog(exc_info(), 'error')
                return imei_list

            finally:
                cs.close()
            ctx.close()
        except:
            self.objLog.doLog(exc_info(), 'error')
            pass

    def get_vehicles_data(self, company, selectedtype, imeiNo):
        try:
            data_dict = {}
            data_result_dict = []
            data_machine_final = []
            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()
            try:

                cs.execute(
                    'SELECT * from "Vehicle_Master_Database" ')
                data_rows = cs.fetchall()

                if data_rows:
                    for row in data_rows:
                        if row[8] == company and row[6] == selectedtype and row[1] == imeiNo:
                            data_dict = {
                                "v_code": row[0],
                                "make": row[2],
                                "model": row[3],
                                "year": row[4],
                                "age": row[5],
                                "subtype": row[7],
                            }
                    return data_dict

            except:
                self.objLog.doLog(exc_info(), 'error')
                return data_dict

            finally:
                cs.close()
            ctx.close()
        except:
            self.objLog.doLog(exc_info(), 'error')
            pass


# def get_vehicles_data_by_id(self,id):
#         try:
#             data_dict = {}

#             ctx = snow_connect(
#                 user=self.username,
#                 password=self.password,
#                 account=self.account_identifier,
#                 database=self.db_name,
#                 warehouse=self.warehouse,
#                 schema=self.schema,
#                 autocommit=True
#             )
#             cs = ctx.cursor()
#             try:

#                 cs.execute(
#                     'SELECT * from "Vehicle_Master_Database" ')
#                 data_rows = cs.fetchall()
#                 if data_rows:
#                     for row in data_rows:
#                         if row[8] == company and row[6] == selectedtype and row[1] == imeiNo:
#                             data_dict = {
#                                 "v_code": row[0],
#                                 "make": row[2],
#                                 "model": row[3],
#                                 "year": row[4],
#                                 "age": row[5],
#                                 "subtype": row[7],


#                             }
#                     return data_dict

#             except:
#                 return data_dict

#             finally:
#                 cs.close()
#             ctx.close()
#         except:
#             pass


#     def insertData(self):
#         try:
#             doc_count = 0
#             ctx = snow_connect(
#                 user=self.username,
#                 password=self.password,
#                 account=self.account_identifier,
#                 database=self.db_name,
#                 warehouse=self.warehouse,
#                 schema=self.schema,
#                 autocommit=True
#             )
#             cs = ctx.cursor()
#             query = f'SELECT * from "Quartz_Machines" '
#             cs.execute(query)
#             data_rows = cs.fetchall()

#             mach_obj = MachineSerializer()
#             if data_rows:

#                 for data in data_rows:
#                     datadict = {"user_id": 1, "name": data[6], "machine_type": data[6], "machine_sub_type": data[7],
#                                 "plant": data[2], "vehicle_code": data[0], "vehicle_code": data[0], "imei_no": data[1], "make": data[2], "model": data[3], "year": data[4], "machine_age": data[5], "contractor_company": data[8]}
#                     mach_obj.create(datadict)

#         except:
#             from sys import exc_info
#             print("---->>>>", exc_info())


# obj = SnowFlakeHelper()
# obj.insertData()
