from django.urls import path

from .views import MachineData, MachineDataById, AddMachine, MachineTypesAndSubTypes, MachineMessageById, GetVehiclesType, GetVehiclesImei, GetVehiclesData, GetVehiclesDataById, DeleteVehiclesDataById

urlpatterns = [
    path('machine-data/', MachineData.as_view()),
    path('machine-data-by-id/', MachineDataById.as_view()),
    path('add-machine/', AddMachine.as_view()),
    path('get-machine-type/', GetVehiclesType.as_view()),
    path('get-machine-imei/', GetVehiclesImei.as_view()),
    path('get-machine-message-by-id/', MachineMessageById.as_view()),
    path('get-vehicle-data/', GetVehiclesData.as_view()),
    path('get-vehicle-data-by-id/', GetVehiclesDataById.as_view()),
    path('delete-vehicle-data/', DeleteVehiclesDataById.as_view())


]
