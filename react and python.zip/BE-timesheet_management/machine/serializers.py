"""Machine app's serilizers"""

from rest_framework import serializers
from .models import MachineType, MachineSubType, MachineMessage, MachineSecond


class MachineSerializer(serializers.ModelSerializer):
    """Machine table's serializer"""
    class Meta:
        model = MachineSecond
        fields = ('user', 'id', 'machine_type', 'machine_sub_type', 'name', 'plant', 'discription', 'vehicle_code',
                  'imei_no', 'make', 'model', 'year', 'machine_age', 'contractor_company', 'global_vehicle_code')


class MachineTypeSerializer(serializers.ModelSerializer):
    """MachineType table's serializer"""
    class Meta:
        model = MachineType
        fields = ('user', 'machine_type')


class MachineSubTypeSerializer(serializers.ModelSerializer):
    """MachineSubType table's serializer"""
    class Meta:
        model = MachineSubType
        fields = ('user', 'machine_type', 'machine_sub_type')


class MachineMessageSerializer(serializers.ModelSerializer):
    """MachineMessage table's serializer"""
    class Meta:
        model = MachineMessage
        fields = ('user', 'machine', 'message', 'assign_to', 'is_deleted', 'type')
