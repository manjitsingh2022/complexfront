from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from baseapp.utils import formatResponse
from rest_framework.permissions import IsAuthenticated
from .serializers import MachineTypeSerializer, MachineSubTypeSerializer, MachineSerializer, MachineMessageSerializer
from .models import Machine, MachineSubType, MachineType, MachineMessage, MachineSecond
from django.db.models import Q
from .SnowflakeHandler import SnowFlakeHelper
from logs.LogHandler import LogHelper
from sys import exc_info

class MachineData(APIView):

    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'MachineData')

    def get(self, request):
        '''
        Method to get machine data
        :param request:
        :return:
        '''
        data_dict = {}
        machine_type = None
        machine_sub_type = None
        machine = []
        type_list = []
        sub_type_list = []
        machine_query = None
        no_of_pages = 1
        total_count = 0
        try:

            selectedtype = request.GET.get('selectedtype', None)
            selectedSubtype = request.GET.get('selectedSubtype', None)
            searchItem = request.GET.get('searchItem', None)
            selectedComapny = request.GET.get('selectedComapny', None)
            page = int(request.GET.get('page', None))
            user = request.user.id
            user_role = request.user.role.role
            user_comp = request.user.company_name
            upto = 12 * page
            offset = 0
            query = None

            try:
                if page == 0 or page == 1:
                    offset = 0
                else:
                    offset = (page - 1) * 12

            except:
                pass

            if selectedtype != 'undefined' and selectedtype != 'null' and selectedtype != None and selectedtype != '':
                query = Q(machine_type=selectedtype)

            if selectedSubtype != 'undefined' and selectedSubtype != 'null' and selectedSubtype != None and selectedSubtype != '':
                if query != None:
                    query.add((Q(machine_sub_type=selectedSubtype)), query.connector)
                else:
                    query = (Q(machine_sub_type=selectedSubtype))

            if searchItem != 'undefined' and searchItem != 'null' and searchItem != None and searchItem != '':
                if query != None:
                    query.add((Q(machine_sub_type__icontains=searchItem) | Q(
                        machine_type__icontains=searchItem) | Q(
                        vehicle_code__icontains=searchItem)), query.connector)
                else:
                    query = (Q(machine_sub_type__icontains=searchItem) | Q(machine_type__icontains=searchItem) | Q(
                        vehicle_code__icontains=searchItem))

            if selectedComapny != 'undefined' and selectedComapny != 'null' and selectedComapny != None and selectedComapny != '':
                if query != None:
                    query.add((Q(contractor_company=selectedComapny)), query.connector)
                else:
                    query = (Q(contractor_company=selectedComapny))
            if query:
                if user_role != "CFO" and user_role != "Approver":
                    machine_query = MachineSecond.objects.filter(
                        query, contractor_company=user_comp).order_by('-created_at')[offset:upto]

                    total_count = MachineSecond.objects.filter(
                        query, contractor_company=user_comp).count()

                else:
                    machine_query = MachineSecond.objects.filter(
                        query).order_by('-created_at')[offset:upto]

                    total_count = MachineSecond.objects.filter(
                        query).count()
            else:
                if user_role != "CFO" and user_role != "Approver":
                    machine_query = MachineSecond.objects.filter(
                        contractor_company=user_comp).order_by('-created_at')[offset:upto]

                    total_count = MachineSecond.objects.filter(
                        contractor_company=user_comp).count()
                else:
                    machine_query = MachineSecond.objects.filter(
                    ).order_by('-created_at')[offset:upto]
                    total_count = MachineSecond.objects.filter().count()

            try:
                ms_obj = MachineSerializer(machine_query, many=True)
                machine = ms_obj.data
            except:
                machine = []
            try:
                if user_role == 'CFO' or user_role == 'Approver':
                    mt_obj = MachineSecond.objects.filter().values_list(
                        'machine_type', flat=True).distinct()
                else:
                    mt_obj = MachineSecond.objects.filter(contractor_company=user_comp).values_list(
                        'machine_type', flat=True).distinct()

                if mt_obj:
                    for x in mt_obj:
                        type_list.append({'label': x, 'value': x, 'type': 'machineType'})

            except:
                pass

            try:

                if user_role == 'CFO' or user_role == 'Approver':
                    mts_obj = MachineSecond.objects.filter().values_list(
                        'machine_sub_type', flat=True).distinct()
                
                else:
                    mts_obj = MachineSecond.objects.filter(contractor_company=user_comp).values_list(
                        'machine_sub_type', flat=True).distinct()
                if mts_obj:
                    for x in mts_obj:
                        if x != None and x != " ":
                            sub_type_list.append({'label': x, 'value': x, 'type': 'machineSubtype'})

            except:
                pass
            try:

                if total_count > 12:
                    pages = total_count/12
                    remainder = int(total_count % 12)
                    if remainder > 0:
                        no_of_pages = int(pages) + 1
                    else:
                        no_of_pages = pages
                else:
                    no_of_pages = 1
            except:
                no_of_pages = 1

            if offset == 0:
                offset = 1

            if upto > total_count:
                upto = total_count

            data_dict = {'machine_data': machine, 'machine_type': type_list,
                         'machine_sub_type': sub_type_list, "no_of_pages": no_of_pages, "total_count": total_count, "offset": offset, "upto": upto}
            return Response(formatResponse('Machine data found', 'success', data_dict,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))

    # def post(self, request):
    #     '''
    #     Method to save machine data
    #     :param request:
    #     :return:
    #     '''
    #     try:
    #         data_set = dict(request.data)
    #         user = request.user.id

    #         if data_set:

    #             machine_type = data_set['machine_type']
    #             machine = data_set['machine']
    #             machine_sub_type = data_set['machine_sub_type']

    #             if machine_type['machine_type'] == 'null' or machine_type['machine_type'] == "":
    #                 return Response(formatResponse('Machine type is required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))

    #             if machine_sub_type['machine_sub_type'] == 'null' or machine_sub_type['machine_sub_type'] == "":
    #                 return Response(formatResponse('Machine sub type is required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))

    #             if machine['name'] == 'null' or machine['name'] == "":
    #                 return Response(formatResponse('Machine name required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))

    #             if machine['vehicle_code'] == 'null' or machine['vehicle_code'] == "":
    #                 return Response(formatResponse('vehicle code required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))

    #             m_type_obj = MachineTypeSerializer()
    #             machine_type['user_id'] = user
    #             m_type_data = m_type_obj.create(machine_type)
    #             if m_type_data:
    #                 m_sub_type_obj = MachineSubTypeSerializer()
    #                 machine_sub_type['user_id'] = user
    #                 machine_sub_type['machine_type_id'] = m_type_data.id
    #                 m_sub_type_data = m_sub_type_obj.create(machine_sub_type)

    #                 if m_sub_type_data:
    #                     machine['user_id'] = user
    #                     machine['machine_type_id'] = m_type_data.id
    #                     machine['machine_sub_type_id'] = m_sub_type_data.id
    #                     m_obj = MachineSerializer()
    #                     m_obj.create(machine)

    #                     return Response(formatResponse('Machine data saved', 'success', data_set,
    #                                                    status.HTTP_200_OK))

    #     except:
    #         return Response(formatResponse('Internal Server Error', 'error', None,
    #                                        status.HTTP_500_INTERNAL_SERVER_ERROR))


class MachineDataById(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'MachineDataById')

    def get(self, request):
        '''
        Method to get machine data by id
        :param request:
        :return:
        '''
        machine_id = request.GET.get("machine_id", None)
        user_id = request.user.id
        machine_data = None
        machine_type_data = None
        machine_sub_type_data = None
        data_dict = {}
        try:
            if machine_id:
                m_obj = Machine.objects.get(id=machine_id, user=user_id)
                if m_obj:
                    m_serial = MachineSerializer(m_obj)
                    machine_data = m_serial.data
                    if machine_data:
                        mch_type_obj = MachineType.objects.get(id=machine_data['machine_type'])
                        mch_type_serial = MachineTypeSerializer(mch_type_obj)
                        machine_type_data = mch_type_serial.data

                        mch_sub_type_obj = MachineSubType.objects.get(
                            id=machine_data['machine_sub_type'])
                        mch_sub_type_serial = MachineSubTypeSerializer(mch_sub_type_obj)
                        machine_sub_type_data = mch_sub_type_serial.data
                        data_dict = {"machine": machine_data, "machine_type": machine_type_data,
                                     "machine_sub_type": machine_sub_type_data}

                        return Response(formatResponse('Machine data found', 'success', data_dict,
                                                       status.HTTP_200_OK))
            else:
                return Response(formatResponse('Machine Id required', 'error', None,
                                               status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class AddMachine(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'AddMachine')

    def post(self, request):
        '''
        Method to save machine data
        :param request:
        :return:
        '''
        try:
            data_set = dict(request.data)
            user = request.user.id
            m_data = None

            if data_set:
                if data_set['machine_type'] == 'null' or data_set['machine_type'] == "":
                    return Response(formatResponse('Machine type is required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                if data_set['machine_sub_type'] == 'null' or data_set['machine_sub_type'] == "":
                    return Response(formatResponse('Machine sub type is required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                if data_set['vehicle_code'] == 'null' or data_set['vehicle_code'] == "":
                    return Response(formatResponse('vehicle code required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                data_set['user_id'] = user
                ms_obj = MachineSerializer()
                # try:
                text_obj = MachineSecond.objects.filter(
                    imei_no=data_set['imei_no'], contractor_company=request.user.company_name)
                if text_obj:
                    # error_message = "IMEI Number already exist, Please use diffrent IMEI number."
                    error_message = "imei already exist"
                    return Response(formatResponse(error_message, 'success', None,
                                                   status.HTTP_500_INTERNAL_SERVER_ERROR))

                m_obj = MachineSecond.objects.filter(
                    user_id=user, machine_type=data_set['machine_type'], imei_no=data_set['imei_no'], vehicle_code=data_set['vehicle_code'])
                if m_obj:
                    m_data = ms_obj.update(m_obj, data_set)
                else:
                    m_data = ms_obj.create(data_set)

                # except:
                #     m_obj = MachineSecond.objects.get(
                #         user_id=user, machine_type=data_set['machine_type'], imei_no=data_set['imei_no'], vehicle_code=data_set['vehicle_code'])
                #     if m_obj:
                #         m_data = ms_obj.update(m_obj, data_set)
                #     else:
                #         m_data = ms_obj.create(data_set)
                if m_data:

                    mchnMsgData = {
                        'user_id': request.user.id,
                        'assign_to_id': 4,
                        'message': f"New Machine Added by {request.user.name}",
                        'machine_id': m_data.id,
                        'is_deleted': False,
                        'type': "Machine"
                    }
                    ms_obj = MachineMessageSerializer()
                    ms_obj.create(mchnMsgData)
                    if m_obj:
                        return Response(formatResponse('Machine Updated', 'success', data_set,
                                                       status.HTTP_200_OK))
                    else:
                        return Response(formatResponse('Machine Saved', 'success', data_set,
                                                       status.HTTP_200_OK))

                else:

                    return Response(formatResponse('Something went wrong please try again in some time.', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Something went wrong please try again in some time.', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class AddMachineType(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'AddMachineType')

    def post(self, request):
        '''
        Method to save machine type
        :param request:
        :return:
        '''
        try:
            data_set = dict(request.data)
            user = request.user.id

            if data_set:

                if data_set['machine_type'] == 'null' or data_set['machine_type'] == "":
                    return Response(formatResponse('Machine type is required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                m_type_obj = MachineType.objects.get(machine_type=data_set['machine_type'])

                if m_type_obj:
                    return Response(formatResponse('Machine type already exist', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                else:
                    data_set['user_id'] = user
                    m_obj = MachineTypeSerializer()
                    m_obj.create(data_set)

                    return Response(formatResponse('Machine type saved', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class AddMachineSubType(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'AddMachineSubType')

    def post(self, request):
        '''
        Method to save machine sub type
        :param request:
        :return:
        '''
        try:
            data_set = dict(request.data)
            user = request.user.id

            if data_set:

                if data_set['machine_type'] == 'null' or data_set['machine_type'] == "":
                    return Response(formatResponse('Machine type is required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                m_type_obj = MachineType.objects.get(machine_type=data_set['machine_type'])

                if m_type_obj:
                    return Response(formatResponse('Machine type already exist', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))
                m_type_obj = MachineType.objects.get(id=data_set['machine_type'])

                if not m_type_obj:
                    return Response(formatResponse('Machine type is invalid', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))
                    mst_obj = MachineSubType.objects.get(
                        machine_sub_type=data_set['machine_sub_type'])

                else:
                    data_set['user_id'] = user
                    m_obj = MachineTypeSerializer()
                    m_obj.create(data_set)

                    return Response(formatResponse('Machine type saved', 'success', None,
                                                   status.HTTP_200_OK))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class MachineTypesAndSubTypes(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'MachineTypesAndSubTypes')

    def get(self, request):
        '''
        Method to get machine types and sub_types
        :param request:
        :return:
        '''
        try:
            mach_types = []
            mach_sub_types = []
            data_dict = {}

            mt_obj = MachineType.objects.filter().distinct().values('machine_type')

            for type in mt_obj:
                dct = {"key": type['machine_type'], "value": type['machine_type']}
                mach_types.append(dct)

            mst_obj = MachineSubType.objects.filter().distinct().values('machine_sub_type')

            for subtype in mst_obj:
                dct = {"key": subtype['machine_sub_type'], "value": subtype['machine_sub_type']}
                mach_sub_types.append(dct)

            data_dict = {'types': mach_types, 'sub_types': mach_sub_types}
            return Response(formatResponse('Machine type and subtypes found', 'success', data_dict,
                                           status.HTTP_200_OK))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class MachineMessageById(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'MachineMessageById')

    def get(self, request):
        '''
        Method to get messages
        :param request:
        :return:
        '''
        try:
            user_id = request.user.id
            data_list = []
            total_machines = 0
            approved_machines = 0
            pending_machines = 0
            clarification_machines = 0
            data_dict = {}

            m_obj = MachineMessage.objects.filter(
                assign_to_id=user_id, is_deleted=False).order_by('-created_at')

            if m_obj:
                msg_ser = MachineMessageSerializer(m_obj, many=True)
                data_list = msg_ser.data

            # if user_id == 4:

            #     total_machines = MachineMessage.objects.filter(assign_to=user_id).count()
            #     approved_machines = Machine.objects.filter(
            #         approved_by_id=user_id, is_approved=True,).count()
            #     clarification_machines = Machine.objects.filter(
            #         audit_by_id=user_id, is_auditable=True,).count()
            #     pending_machines = total_machines - (approved_machines+clarification_machines)

            # else:

            #     total_machines = Machine.objects.filter(user_id=user_id).count()
            #     pending_machines = Machine.objects.filter(
            #         is_auditable=False, is_approved=False, user_id=user_id).count()
            #     approved_machines = Machine.objects.filter(
            #         is_auditable=False, is_approved=True, user_id=user_id).count()
            #     clarification_machines = Machine.objects.filter(
            #         is_auditable=True, is_approved=False, user_id=user_id).count()

            # if clarification_machines + approved_machines > total_machines:
            #     total_machines = approved_machines + clarification_machines
            #     pending_machines = 0

            machine_count = {'total_machines': total_machines, 'approved_machines': approved_machines,
                             'pending_machines': pending_machines, 'clarification_machines': clarification_machines}

            data_dict = {'data_list': data_list}
            return Response(formatResponse('Message fetched successfully', 'success', data_dict,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class GetVehiclesType(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'GetVehiclesType')

    def get(self, request):
        try:
            company = request.user.company_name
            if company:
                data_obj = SnowFlakeHelper()
                data = data_obj.get_vehicles_Type(company)
                if data:
                    return Response(formatResponse('Vehicles type found', 'success', data,
                                                   status.HTTP_200_OK))
            else:
                return Response(formatResponse('Something Went wrong please try again', 'error', None,
                                               status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class GetVehiclesImei(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'GetVehiclesImei')

    def get(self, request):
        try:
            company = request.user.company_name
            selectedtype = request.GET.get('type', None)

            if company and selectedtype:
                data_obj = SnowFlakeHelper()
                data = data_obj.get_vehicles_Imei(company, selectedtype)

                if data:
                    return Response(formatResponse('Vehicles imei number found', 'success', data,
                                                   status.HTTP_200_OK))
            else:
                return Response(formatResponse('Something Went wrong please try again', 'error', None,
                                               status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class GetVehiclesData(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'GetVehiclesData')


    def get(self, request):
        try:
            company = request.user.company_name
            selectedtype = request.GET.get('type', None)
            imeiNo = request.GET.get('imei', None)

            if company and selectedtype:
                data_obj = SnowFlakeHelper()
                data = data_obj.get_vehicles_data(company, selectedtype, imeiNo)

                if data:
                    return Response(formatResponse('Vehicles data found', 'success', data,
                                                   status.HTTP_200_OK))
            else:
                return Response(formatResponse('Something Went wrong please try again', 'error', None,
                                               status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class GetVehiclesDataById(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'GetVehiclesDataById')

    def get(self, request):
        try:
            mach_id = request.GET.get('id', None)
            if mach_id:
                m_obj = MachineSecond.objects.get(id=mach_id)
                if m_obj:
                    ms_obj = MachineSerializer(m_obj)
                    data = ms_obj.data
                    return Response(formatResponse('Vehicles data found', 'success', data,
                                                   status.HTTP_200_OK))
            else:
                return Response(formatResponse('Something Went wrong please try again', 'error', None,
                                               status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class DeleteVehiclesDataById(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Machine', 'DeleteVehiclesDataById')

    def post(self, request):
        try:
            mach_id = request.GET.get('id', None)

            if mach_id:
                m_obj = MachineSecond.objects.get(id=mach_id)
                if m_obj:
                    m_obj.delete()
                    return Response(formatResponse('Vehicles data Deleted', 'success', None,
                                                   status.HTTP_200_OK))
            else:
                return Response(formatResponse('Something Went wrong please try again', 'error', None,
                                               status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))
