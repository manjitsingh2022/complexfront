from django.db import models
from baseapp.models import BaseModel
from accounts.models import TimesheetUser

# Create your models here.


class MachineType(BaseModel):
    """Machine type model - Contains Different types of machines"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    machine_type = models.CharField(max_length=100, null=False)


class MachineSubType(BaseModel):
    """  Machine Sub type model - Contains sub types of machines"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    machine_type = models.ForeignKey(MachineType, on_delete=models.CASCADE)
    machine_sub_type = models.CharField(max_length=100, null=False)


class Machine(BaseModel):
    """  Machine model - Contains the information about machines"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    machine_type = models.ForeignKey(MachineType, on_delete=models.CASCADE)
    machine_sub_type = models.ForeignKey(MachineSubType, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, null=False)
    # machine_type = models.CharField(max_length=100, null=True, default=None)
    # machine_sub_type = models.CharField(max_length=100, null=True, default=None)
    plant = models.CharField(max_length=100, null=False)
    discription = models.TextField(null=True)
    vehicle_code = models.CharField(max_length=100, null=False)
    global_vehicle_code = models.CharField(max_length=100, null=True, default=None)
    imei_no = models.IntegerField(null=False)
    make = models.CharField(max_length=100, null=False)
    model = models.CharField(max_length=100, null=False)
    year = models.IntegerField(null=False)
    machine_age = models.IntegerField(null=False)
    contractor_company = models.CharField(max_length=100, null=False)
    is_auditable = models.BooleanField(default=False, null=True)
    is_approved = models.BooleanField(default=False, null=True)
    machine_audit_by = models.ForeignKey(TimesheetUser, null=True, blank=True,
                                         default=None, on_delete=models.CASCADE, related_name='machine_audit_by')
    machine_approved_by = models.ForeignKey(TimesheetUser, null=True, blank=True,
                                            default=None, on_delete=models.CASCADE, related_name='machine_approved_by')


# class Vehicle_Master_Database(BaseModel):
#     """Vehicle_Master_Database model - Handles Vehicles data """
#     Contractor_Company = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
#     IMEI_number = models.ForeignKey(MachineType, on_delete=models.CASCADE)
#     Machine_Age = models.ForeignKey(MachineSubType, on_delete=models.CASCADE)
#     Machine_Subtype = models.CharField(max_length=100, null=False)
#     Machine_Type = models.CharField(max_length=100, null=False)
#     Make = models.TextField(null=True)
#     Model = models.CharField(max_length=100, null=False)
#     Vehicle_Code = models.IntegerField(null=False)
#     Year = models.CharField(max_length=100, null=False)

    # class Meta:
    #     managed = False
    #     db_table = 'centeral_db'

class MachineSecond(BaseModel):
    """  Machine model - Contains the information about machines"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, null=True)
    machine_type = models.CharField(max_length=100, null=True, default=None)
    machine_sub_type = models.CharField(max_length=100, null=True, default=None)
    plant = models.CharField(max_length=100, null=True)
    discription = models.TextField(null=True)
    vehicle_code = models.CharField(max_length=100, null=True)
    global_vehicle_code = models.CharField(max_length=100, null=True, default=None)
    imei_no = models.IntegerField(null=True)
    make = models.CharField(max_length=100, null=True)
    model = models.CharField(max_length=100, null=True)
    year = models.IntegerField(null=True)
    machine_age = models.IntegerField(null=True)
    contractor_company = models.CharField(max_length=100, null=True)
    is_auditable = models.BooleanField(default=False, null=True)
    is_approved = models.BooleanField(default=False, null=True)

    class Meta:
        verbose_name_plural = 'MachineSecond'


class MachineMessage(BaseModel):
    """MachineMessage model - Save Messages of Machines"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    machine = models.ForeignKey(MachineSecond, on_delete=models.CASCADE)
    message = models.TextField(null=True, blank=True)
    assign_to = models.ForeignKey(
        TimesheetUser, on_delete=models.CASCADE, related_name='machine_assign_to')
    is_deleted = models.BooleanField(default=False, null=True)
    type = models.CharField(max_length=100, null=False)
