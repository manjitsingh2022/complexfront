"""accounts app's urls """
from django.urls import path

from accounts.views import login, get_current_user, ChangePassword, ViewerData

urlpatterns = [
    path('login/', login),
    path('me/', get_current_user),
    path('change-paasword/', ChangePassword.as_view()),
    path('viewer-list/', ViewerData.as_view()),
]
