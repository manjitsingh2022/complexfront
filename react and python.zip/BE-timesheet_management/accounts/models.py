"""accounts app's models"""

from django.db import models
from baseapp.models import BaseModel
from django.contrib.auth.models import AbstractBaseUser, UserManager
from django.utils.translation import gettext_lazy as _


class Permission(BaseModel):
    """Permission fields"""

    PERMISSION_CHOICES = (
        ("View Document", "View Document"),
        ("Add Document", "Add Document"),
        ("Delete Document", "Delete Document"),
        ("Upload Document", "Upload Document"),
        ("View Anomalies", "View Anomalies"),
        ("Add Anomalies", "Add Anomalies"),
        ("Delete Anomalies", "Delete Anomalies"),
        ("View Machines", "View Machines"),
        ("Add Machines", "Add Machines"),
        ("Delete Machines", "Delete Machines"),
        ("View Contracts", "View Contracts"),
        ("Add Contracts", "Add Contracts"),
        ("Delete Contracts", "Delete Contracts"),
        ("View Telematics", "View Telematics"),
        ("Add Telematics", "Add Telematics"),
        ("Delete Telematics", "Delete Telematics"),
        ("View Reports", "View Reports"),
        ("Add Reports", "Add Reports"),
        ("Delete Reports", "Delete Reports"),
    )

    name = models.CharField(max_length=100, choices=PERMISSION_CHOICES, null=False, unique=True)

    class Meta:
        verbose_name_plural = 'Permission'

    def __str__(self):
        return self.name


class Role(BaseModel):
    """Role fields"""

    ROLE_CHOICES = (
        ("Superadmin", "Superadmin"),
        ("Admin", "Admin"),
        ("Contractor", "Contractor"),
        ("CFO", "CFO"),
        ("Approver", "Approver"),
        ("Subcontractor", "Subcontractor")
    )

    role = models.CharField(max_length=50, choices=ROLE_CHOICES, null=False, unique=True)
    permission = models.ManyToManyField(Permission)

    class Meta:
        verbose_name_plural = 'Roles'

    def __str__(self):
        return self.role


class TimesheetUser(BaseModel, AbstractBaseUser):
    """Timesheet User model fields"""

    email = models.EmailField(_('email'), unique=True)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    name = models.CharField(max_length=255, null=False)
    company_code = models.CharField(max_length=100, null=False)
    company_name = models.CharField(max_length=255, null=True, blank=True, default=None)
    is_staff = models.BooleanField(
        _('staff status'),
        default=False,
        help_text=_('Designates whether the user can log into this site.'),
    )
    is_admin = models.BooleanField(default=False, db_index=True)
    is_superuser = models.BooleanField(default=False, db_index=True)
    is_account_locked = models.BooleanField(default=False, db_index=True)
    locked_count = models.IntegerField(default=0)

    USERNAME_FIELD = 'email'
    objects = UserManager()

    @property
    def role_detail(self):
        """method to get role details"""
        role = {
            'id': self.role.id,
            'role': self.role.role
        }
        return role

    def has_module_perms(self, app_label):
        """Does the user have permissions to view the app `app_label`?"""
        # Simplest possible answer: Yes, always
        return True

    def has_perm(self, perm, obj=None):
        """Does the user have a specific permission?"""
        # Simplest possible answer: Yes, always
        return True

    def __str__(self):
        return self.email

class TimesheetUserValidations(BaseModel):
    """Timesheet User history"""

    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    updated_password = models.CharField(max_length=100, null=False)
