"""account app's serializers"""
from rest_framework import serializers

from .models import TimesheetUser , TimesheetUserValidations


class GetCurrentUser(serializers.ModelSerializer):
    """ User fields to return in response"""

    class Meta:
        model = TimesheetUser
        fields = ('id', 'email', 'name', 'role_detail', 'company_name')


class TimesheetUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = TimesheetUser
        fields = ('id', 'email', 'name', 'role', 'company_name')

class TimesheetUserValidationsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TimesheetUserValidations
        fields = ('id','user', 'updated_password')