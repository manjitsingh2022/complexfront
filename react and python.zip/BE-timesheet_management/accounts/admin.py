"""Accounts app's admin"""

from django.contrib import admin
from django.contrib.auth.models import Group
from .models import TimesheetUser, Role, Permission
from machine.models import Machine
# from document.models import Documents, Company, Foreman, FileType, AuditDocument
from anomalies.models import SiteType, Anomalies, AuditAnomalies, DocumentType, Status
from audits.models import Audit
from timesheet.models import TimeSheet


class TimesheetUserAdmin(admin.ModelAdmin):
    """ TimesheetUser model's admin"""
    exclude = ('is_staff', 'is_admin', 'is_superuser')

    list_display = ["id", "email", "name"]


class RoleAdmin(admin.ModelAdmin):
    """ Role model's admin"""
    list_display = ["id", "role"]


class PermissionAdmin(admin.ModelAdmin):
    """ Permission model's admin"""
    list_display = ["id", "name"]


class TimeSheetAdmin(admin.ModelAdmin):
    """ TimeSheet model's admin"""
    list_display = ["id", "month", "year", "user", "machine"]


admin.site.register(TimesheetUser, TimesheetUserAdmin)
admin.site.register(Role, RoleAdmin)
admin.site.register(Permission, PermissionAdmin)
admin.site.unregister(Group)
admin.site.register(Machine)
admin.site.register(Audit)
admin.site.register(TimeSheet, TimeSheetAdmin)

# admin.site.register(Documents)
# admin.site.register(Foreman)
# admin.site.register(Company)
# admin.site.register(FileType)
# admin.site.register(SiteType)
# admin.site.register(AuditAnomalies)
# admin.site.register(Anomalies)
# admin.site.register(DocumentType)
# admin.site.register(AuditDocument)
# admin.site.register(AuditDocument)
