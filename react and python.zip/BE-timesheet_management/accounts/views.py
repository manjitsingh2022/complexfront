"""account app's views"""

from rest_framework.decorators import (api_view, permission_classes)
from django.views.decorators.csrf import csrf_exempt
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate
from django.contrib.auth.models import update_last_login
from rest_framework.authtoken.models import Token
from baseapp.utils import formatResponse
from .serializers import GetCurrentUser
from .models import TimesheetUser , TimesheetUserValidations
from rest_framework.views import APIView
from .serializers import TimesheetUserSerializer , TimesheetUserValidationsSerializer
from hashlib import sha1 as hash_sha1
from datetime import datetime ,timezone
from logs.LogHandler import LogHelper
from sys import exc_info

@csrf_exempt
@api_view(["POST"])
@permission_classes((AllowAny,))
def login(request):
    objLog = LogHelper('accounts', 'login')

    """
    method to handle login request
    :param request: email and password
    :return: response set with auth token
    """
    try:
        email = request.data.get("email")
        password = request.data.get("password")


        if email is None or password is None:
            return Response(formatResponse('Please provide both email and password', 'error',
                                           None, status.HTTP_400_BAD_REQUEST))
        email = email.lower()
        try:
            usr_obj = TimesheetUser.objects.get(email=email)
            locked_count = usr_obj.locked_count
            if locked_count >= 3 :
                return Response(formatResponse('Your account has been locked due to three consecutive failed login attempts, Please contact admin.',
                                                'error', None, status.HTTP_404_NOT_FOUND))
        except:
            
            usr_obj = None

        user = authenticate(username=email, password=password)
        if not user:
            try:
                if usr_obj :
                    locked_count = usr_obj.locked_count
                    locked_count += 1
                    usr_obj.locked_count  = locked_count
                    usr_obj.save()
            except:
                pass

            return Response(formatResponse('Invalid Credentials', 'error',
                                           None, status.HTTP_404_NOT_FOUND))
        


        token, _ = Token.objects.get_or_create(user=user)
        update_last_login(None, user)
        try:
            obj_u = GetCurrentUser(user)
            userdata = obj_u.data
            role = userdata['role_detail']['role']

        except:
            role = None
        
        try:
            if usr_obj :
                usr_obj.locked_count  = 0
                usr_obj.save()
        except:
            pass

        return Response(formatResponse('Login successfully', 'success', {'token': token.key, 'role': role},
                                       status.HTTP_200_OK))
    except:
        objLog.doLog(exc_info(), 'error')
        return Response(formatResponse('Internal Server Error', 'error', None,
                                       status.HTTP_500_INTERNAL_SERVER_ERROR))


@csrf_exempt
@api_view(["GET"])
@permission_classes((IsAuthenticated,))
def get_current_user(request):
    objLog = LogHelper('accounts', 'get_current_user')
    """
    Method to get current user details
    :param request: expect auth token in request header
    :return: user object
    """
    try:
        userobj = request.user
        obj_u = GetCurrentUser(userobj)
        userdata = obj_u.data
        is_uptodate = True
        try:
            usr_pass_obj = TimesheetUserValidations.objects.filter(user_id = request.user.id).order_by('-created_at')[:1]
            if usr_pass_obj:
                for rec in usr_pass_obj:
                    today_date =  datetime.now(timezone.utc)
                    diff = rec.created_at - today_date

                    if diff.days >= 42 :
                        is_uptodate = False
                        
        except:
            pass
        
        userdata['is_uptodate'] = is_uptodate
            
        return Response(formatResponse('current user', 'success', userdata,
                                       status.HTTP_200_OK))
    except:
        objLog.doLog(exc_info(), 'error')
        return Response(formatResponse('Internal Server Error', 'error', None,
                                       status.HTTP_500_INTERNAL_SERVER_ERROR))


class ChangePassword(APIView):
    objLog = LogHelper('accounts', 'ChangePassword')
    """
    class to handle password change
    """
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        """
        method to handle password change
        :param request: user object with atleast required fields (email, subject, message)
        :return:
        """
        try:
            pass_match = False
            dataset = dict(request.data)
            if len(dataset) == 0:
                return Response(formatResponse('bad request', 'error',
                                               None, status.HTTP_400_BAD_REQUEST))
            msg = ''
            if 'old_password' not in dataset.keys():
                msg = 'Old password is required'
            if 'new_password' not in dataset.keys():
                msg = 'New Password is required'
            if 'confirm_password' not in dataset.keys():
                msg = 'Confirm Password is required'

            if msg != '':
                return Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))

            user = authenticate(username=request.user.email, password=dataset['old_password'])
            if not user:
                return Response(formatResponse("Current Password didn't match", 'error',
                                               None, status.HTTP_404_NOT_FOUND))
            
            try:
                unq_id = (str(request.user.id)+'_' +
                        str(dataset["new_password"])).encode()
                hsh_object = hash_sha1(unq_id)
                usr_pwd = hsh_object.hexdigest()
                
            except:
                pass
            
            latest_7_records = TimesheetUserValidations.objects.filter(user_id = request.user.id).order_by('-created_at')[:7]
            for record in latest_7_records:
                if usr_pwd == record.updated_password:
                    pass_match = True
            
            if pass_match == True :
                return Response(formatResponse("Please choose a unique password that you have not used in the past seven passwords.", 'error',
                                               None, status.HTTP_404_NOT_FOUND))
            
            else:
                obj_u = TimesheetUser.objects.get(id=request.user.id)
                obj_u.set_password(dataset['new_password'])
                obj_u.save()

                tmsUser_dict = {"user_id":request.user.id,"updated_password":usr_pwd}
                tmsUserValid = TimesheetUserValidationsSerializer()
                tmsUserValid.create(tmsUser_dict)
            

            return Response(formatResponse('Password changed successfully, Please login with your new password', 'success', None,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class ViewerData(APIView):
    objLog = LogHelper('accounts', 'ViewerData')
    """
    class to handle Viewer data
    """
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        '''
        Method to get Viewers data
        :param request:
        :return:
        '''

        try:
            options_list = []
            # v_obj = TimesheetUser.objects.filter()
            # ser_obj = TimesheetUserSerializer(v_obj, many=True)
            # ser_data = ser_obj.data
            # data_dict = {}
            # for viewer in ser_data:
            #     data_dict = {'id': viewer['id'], 'email': viewer['email'], 'name': viewer['name']}
            #     viewer_list.append(data_dict)

            return Response(formatResponse('Viewers found successfully ', 'success', options_list,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


