"""Timesheet app's serilizers"""

from rest_framework import serializers
from .models import TimeSheet, TimeSheetDays, FileResult, TimesheetMessage, CFOMessage


class TimesheetSerializer(serializers.ModelSerializer):
    """TimeSheet table's serializer"""

    class Meta:
        model = TimeSheet
        fields = ('id', 'machine', 'company', 'foreman', 'po', 'invoice', 'manager_name', 'cost_center', 'order_number',
                  'status', 'total_hours', 'days_per_month', 'per_day', 'total', 'year', 'month', 'month_year', 'is_auditable', 'audit_by', 'is_approved', 'approved_by', 'sheet_message', 'signature', 'approved_on','vehicle_code','machine_sub_type','site_name')


class TimesheetDaysSerializer(serializers.ModelSerializer):
    """TimeSheetDays table's serializer"""

    class Meta:
        model = TimeSheetDays
        fields = ('timesheet', 'day', 'date', 'hours', 'rate', 'period')


class FileResultSerializer(serializers.ModelSerializer):
    """TimeSheetDays table's serializer"""

    class Meta:
        model = FileResult
        fields = ('uuid', 'file_name', 'file_data')


class TimesheetMessageSerializer(serializers.ModelSerializer):
    """TimesheetMessage table's serializer"""

    class Meta:
        model = TimesheetMessage
        fields = ('timesheet', 'Message', 'assign_to', 'user', 'is_deleted', 'created_at')


class CFOMessageSerializer(serializers.ModelSerializer):
    """CFOMessage table's serializer"""

    class Meta:
        model = CFOMessage
        fields = ('timesheet', 'Message', 'assign_to', 'user', 'is_deleted', 'created_at', 'type')
