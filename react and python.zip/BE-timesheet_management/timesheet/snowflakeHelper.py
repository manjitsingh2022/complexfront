from snowflake.connector import connect as snow_connect
from os import getenv
from logs.LogHandler import LogHelper
from sys import exc_info
class SnowFlakeHelper():
    objLog = LogHelper('TimesheetSnowflake', 'SnowFlakeHelper')
    account_identifier = getenv("SNOWFLAKE_ACCOUNT")
    username = getenv("SNOWFLAKE_USERNAME")
    password = getenv("SNOWFLAKE_PASSWORD")
    db_name = getenv("SNOWFLAKE_DB_NEW")
    schema = getenv("SNOWFLAKE_SCHEMA_NEW")
    warehouse = getenv("SNOWFLAKE_WAREHOUSE_NEW")


    def get_option_list(self, company, comp_code,role):
        try:
            data_result_dict = []
            machine_list = [{'value': "Select", "label": "Select"}]
            machine_sub_list = [{'key': "Select", "value": "Select"}]
            vehicle_code_list = [{"value": "Select", "label": "Select"}]
            vehicle_code_list2 = []
            machine_list2 = ['Select']
            machine_sub_list2 = ['Select']
            site_name_list = [{'value': "Select", "label": "Select"}]
            site_name_list2 = ['Select']
            po_list = [{'value': "Select", "label": "Select"}]
            po_list2 = ['Select']
            data_dict = {"machine_list": machine_list, "machine_sub_list": machine_sub_list, "vehicle_code_list": vehicle_code_list, "vehicle_code_list2": vehicle_code_list2,
                         "machine_sub_list2": machine_sub_list2, "machine_list2": machine_list2, "site_name_list": site_name_list, "site_name_list2": site_name_list2}

            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()

            try:
                comp = "'"+company+"'"
                if role == 'CFO' or role == 'Approver':
                    query = f'SELECT * from "Vehicle_Master_Database" '
                else:
                    query = f'SELECT * from "Vehicle_Master_Database" where "Contractor Company" ={comp} '
                cs.execute(query)
                column_names = [column[0] for column in cs.description]
                data_rows = cs.fetchall()

                if data_rows:
                    for row in data_rows:
                        row_data = dict(zip(column_names, row))
                        data_result_dict.append(row_data)

                if data_result_dict:
                    for dt in data_result_dict:
                        try:
                            m_dict = {'key': dt['Machine Type'], "value": dt['Machine Type']}
                            if m_dict not in machine_list:
                                machine_list.append(m_dict)
                                machine_list2.append(dt['Machine Type'])

                            ms_dict = {'key': dt['Machine Subtype'], "value": dt['Machine Subtype']}
                            if ms_dict not in machine_sub_list:
                                machine_sub_list.append(ms_dict)
                                machine_sub_list2.append(dt['Machine Subtype'])

                            vc_dict = {'value': dt['Vehicle_Code'], "label": dt['Vehicle_Code']}
                            if vc_dict not in vehicle_code_list:
                                vehicle_code_list.append(vc_dict)
                                vehicle_code_list2.append(vc_dict)
                        except:
                            self.objLog.doLog(exc_info(), 'error')
                            pass

                        

                # if data_rows:
                #     for row in data_rows:
                #         m_dict = {'key': row[6], "value": row[6]}
                #         ms_dict = {'key': row[7], "value": row[7]}
                #         vc_dict = {'value': row[0], "label": row[0]}
                #         if m_dict not in machine_list:
                #             machine_list.append(m_dict)
                #             machine_list2.append(row[6])

                #         if ms_dict not in machine_sub_list:
                #             machine_sub_list.append(ms_dict)
                #             machine_sub_list2.append(row[7])

                #         if vc_dict not in vehicle_code_list:
                #             vehicle_code_list.append(vc_dict)
                #             vehicle_code_list2.append(vc_dict)

            except:
                pass
            try:
                query2 = f'SELECT distinct "Name" from "GeoLocations Library" '
                cs2 = ctx.cursor()
                cs2.execute(query2)
                data_rows2 = cs2.fetchall()
                if data_rows2:
                    for row in data_rows2:
                        site_dict = {'value': row[0], "label": row[0]}
                        site_name_list.append(site_dict)
                        site_name_list2.append(row[0])
            except:
                pass
            try:
                comp_code = "'"+comp_code+"'"
                query3 = f'SELECT distinct "POHdr_PurchaseOrder" from "Merged_PO" where "POHdr_Supplier"={comp_code} '
                cs3 = ctx.cursor()
                cs3.execute(query3)
                data_rows3 = cs3.fetchall()
                if data_rows3:
                    for row in data_rows3:
                        po_dict = {'value': row[0], "label": row[0]}
                        po_list.append(po_dict)
                        po_list2.append(row[0])
            except:
                self.objLog.doLog(exc_info(), 'error')
                pass

            data_dict = {"machine_list": machine_list, "machine_sub_list": machine_sub_list, "vehicle_code_list": vehicle_code_list, "vehicle_code_list2": vehicle_code_list2,
                         "machine_sub_list2": machine_sub_list2, "machine_list2": machine_list2, "site_name_list": site_name_list, "site_name_list2": site_name_list2, "po_list": po_list, "po_list2": po_list2}
            return data_dict
        except:
            self.objLog.doLog(exc_info(), 'error')
            return data_dict
