"""TimeSheet app's views"""

from .serializers import TimesheetSerializer, TimesheetDaysSerializer, FileResultSerializer, TimesheetMessageSerializer, CFOMessageSerializer
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from utilities.utils import formatResponse
from dateutil import parser
from .models import TimeSheet, TimeSheetDays, TimesheetMessage, CFOMessage
from accounts.models import TimesheetUser
from rest_framework.permissions import IsAuthenticated
import uuid
from datetime import datetime, timedelta
from django.db.models import Q
from document.models import Documents
from machine.models import MachineSecond
from document.SnowFlakeHandler import SnowFlakeHelper
from anomalies.SnowFlakeHandler import SnowFlakeHelper as anom_SnowFlakeHelper
from urllib.parse import unquote
from .snowflakeHelper import SnowFlakeHelper as time_SnowFlakeHelper
from logs.LogHandler import LogHelper
from sys import exc_info

class TimesheetData(APIView):
    '''
    Method to Check if dataset is valid or not
    :param request:
    :return:
    '''
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Timesheet', 'TimesheetData')

    def checkDataValidations(self, dataset):
        status = "success"
        try:
            if len(dataset) == 0:
                msg = 'bad request'
                status = msg
                # status = Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))

            if 'machine' not in dataset.keys():
                msg = 'machine name is required'
                status = msg
                # status = Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))

            if 'company' not in dataset.keys():
                msg = 'company name is required'
                status = msg
                # status = Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))

            # if 'po' not in dataset.keys():
            #     msg = 'PO is required'
            #     status = msg
                # status = Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))

            if 'status' not in dataset.keys():
                msg = 'Timesheet Status is required'
                status = msg
                # status = Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))

            # if 'invoice' not in dataset.keys():
            #     msg = 'Invoice is required'
            #     status = msg
                # status = Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))

            if 'foreman' not in dataset.keys():
                msg = 'Foreman is required'
                status = msg
                # status = Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))
            if 'manager_name' not in dataset.keys():
                msg = 'Name is required'
                status = msg

                # status = Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))

            if 'days_data' not in dataset.keys():
                msg = 'TimeSheet days are required'
                status = "TimeSheet days are required"
                # status = Response(formatResponse(msg, 'error', None, status.HTTP_400_BAD_REQUEST))
        except:
            status = "error"
        return status

    def CheckIfMachineExist(self, month, year, machine, company):
        '''
        Method to check if machine already exist for this date
        :param request:
        :return:
        '''
        rspns = None
        try:

            tm_obj = TimeSheet.objects.filter(
                machine=machine, year=year, month=month, company=company)
            if tm_obj:
                rspns = "Exist"
            else:
                rspns = "Does not Exist"
            return rspns

        except:
            return rspns

    def post(self, request):
        '''
        Method to save TimeSheet data
        :param request:
        :return:
        '''
        try:
            dataset = dict(request.data)

            sheet_update_obj = None
            sheet_days_update_obj = None
            if 'timesheet_id' in dataset.keys():
                timesheet_id = dataset['timesheet_id']
                sheet_update_obj = TimeSheet.objects.get(id=timesheet_id)
            chechk_data_status = self.checkDataValidations(dataset)
            if request.user.id == 5:
                assign_to_id = 6
            else:
                assign_to_id = 4

            if chechk_data_status == "success":
                sheetData = {
                    "site_name":dataset['site_name'],
                    "machine": dataset["machine"],"machine_sub_type": dataset["machineSubType"], "company": dataset["company"],
                    "foreman": dataset["foreman"], "po": dataset["po"], "signature": dataset['signature'],
                    "invoice": dataset["invoice"], "status": dataset["status"], "manager_name": dataset["manager_name"],
                    "total_hours": dataset["total_hours"], "days_per_month":
                    dataset["days_per_month"], "order_number": dataset["order_number"], "per_day": dataset["per_day"],
                    "total": dataset["total"], "month": dataset['month'], 'year': dataset['year'], 'month_year': parser.parse(dataset['month_year']),
                    "user_id": request.user.id, "assign_to_id": assign_to_id, "vehicle_code":dataset['vehicleCode']                }
                # clarify = self.CheckIfMachineExist(
                #     dataset['month'], dataset['year'], dataset["machine"], request.user.company_name)
                # if 'timesheet_id' not in dataset.keys():
                #     if clarify:
                #         if clarify == "Exist":
                #             return Response(formatResponse('Timesheet for this machine already submitted.', 'error', None,
                #                          
                #                     status.HTTP_400_BAD_REQUEST))
                #         else:
                #             pass
                #     else:
                #         return Response(formatResponse('Something went wrong, Please try again', 'error', None,
                #                                        status.HTTP_400_BAD_REQUEST))

                obj = TimesheetSerializer()
                if sheet_update_obj:
                    data = obj.update(sheet_update_obj, sheetData)
                else:
                    data = obj.create(sheetData)
                  
                sheet_id = data.id

                try:
                    if sheet_id:
                        daysData = dataset['days_data']
                        for day in daysData:
                            if day['hours'] == 'null' or day['hours'] == None:
                                continue
                            else:
                                day["timesheet_id"] = sheet_id
                                day['date'] = parser.parse(day['date'])
                                s_obj = TimesheetDaysSerializer()
                                if sheet_update_obj:
                                    try:
                                        sheet_days_update_obj = TimeSheetDays.objects.get(
                                            timesheet=timesheet_id, date=day['date'])
                                    except:
                                        sheet_days_update_obj = None

                                if sheet_days_update_obj:
                                    s_obj.update(sheet_days_update_obj, day)

                                else:
                                    s_obj.create(day)

                        return Response(formatResponse('Timesheet created', 'success', sheet_id,
                                                       status.HTTP_200_OK))

                except:
                    self.objLog.doLog(exc_info(), 'error')
                    return Response(formatResponse('Internal Server Error', 'error', None,
                                                   status.HTTP_500_INTERNAL_SERVER_ERROR))

            else:
                return Response(formatResponse(chechk_data_status, 'error', None, status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))

    def put(self, request):
        '''
        Method to update status and submit TimeSheet data
        :param request:
        :return:
        '''
        try:
            dataset = dict(request.data)
            if 'timesheet_id' in dataset.keys():
                timesheet_id = dataset['timesheet_id']
                sheet_update_obj = TimeSheet.objects.get(id=timesheet_id)
                chechk_data_status = self.checkDataValidations(dataset)
                if request.user.id == 5:
                    assign_to_id = 6
                else:
                    assign_to_id = 4
                if chechk_data_status == "success":
                    sheetData = {
                        "site_name":dataset['site_name'],
                        "machine": dataset["machine"],"machine_sub_type": dataset["machineSubType"], "company": dataset["company"], "cost_center": dataset["cost_center"],
                        "foreman": dataset["foreman"], "po": dataset["po"], "signature": dataset['signature'],
                        "invoice": dataset["invoice"], "status": dataset["status"], "manager_name": dataset["manager_name"],
                        "total_hours": dataset["total_hours"], "days_per_month":
                        dataset["days_per_month"], "order_number": dataset["order_number"], "per_day": dataset["per_day"],
                        "total": dataset["total"], "month": dataset['month'], 'year': dataset['year'], 'month_year': parser.parse(dataset['month_year']),
                        "user_id": request.user.id,
                        "assign_to_id": assign_to_id,
                        "vehicle_code":dataset['vehicleCode']
                    }

                    obj = TimesheetSerializer()
                    if sheet_update_obj:
                        data = obj.update(sheet_update_obj, sheetData)
                        approver_list = TimesheetUser.objects.filter(
                        role__role="Approver").values("id")

                        msg_dict2 = {
                                'user_id': request.user.id,
                                'assign_to_id':  None,
                                # 'Message': f"New Timesheet created by {request.user.name} from {request.user.company_name}",
                                'timesheet_id': data.id,
                                'is_deleted': False,
                                'type': 'created'
                            }

                        msg_exist = TimesheetMessage.objects.filter(timesheet_id=data.id) 
                       
                        if msg_exist:
                            msg_dict2['Message']=f" Timesheet updated by {request.user.name} from {request.user.company_name}"
                        else:
                             msg_dict2['Message']= f"New Timesheet created by {request.user.name} from {request.user.company_name}"
                        
                        
                        if msg_dict2:
                                msg_obj2 = CFOMessageSerializer()
                                msg_obj2.create(msg_dict2)

                        for aprrvr in approver_list:
                            msg_dict = None
                            msg_dict2 = None

                            msg_dict = {
                                'user_id': request.user.id,
                                'assign_to_id': aprrvr['id'],
                                # 'Message': f"New Timesheet created by {request.user.name}",
                                'timesheet_id': data.id,
                                'is_deleted': False,
                                'type': 'created'
                            }
                            if msg_exist:
                                msg_dict['Message']=f" Timesheet updated by {request.user.name}"
                            else:
                                msg_dict['Message']= f"New Timesheet created by {request.user.name}"
                            

                            if msg_dict:
                                msg_obj = TimesheetMessageSerializer()
                                msg_obj.create(msg_dict)

                            


                    sheet_id = data.id
                    try:
                        if sheet_id:
                            daysData = dataset['days_data']
                            for day in daysData:
                                if day['hours'] == 'null' or day['hours'] == None:
                                    continue
                                else:
                                    day["timesheet_id"] = sheet_id
                                    day['date'] = parser.parse(day['date'])
                                    s_obj = TimesheetDaysSerializer()
                                    if sheet_update_obj:
                                        try:
                                            sheet_days_update_obj = TimeSheetDays.objects.get(
                                                timesheet=timesheet_id, date=day['date'])
                                        except:
                                            sheet_days_update_obj = None

                                    if sheet_days_update_obj:
                                        s_obj.update(sheet_days_update_obj, day)

                                    else:
                                        s_obj.create(day)

                                    

                            return Response(formatResponse('Timesheet Submitted', 'success', sheet_id,
                                                           status.HTTP_200_OK))

                    except:
                        self.objLog.doLog(exc_info(), 'error')
                        return Response(formatResponse('Internal Server Error', 'error', None,
                                                       status.HTTP_500_INTERNAL_SERVER_ERROR))
                else:
                    return chechk_data_status
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))

    def get(self, request):
        '''
        Method to get TimeSheet data
        :param request:
        :return:
        '''
        try:
            query = (Q())
            sheet_status = request.GET.get("sheetStatus", None)
            start_date = request.GET.get("startDate", None)
            end_date = request.GET.get("endDate", None)
            tms_search = request.GET.get("tms_search", None)
            page = int(request.GET.get('page_no', 1))
            company = request.GET.get("company", None)
            VehicleCode = request.GET.get("VehicleCode", None)
            upto = 10 * page
            offset = 0
            no_of_pages = 1
            total_count = 0
            data_dict = {}

            try:
                if page == 0 or page == 1:
                    offset = 0
                else:
                    offset = (page - 1) * 10

            except:
                pass


            if start_date != "null" and start_date != "undefined" and start_date != "" and start_date != None and end_date != "null" and end_date != "" and end_date != None and end_date != "undefined":
                try:
                    start_date = datetime.strptime(start_date, '%d-%m-%Y').date()
                    end_date = datetime.strptime(end_date, '%d-%m-%Y').date()

                    if query != None:
                        query.add(
                            (Q(created_at__date__gte=start_date, created_at__date__lte=end_date)), query.connector)
                    else:
                        query = (Q(created_at__date__gte=start_date, created_at__date__lte=end_date))

                except:

                    pass
            if company != None and company != "null" and company != "Null" and company != "" and company != "undefined":
                if query != None:
                        query.add((Q(company=company)), query.connector)
                else:
                    query = (Q(company=company))
            

            if sheet_status != None and sheet_status != "null" and sheet_status != "Null" and sheet_status != "" and sheet_status != "undefined":

                if sheet_status == "Pending":
                    if query != None:
                        query.add((Q(is_auditable=False, is_approved=False)), query.connector)
                    else:
                        query = (Q(is_auditable=False, is_approved=False))

                if sheet_status == "Approved":
                    if query != None:
                        query.add((Q(is_approved=True, is_auditable=False)), query.connector)
                    else:
                        query = (Q(is_approved=True, is_auditable=False))

                if sheet_status == "Request Clarification":
                    if query != None:
                        query.add((Q(is_auditable=True, is_approved=False)), query.connector)
                    else:
                        query = (Q(is_auditable=True, is_approved=False))

            if tms_search != None and tms_search != "null" and tms_search != "Null" and tms_search != "" and tms_search != "undefined":
                if query != None:
                    query.add((Q(month__icontains=tms_search) | Q(machine__icontains=tms_search) | Q(po__icontains=tms_search) | Q(invoice__icontains=tms_search) | Q(manager_name__icontains=tms_search) | Q(order_number__icontains=tms_search) | Q(cost_center__icontains=tms_search) | Q(
                        foreman__icontains=tms_search, year__icontains=tms_search)), query.connector)
                else:
                    query = (Q(month__icontains=tms_search) | Q(machine__icontains=tms_search) | Q(po__icontains=tms_search) | Q(invoice__icontains=tms_search) | Q(manager_name__icontains=tms_search) | Q(order_number__icontains=tms_search) | Q(cost_center__icontains=tms_search) | Q(
                        foreman__icontains=tms_search | Q(year__icontains=tms_search)))
                    
            if  VehicleCode != None and VehicleCode != "null" and VehicleCode != "Null" and VehicleCode != "" and VehicleCode != "undefined":
                if query != None:
                        query.add((Q(vehicle_code=VehicleCode)), query.connector)
                else:
                    query = (Q(vehicle_code=VehicleCode))


            if request.user.role.role == "Approver" or request.user.role.role == "CFO" :
                # if request.user.id == 4 or request.user.id == 6:
                lst_timesheet = TimeSheet.objects.filter(
                    query).order_by('-year', '-month', '-created_at')[offset:upto]
                total_count = TimeSheet.objects.filter(query).count()

          
            else:
                lst_timesheet = TimeSheet.objects.filter(
                    query, company=request.user.company_name).order_by('-year', '-month', '-created_at')[offset:upto]
                total_count = TimeSheet.objects.filter(query,company=request.user.company_name).count()

            t_data = TimesheetSerializer(lst_timesheet, many=True)
            timesheet_list = t_data.data
            for x in timesheet_list:
                data_list = []
                if x['approved_by'] != None:
                    aprvr_name = TimesheetUser.objects.filter(id=x['approved_by']).values('name')
                    x['approved_by_name'] = aprvr_name[0]['name']
                days_obj = TimeSheetDays.objects.filter(timesheet=x['id'])
                if days_obj:
                    t_data = TimesheetDaysSerializer(days_obj, many=True)
                    data_list = t_data.data
                x['days_data'] = data_list

                try:
                    timesheet_sg = TimeSheet.objects.get(
                         id = x["id"])
                    
                    x['signature'] = str(timesheet_sg.signature)
                
                except:
                    pass
            try:
                
                if total_count > 10:
                    pages = total_count/10
                    remainder = int(total_count % 10)
                    if remainder > 0:
                        no_of_pages = int(pages) + 1
                    else:
                        no_of_pages = pages
                else:
                    no_of_pages = 1
            except:
                no_of_pages = 1

            if offset == 0:
                offset = 1

            if upto > total_count:
                upto = total_count


            data_dict = {"no_of_pages": no_of_pages, "total_count": total_count, "offset": offset, "upto": upto,"timesheet_list":timesheet_list}

            return Response(formatResponse('TimeSheet List', 'success', data_dict,
                                           status.HTTP_200_OK))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', [],
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class ConvertBase64ToJson(APIView):
    objLog = LogHelper('Timesheet', 'MachineData')
    def post(self, request):
        '''
        Method to get Json data converted from base64
        :param request:
        :return:
        '''
        try:

            data_dict = {"file_data": [

                {
                    "id": 1,
                    "email": "rose.moore@example.com",
                    "gender": "female",
                    "name": "preet"
                }, {
                    "id": 2,
                    "email": "rose.dfsf@example.com",
                    "gender": "female",
                    "name": "amreek"
                }, {
                    "id": 3,
                    "email": "rose.mofsdfore@example.com",
                    "gender": "female",
                    "name": "jaspreet"
                }, {
                    "id": 4,
                    "email": "rose.mmn@example.com",
                    "gender": "female",
                    "name": "amanpreet"
                }, {
                    "id": 5,
                    "email": "rasdjkre@example.com",
                    "gender": "female",
                    "name": "joban"
                },
            ], "file_name": "MYFILENAME.PDF", 'file_to_show': request.data['base64'], 'file_Type': request.data['file_Type']
            }

            return Response(formatResponse('Data converted ', 'success', data_dict,
                                           status.HTTP_200_OK))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class PostFileResult(APIView):
    def post(self, request):
        '''
        Method to save file results
        :param request:
        :return:
        '''
        try:
            _id = None
            f_obj = FileResultSerializer()
            uu_id = uuid.uuid4().hex
            data_dict = {'file_name': request.data['file_name'], 'file_data': request.data['file_data'], 'uuid': uu_id
                         }
            save_data = f_obj.create(data_dict)
            _id = save_data.id
            if _id:
                return Response(formatResponse('File Result Saved ', 'success', _id,
                                               status.HTTP_200_OK))

            else:
                return Response(formatResponse('Internal Server Error', 'error', None,
                                               status.HTTP_500_INTERNAL_SERVER_ERROR))

        except:
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class TimesheetDataById(APIView):
    objLog = LogHelper('Timesheet', 'TimesheetDataById')

    def get_last_date_of_month(self, year, month):
        """Return the last date of the month.

        Args:
            year (int): Year, i.e. 2022
            month (int): Month, i.e. 1 for January

        Returns:
            date (datetime): Last date of the current month
        """

        if month == 12:
            last_date = datetime(year, month, 31)
        else:
            last_date = datetime(year, month + 1, 1) + timedelta(days=-1)

        return last_date.strftime("%Y-%m-%d")

    def get(self, request):
        '''
        Method to get timesheet data by id
        :param request:
        :return:
        '''
        sheet_id = request.GET.get("sheet_id", None)
        data_dict = {}
        sheet_data = {}
        days_data = {}
        sheet_days_data = []
        try:
            ts_obj = TimeSheet.objects.filter(id=sheet_id)
            ts_ser_obj = TimesheetSerializer(ts_obj, many=True)
            sheet_data = ts_ser_obj.data
            sheet_data = sheet_data[0]
            days_obj = TimeSheetDays.objects.filter(timesheet_id=ts_ser_obj.data[0]['id'])
            days_ser_obj = TimesheetDaysSerializer(days_obj, many=True)
            days_data = days_ser_obj.data
            sheet_data["signature"] = str(ts_obj[0].signature)

            if sheet_data:
                start_date = (str(sheet_data['year']) + "-" + str(sheet_data['month']) + '-01')
                end_date = self.get_last_date_of_month(sheet_data['year'], sheet_data['month'])
                import pandas as pd
                days_of_month = pd.date_range(start=start_date, end=end_date, freq='D')

                for x in days_of_month:
                    _data = [d for d in days_data if str(d["date"]) == str(x.date())]
                    if len(_data) > 0:
                        for y in _data:
                            s_dict = {
                                "timesheet": y['timesheet'],
                                "day": y['day'],
                                "date": y['date'],
                                "hours": y['hours'],
                                "rate": y['rate'],
                                "period": y['period'],
                            }
                    else:
                        s_dict = {
                            "timesheet": sheet_id,
                            "day": x.strftime('%A'),
                            "date": x.date(),
                            "hours": 'null',
                            "rate": 'Wet',
                            "period": "Day",
                        }
                    sheet_days_data.append(s_dict)

                data_dict = {"sheet_data": sheet_data, "days_data": sheet_days_data, }

            return Response(formatResponse('TimeSheet data', 'success', data_dict,
                                           status.HTTP_200_OK))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))

    def put(self, request):
        '''
        Method to update Timesheet data
        :param request:
        :return:
        '''
        try:
            data_set = dict(request.data)
            sheet_id = request.GET.get("sheet_id", None)
            if data_set:
                sheet_data = data_set['sheet_data']
                days_data = data_set['days_data']

            ts_obj = TimeSheet.objects.get(id=sheet_id)

            try:
                approver_list = TimesheetUser.objects.filter(
                    role__role="Approver").values("id")
                
                msg_dict2 = {
                        'user_id': request.user.id,
                        'assign_to_id':  None,
                        'Message': f"Timesheet Updated by {request.user.name} from {request.user.company_name}",
                        'timesheet_id': sheet_id,
                        'is_deleted': False,
                        'type': 'updated'
                    }
                if msg_dict2:
                        msg_obj2 = CFOMessageSerializer()
                        msg_obj2.create(msg_dict2)
              
                for aprvr in approver_list:
                    msg_dict = None
                    msg_dict2 = None
                    msg_dict = {
                        'user_id': request.user.id,
                        'assign_to_id': aprvr['id'],
                        'Message': f" Timesheet Updated by {request.user.name}",
                        'timesheet_id': sheet_id,
                        'is_deleted': False,
                         'type': 'updated'
                    }
                   
                    if msg_dict:
                        msg_obj = TimesheetMessageSerializer()
                        msg_obj.create(msg_dict)

                    
            except:

                pass

            ts_ser_obj = TimesheetSerializer()
            ts_ser_obj.update(ts_obj, sheet_data)

            days_obj = TimeSheetDays.objects.filter(timesheet_id=sheet_id).delete()

            for day in days_data:
                if day['hours'] == 'null' or day['hours'] == None or day['hours'] == 0 or day['hours'] == '':
                    continue
                else:
                    del day['timesheet']
                    day["timesheet_id"] = int(sheet_id)
                    day['date'] = parser.parse(day['date'])
                    s_obj = TimesheetDaysSerializer()
                    s_obj.create(day)

            return Response(formatResponse('Timesheet data saved', 'success', data_set,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class TimesheetAuditOrApprove(APIView):

    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Timesheet', 'TimesheetAuditOrApprove')

    def post(self, request):
        '''
        Method to Audit or approve Timesheet
        :param request:
        :return:
        '''
        try:
            data_dict = dict(request.data)
            user_id = request.user.id
            msg_dict = None
            msg_dict2 = None
            try:
                sheet_created_by = TimeSheet.objects.get(
                    id=data_dict['sheet_id'])
                created_by = sheet_created_by.user.id
            except:
                pass
            if data_dict["is_auditable"] == True:
                sheetData = {"is_auditable": data_dict["is_auditable"],
                             "sheet_message": data_dict['messages'],
                             "is_approved": data_dict['is_approved'], "audit_by_id": user_id}
                sheet_id = data_dict['sheet_id']

                msg_dict = {
                    'user_id': request.user.id,
                    'assign_to_id': created_by,
                    'Message': f"Timesheet clarification requested by {request.user.name}",
                    'timesheet_id': sheet_id,
                    'is_deleted': False,
                    'type': 'Clarification'
                }
                msg_dict2 = {
                    'user_id': request.user.id,
                    'assign_to_id': created_by,
                    'Message': f"Timesheet clarification requested by {request.user.name} from {request.user.company_name}",
                    'timesheet_id': sheet_id,
                    'is_deleted': False,
                    'type': 'Clarification'
                }

            if data_dict["is_approved"] == True:
                utc_datetime = datetime.utcnow()
                sheetData = {"is_auditable": data_dict["is_auditable"],
                             "approved_on": utc_datetime,
                             "is_approved": data_dict['is_approved'],  "approved_by_id": user_id}
                sheet_id = data_dict['sheet_id']

                msg_dict = {
                    'user_id': request.user.id,
                    'assign_to_id': created_by,
                    'Message': f"Timesheet approved by {request.user.name}",
                    'timesheet_id': sheet_id,
                    'is_deleted': False,
                    'type': 'Approved'
                }
                msg_dict2 = {
                    'user_id': request.user.id,
                    'assign_to_id': created_by,
                    'Message': f"Timesheet approved by {request.user.name} from {request.user.company_name}",
                    'timesheet_id': sheet_id,
                    'is_deleted': False,
                    'type': 'Approved'
                }
            if msg_dict2:
                try:
                    cfo_msg_obj = CFOMessageSerializer()
                    cfo_msg_obj.create(msg_dict2)
                except:

                    pass

            if msg_dict:
                try:
                    msg_obj = TimesheetMessageSerializer()
                    msg_obj.create(msg_dict)
                except:
                    pass

            sheet_update_obj = TimeSheet.objects.get(id=sheet_id)

            sheet_serl_obj = TimesheetSerializer()
            update_data = sheet_serl_obj.update(sheet_update_obj, sheetData)

            return Response(formatResponse('successfully done', 'success', data_dict,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class MessageById(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Timesheet', 'MessageById')

    def get(self, request):
        '''
        Method to get messages
        :param request:
        :return:
        '''
        try:
            user_id = request.user.id
            user_company = request.user.company_name
            user_role = request.user.role.role
            data_list = []
            total_sheets = 0
            total_machines = 0
            total_documents = 0
            approved_sheets = 0
            pending_sheets = 0
            clarification_sheets = 0
            total_anomalies = (0,)
            urgent_anomalies = (0,)
            data_dict = {}

            if user_role == "CFO" : 
                m_obj = CFOMessage.objects.filter(
                    is_deleted=False).order_by('-created_at')

                if m_obj:
                    msg_ser = CFOMessageSerializer(m_obj, many=True)
                    data_list = msg_ser.data
            
            elif user_role == "Approver":
                try:
                    m_obj = TimesheetMessage.objects.filter(
                        assign_to__role__role=user_role, assign_to_id=user_id, is_deleted=False).order_by('-created_at')
                    if m_obj:
                        msg_ser = TimesheetMessageSerializer(m_obj, many=True)
                        data_list = msg_ser.data

                except:
                    pass


            else:
                try:
                    m_obj = TimesheetMessage.objects.filter(
                        assign_to__role__role=user_role, assign_to_id__company_name=user_company, assign_to_id=user_id, is_deleted=False).order_by('-created_at')
                    if m_obj:
                        msg_ser = TimesheetMessageSerializer(m_obj, many=True)
                        data_list = msg_ser.data
                except:
                    pass

          

            if user_role == 'CFO' or user_role == "Approver":
                total_sheets = TimeSheet.objects.filter(
                ).count()
                approved_sheets = TimeSheet.objects.filter(
                    is_approved=True, is_auditable=False,).count()
                clarification_sheets = TimeSheet.objects.filter(
                    is_auditable=True, is_approved=False).count()
                pending_sheets = TimeSheet.objects.filter(
                    is_auditable=False, is_approved=False).count()

           
            else:
             
                total_sheets = TimeSheet.objects.filter(company=user_company).count()
                pending_sheets = TimeSheet.objects.filter(
                    is_auditable=False, is_approved=False,  company=user_company).count()
                approved_sheets = TimeSheet.objects.filter(
                    is_auditable=False, is_approved=True,  company=user_company).count()
                clarification_sheets = TimeSheet.objects.filter(
                    is_auditable=True, is_approved=False,  company=user_company).count()

            if clarification_sheets + approved_sheets > total_sheets:
                total_sheets = approved_sheets + clarification_sheets
                pending_sheets = 0

            try:
                anm_obj = anom_SnowFlakeHelper()
                total_anomalies = anm_obj.get_Anomalies_count()
                urgent_anomalies = anm_obj.get_urgent_Anomalies_count()

            except:

                pass

            try:
                if user_role == 'CFO' or user_role == "Approver":
                    total_machines = MachineSecond.objects.filter().count()
                else:
                    total_machines = MachineSecond.objects.filter(
                        contractor_company='Red Top Asset Management').count()
            except:
                pass

            try:
                d_obj = SnowFlakeHelper()

                total_documents = d_obj.get_Documents_count()

                total_documents = (int(total_documents[0]) * 2)
            except:
                pass

            sheet_count = {'total_sheets': total_sheets, 'approved_sheets': approved_sheets,
                           'pending_sheets': pending_sheets, 'clarification_sheets': clarification_sheets,
                           'total_machines': total_machines, "total_documents": total_documents, "anom_count": total_anomalies[0], "urgent_anomalies": urgent_anomalies[0]}

            data_dict = {'data_list': data_list, 'sheet_count': sheet_count}
            return Response(formatResponse('Message fetched successfully', 'success', data_dict,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class DashBoardGraphData(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Timesheet', 'DashBoardGraphData')

    def get(self, request):
        '''
        Method to get Graph Data
        :param request:
        :return:
        '''
        try:
            user = request.user.role.role
            comp_code = request.user.company_code
            month_count = request.GET.get("monthCount", 12)
            graph_data = {}
            cfo_pie_chart = None
            finance_chart = None
            cfo_line_chart = None

            finance_chart = None
            from document.SnowFlakeHandler import SnowFlakeHelper
            doc_obj = SnowFlakeHelper()

            if user == 'CFO' or user == "Approver":
                finance_chart = doc_obj.get_Documents_graph_data2(month_count)

            else:
                finance_chart = doc_obj.get_Documents_graph_data(month_count,comp_code)

            if user == 'CFO' or user == "Approver":
                from anomalies.SnowFlakeHandler import SnowFlakeHelper
                anom_pie_obj = SnowFlakeHelper()
                cfo_pie_chart = anom_pie_obj.get_Anomalies_pie_chart()

                cfo_line_chart = anom_pie_obj.get_Anomalies_line_chart()

            graph_data = {"cfo_pie_chart": cfo_pie_chart,
                          "finance_chart": finance_chart, "cfo_line_chart": cfo_line_chart}
            return Response(formatResponse('Message fetched successfully', 'success', graph_data,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class OptionsData(APIView):
    """
    class to handle Options data
    """
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('Timesheet', 'OptionsData')

    def get(self, request):
        '''
        Method to get Options data
        :param request:
        :return:
        '''

        try:
            data_dict = {}
            po_list = [{'key': "Select", "value": "Select"}]
            machine_list = [{'key': "Select", "value": "Select"}]
            vehicle_code_list = [{'key': "Select", "value": "Select"}]
            vehicle_code_list2 = []
            machine_list2 = ['Select']
            machine_sub_list2 = ['Select']
            site_name_list = [{'key': "Select", "value": "Select"}]
            site_name_list2 = ['Select']
            po_list = [{'key': "Select", "value": "Select"}]
            po_list2= ['Select']


           
            company = request.user.company_name
            comp_code = request.user.company_code
            objj =  time_SnowFlakeHelper()
            list_data = objj.get_option_list(company,comp_code,request.user.role.role)
            
            m_obj = MachineSecond.objects.filter().distinct().values("machine_type")
            if m_obj:
                for mac in m_obj:
                    # dct = {"key": mac['machine_type'], "value": mac['machine_type']}
                    # machine_list.append(dct)
                    machine_list2.append(mac['machine_type'])
            vc_obj = MachineSecond.objects.filter().distinct().values("vehicle_code")
            if vc_obj:
                for vc in vc_obj:
                    # vd_dct = {"key": vc['vehicle_code'], "value": vc['vehicle_code']}
                    # vehicle_code_list.append(vd_dct)
                    vehicle_code_list2.append(vc['vehicle_code'])
            machine_list = list_data['machine_list']
            vehicle_code_list = list_data['vehicle_code_list']
            machine_sub_list = list_data['machine_sub_list']

            vehicle_code_list2 = list_data['vehicle_code_list2']
            machine_list2 = list_data['machine_list2']
            machine_sub_list2 = list_data['machine_sub_list2']
            site_name_list = list_data['site_name_list']
            site_name_list2 = list_data['site_name_list2']
            po_list = list_data['po_list']
            po_list2= list_data['po_list2']
            data_dict = {"machine_list": machine_list, "po_list": po_list, "vehicle_code_list":vehicle_code_list,"vehicle_code_list2":vehicle_code_list2,"machine_list2":machine_list2,"machine_sub_list":machine_sub_list,"machine_sub_list2":machine_sub_list2,"site_name_list2":site_name_list2,"site_name_list":site_name_list,"po_list2":po_list2,"po_list":po_list}
            return Response(formatResponse('Viewers found successfully ', 'success', data_dict,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))

class TimesheetDataByIdNotInPage(APIView):
    objLog = LogHelper('Timesheet', 'TimesheetDataByIdNotInPage')
    def get(self,request):
        timesheet_data = {}
        sheet_id = request.GET.get("sheet_id", None)
        try :
            tms_obj = TimeSheet.objects.filter(id= sheet_id)
            ts_ser_obj = TimesheetSerializer(tms_obj, many=True)
            timesheet_data = ts_ser_obj.data
            for x in timesheet_data:
                days_obj = TimeSheetDays.objects.filter(timesheet=x['id'])
                if days_obj:
                    t_data = TimesheetDaysSerializer(days_obj, many=True)
                    data_list = t_data.data
                x['days_data'] = data_list
                x["signature"] = str(tms_obj[0].signature)

            return Response(formatResponse('TimeSheet data', 'success', timesheet_data,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))