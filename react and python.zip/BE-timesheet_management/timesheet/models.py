"""Models for Timesheet app"""
from django.db import models
from baseapp.models import BaseModel
from accounts.models import TimesheetUser


class TimeSheet(BaseModel):
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    machine = models.CharField(max_length=100, null=False)
    machine_sub_type = models.CharField(max_length=100, null=True,default=None)
    company = models.CharField(max_length=100, null=False)
    foreman = models.CharField(max_length=100, null=False)
    po = models.CharField(max_length=100, null=True,default=None)
    invoice = models.CharField(max_length=100, null=True)
    status = models.CharField(max_length=100, null=False)
    signature = models.FileField(null=False)
    manager_name = models.CharField(max_length=100, null=False)
    order_number = models.CharField(null=True, max_length=100)
    cost_center = models.CharField(max_length=100, null=True,default=None)
    total_hours = models.IntegerField(null=False)
    days_per_month = models.IntegerField(null=False)
    per_day = models.FloatField(null=False)
    total = models.IntegerField(null=False)
    verified_by = models.IntegerField(default=None, null=True, blank=True)
    verified_on = models.DateTimeField(default=None, null=True, blank=True)
    month_year = models.DateField(null=False)
    month = models.IntegerField(null=False)
    year = models.IntegerField(null=False)
    sheet_message = models.TextField(null=True, blank=True, default=None)
    is_auditable = models.BooleanField(default=False, null=True)
    is_approved = models.BooleanField(default=False, null=True)
    approved_on = models.DateTimeField(default=None, null=True)
    audit_by = models.ForeignKey(TimesheetUser, null=True, blank=True,
                                 default=None, on_delete=models.CASCADE, related_name='audit_by')
    approved_by = models.ForeignKey(TimesheetUser, null=True, blank=True,
                                    default=None, on_delete=models.CASCADE, related_name='approved_by')
    assign_to = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE,
                                  related_name='sheet_assign_to', default=4)
    vehicle_code = models.CharField(max_length=100, null=True,default=None)
    site_name  = models.CharField(max_length=100, null=True,default=None)

    # viewer = models.ForeignKey(TimesheetUser, null=True, blank=True,
    #                            default=None, on_delete=models.CASCADE, related_name='sheet_viewer')


class TimeSheetDays(BaseModel):
    """TimeSheetDays model - Contains data according to Months"""
    timesheet = models.ForeignKey(TimeSheet, on_delete=models.CASCADE)
    day = models.CharField(max_length=100, null=False)
    date = models.DateField(max_length=100, null=False)
    hours = models.FloatField(max_length=100, null=False)
    rate = models.CharField(null=False, max_length=100)
    period = models.CharField(max_length=100, null=False)


class FileResult(BaseModel):
    """FileResult model - Save data by reading pdf's"""
    uuid = models.CharField(max_length=100, null=False)
    file_name = models.CharField(max_length=100, null=False)
    file_data = models.TextField(null=False)


class TimesheetMessage(BaseModel):
    """TimesheetMessage model - Save Messages of Timesheets"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    timesheet = models.ForeignKey(TimeSheet, on_delete=models.CASCADE)
    Message = models.TextField(null=True, blank=True)
    assign_to = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE, related_name='assign_to')
    is_deleted = models.BooleanField(default=False, null=True)
    type = models.CharField(max_length=100, null=True, default=None, blank=True)


class CFOMessage(BaseModel):
    """CFO Message model - Save Messages of CFO"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    timesheet = models.ForeignKey(TimeSheet, on_delete=models.CASCADE)
    Message = models.TextField(null=True, blank=True)
    assign_to = models.ForeignKey(
        TimesheetUser, on_delete=models.CASCADE, related_name='assign_to_user',null=True,blank=True)
    is_deleted = models.BooleanField(default=False, null=True)
    type = models.CharField(max_length=100, null=True, default=None, blank=True)
