"""
timesheet_management URL Configuration
"""
from django.urls import path
from timesheet.views import TimesheetData, ConvertBase64ToJson, PostFileResult, TimesheetDataById, TimesheetAuditOrApprove, MessageById, DashBoardGraphData, TimesheetDataByIdNotInPage,OptionsData
from django.contrib import admin
from django.conf.urls import include


urlpatterns = [
    path('admin/', admin.site.urls),
    path('timesheet/', TimesheetData.as_view()),
    path('timesheet-by-id/', TimesheetDataById.as_view()),
    path('timesheet-by-id-not-in-page/', TimesheetDataByIdNotInPage.as_view()),
    path('convert-base64-to-json/', ConvertBase64ToJson.as_view()),
    path('save-file-result/', PostFileResult.as_view()),
    path('users/', include('accounts.urls')),
    path('machine/', include('machine.urls')),
    path('document/', include('document.urls')),
    path('anomalies/', include('anomalies.urls')),
    path('telematics/', include('telematics.urls')),
    path('approve-audit-timesheet/', TimesheetAuditOrApprove.as_view()),
    path('dashboard-graph-data/', DashBoardGraphData.as_view()),
    path('get-message-by-id/', MessageById.as_view()),
    path('options-list/', OptionsData.as_view())


]

admin.site.site_header = "Timesheet Admin"
admin.site.site_title = "Timesheet Admin "
admin.site.index_title = "Welcome to Timesheet Admin Portal"
