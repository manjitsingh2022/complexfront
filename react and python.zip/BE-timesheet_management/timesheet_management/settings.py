
from pathlib import Path
from corsheaders.defaults import default_headers
from os import getenv, path as os_path

BASE_DIR = Path(__file__).resolve().parent.parent


SECRET_KEY = 'django-insecure-sw^q-s+#-hxdq2m)@^h+w=bi%p%y%a4ycd1@d13_*pzp^+@tfl'

DEBUG = False
ALLOWED_HOSTS = ['*']
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework.authtoken',
    'timesheet',
    'corsheaders',
    'rest_framework',
    'accounts',
    'machine',
    'document',
    'anomalies',
    'telematics',
    'audits'
]

AUTH_USER_MODEL = 'accounts.TimesheetUser'
ACCOUNT_EMAIL_REQUIRED = True
ACCOUNT_AUTHENTICATION_METHOD = 'email'
ACCOUNT_USER_MODEL_USERNAME_FIELD = 'email'

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'timesheet_management.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'timesheet_management.wsgi.application'
DATABASES = {
    'default': {
        
        'ENGINE': 'django_snowflake',
        'ACCOUNT': getenv("SNOWFLAKE_ACCOUNT"),
        'USER': getenv("SNOWFLAKE_USERNAME"),
        'PASSWORD': getenv("SNOWFLAKE_PASSWORD"),
        'NAME': getenv("SNOWFLAKE_DB_TIMESHEET"),
        'SCHEMA': getenv("SNOWFLAKE_SCHEMA_TIMESHEET"),
        'WAREHOUSE': getenv("SNOWFLAKE_WAREHOUSE"),
    },


    'centeral_db': {
        'ENGINE': 'django_snowflake',
        'ACCOUNT': getenv("SNOWFLAKE_ACCOUNT"),
        'USER': getenv("SNOWFLAKE_USERNAME"),
        'PASSWORD': getenv("SNOWFLAKE_PASSWORD"),
        'NAME': getenv("SNOWFLAKE_DB_NEW"),
        'SCHEMA': getenv("SNOWFLAKE_SCHEMA_NEW"),
        'WAREHOUSE': getenv("SNOWFLAKE_WAREHOUSE_NEW"),
    }
}


AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True

STATIC_URL = '/static/'

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework.authentication.TokenAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated'
    ],
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
        'rest_framework.renderers.BrowsableAPIRenderer',
    ),
    'DEFAULT_PARSER_CLASSES': (
        'rest_framework.parsers.JSONParser',
    ),
    'DEFAULT_SCHEMA_CLASS': 'rest_framework.schemas.coreapi.AutoSchema',
}

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
CORS_ORIGIN_ALLOW_ALL = True
CORS_ALLOW_HEADERS = default_headers + (
    'Access-Control-Allow-Headers', 'access-control-allow-origin',
)
DATABASE_APPS_MAPPING = {'centeral_db': 'centeral_db',
                         }
