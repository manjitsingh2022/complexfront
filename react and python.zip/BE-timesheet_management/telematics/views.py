from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from baseapp.utils import formatResponse
from rest_framework.permissions import IsAuthenticated
from .serializers import TelematicsSerializer, CompanySerializer, AuditsTelematicsSerializer
from .models import Telematics, TelematicsCompany, Foreman, Machine, AuditsTelematics
from sys import exc_info
from machine.serializers import MachineSerializer, MachineTypeSerializer, MachineSubTypeSerializer
from document.serializers import ForemanSerializer
from django.db.models import Q
from audits.models import Audit
from audits.serializers import AuditSerializer
from logs.LogHandler import LogHelper
from sys import exc_info

class TelematicsData(APIView):

    permission_classes = (IsAuthenticated,)

    def get(self, request):
        '''
        Method to get telematics data
        :param request:
        :return:
        '''
        data_dict = {}
        telematics = None
        audits = None
        total_count = 0
        c_list = []
        f_list = []
        m_list = []
        query = (Q())

        try:
            selected_company = request.GET.get('companyType', None)
            selected_foreman = request.GET.get('foremanType', None)
            selected_machine = request.GET.get('machineType', None)
            selectdMonth = request.GET.get('selectdMonth', None)

            page = int(request.GET.get('page', None))
            user = request.user.id
            upto = 16 * page

            offset = 0
            try:
                if page == 0 or page == 1:
                    offset = 0
                else:
                    offset = (page - 1) * 16

            except:
                pass
            if selected_company != 'undefined' and selected_company != 'null' and selected_company != None and selected_company != '':
                if query != None:
                    query.add((Q(company__company_name=selected_company)), query.connector)
                else:
                    query = (Q(company__company_name=selected_company))

            if selected_foreman != 'undefined' and selected_foreman != 'null' and selected_foreman != None and selected_foreman != '':
                if query != None:
                    query.add((Q(foreman__foreman_name=selected_foreman)), query.connector)
                else:
                    query = (Q(foreman__foreman_name=selected_foreman))

            if selected_machine != 'undefined' and selected_machine != 'null' and selected_machine != None and selected_machine != '':
                query = Q(machine__name=selected_machine)

            if selectdMonth != "null" and selectdMonth != "" and selectdMonth != None:
                dt = selectdMonth.split("-")
                year = dt[0]
                month = str(dt[1])
                if query != None:

                    query.add(
                        (Q(created_at__year=int(year), created_at__month=int(month))), query.connector)
                else:
                    query = (Q(created_at__year=int(year), created_at__month=int(month)))
            try:
                t_obj = Telematics.objects.filter(query, user=user)[offset:upto]
                total_count = Telematics.objects.filter(query, user=user).count()
                if t_obj:
                    ts_obj = TelematicsSerializer(t_obj, many=True)
                    telematics = ts_obj.data

                    for x in telematics:
                        aud_obj = Audit.objects.filter(telematics=x['id'])

                        if aud_obj:
                            as_obj = AuditSerializer(aud_obj, many=True)
                            x['audits_data'] = as_obj.data
                        else:
                            x['audits_data'] = []

                        # aud_obj = AuditsTelematics.objects.filter(telematic=x['id'])
                        # if aud_obj:
                        #     aud_data = AuditsTelematicsSerializer(aud_obj, many=True)
                        #     x['audits_data'] = aud_data.data
                        # else:
                        #     aud_data = []

            except:
                telematics = []

            try:
                c_obj = TelematicsCompany.objects.filter(user=user).values_list(
                    'company_name', flat=True).distinct()

                if c_obj:
                    for x in c_obj:
                        c_list.append({'label': x, 'value': x})
            except:
                pass

            try:
                f_obj = Foreman.objects.filter(user=user).values_list(
                    'foreman_name', flat=True).distinct()
                if f_obj:
                    for x in f_obj:
                        f_list.append({'label': x, 'value': x})
            except:
                pass

            try:
                m_obj = Machine.objects.filter(user=user).values_list(
                    'name', flat=True).distinct()
                if m_obj:
                    for x in m_obj:
                        m_list.append({'label': x, 'value': x})
            except:
                pass

            try:
                if total_count > 16:
                    pages = total_count/16
                    if type(pages) == float:
                        split_num = str(pages).split('.')
                        no_of_pages = int(split_num[0])+1
                else:
                    no_of_pages = 1
            except:
                no_of_pages = 1

            data_dict = {'telematics_data': telematics, 'company': c_list, 'foreman': f_list,
                         'machine': m_list, 'no_of_pages': no_of_pages}

            return Response(formatResponse('Telematics data found', 'success', data_dict,
                                           status.HTTP_200_OK))
        except:
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))

    # def post(self, request):
    #     '''
    #     Method to save telematics data
    #     :param request:
    #     :return:
    #     '''
    #     try:
    #         data_set = dict(request.data)
    #         user = request.user.id
    #         if data_set:
    #             telematics = data_set['telematics']
    #             company = data_set['company']
    #             foreman = data_set['foreman']
    #             machine = data_set['machine']
    #             machine_type = data_set['machine_type']
    #             machine_sub_type = data_set['machine_sub_type']
    #             audits = data_set['audits']

    #             if company['company_name'] == 'null' or company['company_name'] == "":
    #                 return Response(formatResponse('hire type is required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))

    #             if foreman['foreman_name'] == 'null' or foreman['foreman_name'] == "":
    #                 return Response(formatResponse(' name is required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))

    #             if telematics['name'] == 'null' or telematics['name'] == "":
    #                 return Response(formatResponse('model_no is  required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))
    #             if telematics['title'] == 'null' or telematics['title'] == "":
    #                 return Response(formatResponse('model_no is  required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))
    #             if telematics['header'] == 'null' or telematics['header'] == "":
    #                 return Response(formatResponse('model_no is  required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))
    #             if telematics['address'] == 'null' or telematics['address'] == "":
    #                 return Response(formatResponse('model_no is  required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))
    #             if telematics['pincode'] == 'null' or telematics['pincode'] == "":
    #                 return Response(formatResponse('model_no is  required', 'error', None,
    #                                                status.HTTP_400_BAD_REQUEST))

    #             c_obj = CompanySerializer()
    #             company['user_id'] = user
    #             company_data = c_obj.create(company)

    #             f_obj = ForemanSerializer()
    #             foreman['user_id'] = user
    #             foreman_data = f_obj.create(foreman)

    #             m_type_obj = MachineTypeSerializer()
    #             machine_type['user_id'] = user
    #             m_type_data = m_type_obj.create(machine_type)
    #             if m_type_data:
    #                 m_sub_type_obj = MachineSubTypeSerializer()
    #                 machine_sub_type['user_id'] = user
    #                 machine_sub_type['machine_type_id'] = m_type_data.id
    #                 m_sub_type_data = m_sub_type_obj.create(machine_sub_type)

    #                 if m_sub_type_data:
    #                     machine['user_id'] = user
    #                     machine['machine_type_id'] = m_type_data.id
    #                     machine['machine_sub_type_id'] = m_sub_type_data.id
    #                     m_obj = MachineSerializer()
    #                     machine_data = m_obj.create(machine)

    #             if company_data != None and foreman_data != None and m_type_data != None:
    #                 t_obj = TelematicsSerializer()
    #                 telematics['user_id'] = user
    #                 telematics['company_id'] = company_data.id
    #                 telematics['foreman_id'] = foreman_data.id
    #                 telematics['machine_id'] = machine_data.id
    #                 telematics_data = t_obj.create(telematics)

    #             a_obj = AuditsTelematicsSerializer()
    #             audits['user_id'] = user
    #             audits['telematic_id'] = telematics_data.id
    #             audits_data = a_obj.create(audits)

    #             if audits_data != None:
    #                 return Response(formatResponse('Contracts data saved', 'success', data_set,
    #                                                status.HTTP_200_OK))
    #     except:
    #         return Response(formatResponse('Internal Server Error', 'error', None,
    #                                        status.HTTP_500_INTERNAL_SERVER_ERROR))

    def put(self, request, id=None):
        '''
        Method to update telematics data
        :param request id:
        :return:
        '''
        try:
            dataset = dict(request.data)

            t_obj = Telematics.objects.get(id=id)
            c_obj = Company.objects.get(id=id)
            f_obj = Foreman.objects.get(id=id)
            m_obj = Machine.objects.get(id=id)
            a_obj = AuditsTelematics.objects.get(id=id)
            if dataset:
                telematics = dataset['telematics']
                company = dataset['company']
                foreman = dataset['foreman']
                machine = dataset['machine']
                audits = dataset['audits']

                if t_obj:
                    ts_obj = TelematicsSerializer()
                    t_data = ts_obj.update(t_obj, telematics)
                    ts_obj = TelematicsSerializer(t_data)

                if c_obj:
                    cs_obj = CompanySerializer()
                    c_data = cs_obj.update(c_obj, company)
                    cs_obj = CompanySerializer(c_data)

                if f_obj:
                    fs_obj = ForemanSerializer()
                    f_data = fs_obj.update(f_obj, foreman)
                    fs_obj = ForemanSerializer(f_data)

                if m_obj:
                    ms_obj = MachineSerializer()
                    ht_data = ms_obj.update(m_obj, machine)
                    ms_obj = MachineSerializer(ht_data)

                if a_obj:
                    as_obj = AuditsTelematicsSerializer()
                    a_data = as_obj.update(a_obj, audits)
                    as_obj = AuditsTelematicsSerializer(a_data)

                return Response(formatResponse('Contracts data saved', 'success', dataset,
                                               status.HTTP_200_OK))
        except:
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class TelematicsDataById(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, id):
        '''
        Method to get telematics data by id
        :param request id:
        :return:
        '''
        telematics_id = id or request.GET.get("id", None)
        user_id = request.user.id
        telematics_data = None
        company_data = None
        foreman_data = None
        machine_data = None
        audits_data = None
        data_dict = {}
        try:
            if telematics_id:
                t_obj = Telematics.objects.get(id=telematics_id, user=user_id)
                if t_obj:
                    t_serial = TelematicsSerializer(t_obj)
                    telematics_data = t_serial.data
                    if telematics_data:
                        c_obj = Company.objects.get(id=telematics_data['company'])
                        c_serial = CompanySerializer(c_obj)
                        company_data = c_serial.data
                        if company_data:
                            f_obj = Foreman.objects.get(id=telematics_data['foreman'])
                            f_serial = ForemanSerializer(f_obj)
                            foreman_data = f_serial.data
                            if foreman_data:
                                m_obj = Machine.objects.get(id=telematics_data['machine'])
                                m_serial = MachineSerializer(m_obj)
                                machine_data = m_serial.data
                                if machine_data:
                                    a_obj = AuditsTelematics.objects.get(
                                        id=telematics_data['audits'])
                                    a_serial = AuditsTelematicsSerializer(a_obj)
                                    audits_data = a_serial.data

                        data_dict = {"telematics": telematics_data, "company": company_data,
                                     'foreman': foreman_data, 'machine': machine_data, "audits_data": audits_data}

                        return Response(formatResponse('Contracts data found', 'success', data_dict,
                                                       status.HTTP_200_OK))
            else:
                return Response(formatResponse('Contracts Id required', 'error', None,
                                               status.HTTP_400_BAD_REQUEST))

        except:
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))
