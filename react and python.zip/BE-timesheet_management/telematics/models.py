from django.db import models
from baseapp.models import BaseModel
from accounts.models import TimesheetUser
from machine.models import Machine
from document.models import Foreman


class TelematicsCompany(BaseModel):
    """Company model - Contains comapany names"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    company_name = models.CharField(default=None, max_length=200, blank=True)


class Telematics(BaseModel):
    """Telematics model - Contains telematics data"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    foreman = models.ForeignKey(Foreman, on_delete=models.CASCADE)
    machine = models.ForeignKey(Machine, on_delete=models.CASCADE)
    company = models.ForeignKey(TelematicsCompany, on_delete=models.CASCADE)
    name = models.CharField(default=None, max_length=100)
    title = models.CharField(default=None, max_length=100)
    header = models.CharField(default=None, max_length=100)
    telematics_address = models.CharField(default=None, max_length=100)
    telematics_pincode = models.IntegerField(default=None)
    start_time = models.TimeField(default=None)
    end_time = models.TimeField(default=None)
    odometer = models.CharField(default=None, max_length=100)
    driver = models.CharField(default=None, max_length=100)
    fuel = models.CharField(default=None, max_length=100)


class AuditsTelematics(BaseModel):
    """Audits model - Contains Audits names"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    handle = models.CharField(default=None, max_length=200)
    last_name = models.CharField(default=None, max_length=200)
    first_name = models.CharField(default=None, max_length=200)
    telematic = models.ForeignKey(Telematics, on_delete=models.CASCADE)
