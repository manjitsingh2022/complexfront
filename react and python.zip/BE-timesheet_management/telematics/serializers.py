"""Telematics app's serilizers"""

from rest_framework import serializers
from .models import Telematics, TelematicsCompany, AuditsTelematics


class TelematicsSerializer(serializers.ModelSerializer):
    """Telematics table's serializer"""
    class Meta:
        model = Telematics
        fields = '__all__'
        # fields = ('user', 'company','foreman','machine','name','title','header','address','pincode', 'start_time',  'end_time', 'odometer', 'driver', 'fuel', 'img', 'img_2' )


class CompanySerializer(serializers.ModelSerializer):
    """Company table's serializer"""
    class Meta:
        model = TelematicsCompany
        fields = ('user', 'company_name')


class AuditsTelematicsSerializer(serializers.ModelSerializer):
    """Company table's serializer"""
    class Meta:
        model = AuditsTelematics
        fields = '__all__'
        # fields = ('user', 'handle','last_name','first_name','telematic')
