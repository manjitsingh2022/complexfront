"""Telematics app's urls """

from django.urls import path
from .views import TelematicsData,TelematicsDataById

urlpatterns = [
    path('telematics-data/', TelematicsData.as_view()),
    path('telematics-data/<int:id>/', TelematicsData.as_view()),
    path('telematics-data-by-id/<int:id>/', TelematicsDataById.as_view()),
]
