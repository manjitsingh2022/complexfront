"""Anomalies app's serilizers"""

from rest_framework import serializers
from .models import DocumentType, SiteType, Status, Anomalies, AuditAnomalies


class AnomaliesSerializer(serializers.ModelSerializer):
    """Anomalies table's serializer"""

    class Meta:
        model = Anomalies
        fields = ('id', 'user', 'status', 'document_type',
                  'site_type', 'plant', 'document', 'anomalies_status')


class SiteSerializer(serializers.ModelSerializer):
    """Site table's serializer"""

    class Meta:
        model = SiteType
        fields = ('user', 'site_type')


class DocumentTypeSerializer(serializers.ModelSerializer):
    """DocumentType table's serializer"""

    class Meta:
        model = DocumentType
        fields = ('user', 'document_type')


class StatusSerializer(serializers.ModelSerializer):
    """Status table's serializer"""

    class Meta:
        model = Status
        fields = ('user', 'status')


class AuditsSerializer(serializers.ModelSerializer):
    """Audits table's serializer"""

    class Meta:
        model = AuditAnomalies
        # fields = ('user', 'first_name', 'last_name', 'handle', 'anomalies')
        fields = '__all__'
