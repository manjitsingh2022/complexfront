from snowflake.connector import connect as snow_connect
from random import choice as random_choice
from os import getenv
from logs.LogHandler import LogHelper
from sys import exc_info

class SnowFlakeHelper():
    objLog = LogHelper('AnomaliesSnowflake', 'SnowFlakeHelper')
    account_identifier = getenv("SNOWFLAKE_ACCOUNT")
    username = getenv("SNOWFLAKE_USERNAME")
    password = getenv("SNOWFLAKE_PASSWORD")
    db_name = getenv("SNOWFLAKE_DB_NEW")
    schema = getenv("SNOWFLAKE_SCHEMA_NEW")
    warehouse = getenv("SNOWFLAKE_WAREHOUSE_NEW")
    comp = None

    def get_Anomalies_Data(self, site, doc_type, status, start_date, end_date, company, upto, offset, anom_search):
        try:
            status_list = []
            data_list = []
            data_dict = {}
            data_result_dict = []
            anom_final_data = []
            no_of_pages = 1

            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()
            cs2 = ctx.cursor()
            cs3 = ctx.cursor()
            comp = None
            if company == "Red Top Asset Management":
                comp = "'010R'"
            elif company == "Quartz Plant Hire":
                comp = "'004Q'"
            elif company == "KLT Machinery and Plant Hire":
                comp = "'006K'"

            query = f'SELECT distinct "INV_PO_Price_Anomaly_Status" from "CFO_Anomalies"'
            query2 = f'SELECT * from "CFO_Anomalies"'
            query3 = f'SELECT count(*) from "CFO_Anomalies"'

            if status != 'null' and status != None and status != "undefined":
                status = "'"+status+"'"
                query2 += f' where "INV_PO_Price_Anomaly_Status"= {status}'
                query3 += f' where "INV_PO_Price_Anomaly_Status"= {status}'

                if start_date != None and start_date != "null" and start_date != "undefined":
                    start_date = "'"+start_date+"'"
                    end_date = "'"+end_date+"'"
                    query2 += f'and "INV_InvoiceDate">= {start_date} and "INV_InvoiceDate"<= {end_date} '
                    query3 += f'and "INV_InvoiceDate">= {start_date} and "INV_InvoiceDate"<= {end_date} '

                if comp != None:
                    query2 += f'and "INV_Supplier" = {comp} '
                    query3 += f'and "INV_Supplier" = {comp} '

                if anom_search and anom_search != 'null' and anom_search != 'Undefined':
                    srch_term = "'%"+anom_search+"%'"
                    query3 += f'and  ("INV_PO_Price_Anomaly_Reason" ILIKE {srch_term}) '
                    query2 += f'and  ("INV_PO_Price_Anomaly_Reason" ILIKE {srch_term} ) '

            elif start_date != None and start_date != "null" and start_date != "undefined":
                start_date = "'"+start_date+"'"
                end_date = "'"+end_date+"'"
                query2 += f' where "INV_InvoiceDate">= {start_date} and "INV_InvoiceDate"<= {end_date} '
                query3 += f' where "INV_InvoiceDate">= {start_date} and "INV_InvoiceDate"<= {end_date} '

                if comp != None:
                    query2 += f'and "INV_Supplier" = {comp} '
                    query3 += f'and "INV_Supplier" = {comp} '

                if anom_search and anom_search != 'null' and anom_search != 'Undefined':
                    srch_term = "'%"+anom_search+"%'"
                    query3 += f'and  ("INV_PO_Price_Anomaly_Reason" ILIKE {srch_term}) '
                    query2 += f'and  ("INV_PO_Price_Anomaly_Reason" ILIKE {srch_term} ) '

            elif comp != None:
                query2 += f' where "INV_Supplier" = {comp} '
                query3 += f' where "INV_Supplier" = {comp} '

            elif anom_search and anom_search != 'null' and anom_search != 'Undefined':
                srch_term = "'%"+anom_search+"%'"
                query3 += f'where "INV_PO_Price_Anomaly_Reason" ILIKE {srch_term}'
                query2 += f'where "INV_PO_Price_Anomaly_Reason" ILIKE {srch_term} '

            query2 += f' limit 32 offset {offset}'

            cs.execute(query)
            cs2.execute(query2)
            cs3.execute(query3)
            rows_count = cs3.fetchone()
            column_names = [column[0] for column in cs2.description]
            anom_data = cs2.fetchall()
            data_rows = cs.fetchall()
            for row in anom_data:
                row_data = dict(zip(column_names, row))
                data_result_dict.append(row_data)

            if data_result_dict:
                for dt in data_result_dict:
                    anmDct = {
                        "reason": dt['INV_PO_Price_Anomaly_Reason'],
                        "INV_PO_Price_Difference": dt['INV_PO_Price_Difference'],
                        "INV_PO_Price_Anomaly_Indicator": dt['INV_PO_Price_Anomaly_Indicator'],
                        "INV_PO_Price_Anomaly_Status": dt['INV_PO_Price_Anomaly_Status'],
                        "INV_PO_Price_Anomaly_Reason": dt['INV_PO_Price_Anomaly_Reason'],
                        "WetDayRate": dt['Wet Day Rate'],
                        "DryDayRate": dt['Dry Day Rate'],
                        "PO_Wet_Rate_Difference": dt['PO_Wet_Rate_Difference'],
                        "PO_Dry_Rate_Difference": dt['PO_Dry_Rate_Difference'],
                        "INV_Invoice": dt['INV_Invoice'],
                        "INV_InvoiceDate": dt['INV_InvoiceDate'],
                        "INV_DueDate": dt['INV_DueDate'],
                        "INV_OrigInvValue": dt['INV_OrigInvValue'],
                        "INVPay_TrnValue": dt['INVPay_TrnValue'],
                        "INVPay_TrnType": dt['INVPay_TrnType'],
                        "MachineType": dt['Machine Type'],
                        "MachineSubType": dt['Machine Subtype'],
                        "HireType": dt['Hire Type'],
                        "INV_Reference": dt['INV_Reference'],
                        "PODet_PurchaseOrder": dt['PODet_PurchaseOrder'],
                        "POHdr_OrderEntryDate": dt['POHdr_OrderEntryDate'],
                        "POHdr_OrderDueDate": dt['POHdr_OrderDueDate'],
                        "PODet_MStockCode": dt['PODet_MStockCode'],
                        "PODet_MPrice": dt['PODet_MPrice'],
                    }
                    anom_final_data.append(anmDct)

            rows_count = rows_count[0]

            if rows_count > 32:
                pages = rows_count/32
                remainder = int(rows_count % 32)
                if remainder > 0:
                    no_of_pages = int(pages) + 1
                else:
                    no_of_pages = pages
            else:
                no_of_pages = 1

            for anm in data_rows:
                s_d = {'label': anm[0], 'value': str(anm[0]), 'type': 'anm_status'}
                if s_d not in status_list:
                    status_list.append(s_d)

            if offset == 0:
                offset = 1

            if upto > rows_count:
                upto = rows_count

            data_dict = {"status_list": status_list,
                         "data_list": anom_final_data, "no_of_pages": no_of_pages, "total": rows_count, "offset": offset, "upto": upto}
            return data_dict

        except:
            self.objLog.doLog(exc_info(), 'error')
            return data_dict

    def get_Anomalies_count(self):
        try:
            anom_count = 0
            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()
            query = 'SELECT count(*) from "CFO_Anomalies"'
            cs.execute(
                query)
            anom_count = cs.fetchone()

            return anom_count

        except:
            self.objLog.doLog(exc_info(), 'error')
            return anom_count

    def get_urgent_Anomalies_count(self):
        try:
            urgent_anom_count = 0
            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()
            status = "'Urgent'"
            query = f'SELECT count(*) from "CFO_Anomalies" where "INV_PO_Price_Anomaly_Status"= {status} '
            cs.execute(
                query)
            urgent_anom_count = cs.fetchone()

            return urgent_anom_count

        except:
            self.objLog.doLog(exc_info(), 'error')
            return urgent_anom_count

    def get_Anomalies_pie_chart(self):
        graph_data = None

        try:
            series = []
            labels = ["Not Urgent", "Urgent"]

            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()
            status = "'Urgent'"
            urgent_query = f'SELECT count(*) from "CFO_Anomalies" where "INV_PO_Price_Anomaly_Status"= {status} '
            status2 = "'Not Urgent'"
            not_urgent_query = f'SELECT count(*) from "CFO_Anomalies" where "INV_PO_Price_Anomaly_Status"= {status2} '
            cs.execute(urgent_query)
            urgent_anom_count = cs.fetchone()[0]

            cs.execute(not_urgent_query)
            not_urgent_anom_count = cs.fetchone()[0]
            total_count = urgent_anom_count + not_urgent_anom_count
            urgent_anom_count = (urgent_anom_count/total_count) * 100

            not_urgent_anom_count = (not_urgent_anom_count/total_count) * 100

            series = [round(not_urgent_anom_count), round(urgent_anom_count)]
            options = {
                'width': 380,
                'type': "pie",
                'labels': ["Not Urgent", "Urgent"],
                'responsive': [
                    {
                        'breakpoint': 720,
                        'options': {
                            'chart': {
                                'width': 300,
                            },
                        },
                    },
                ],
                'dataLabels': {
                    'enabled': False,
                },
                'legend': {
                    'position': "bottom",
                },
                'colors': ["#E34747", "#FCAF17"],
            }
            graph_data = {"series": series, "options": options}

            return graph_data
        except:
            self.objLog.doLog(exc_info(), 'error')
            return graph_data

    def get_Anomalies_line_chart(self):
        line_data = None
        try:
            from datetime import datetime, timedelta
            date_range = 7
            data_list = []
            date_list = []
            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()
            count = 6
            for _ in range(date_range):
                start_date = datetime.now() - timedelta(days=count+1)
                end_date = datetime.now() - timedelta(days=count)
                s_date = "'"+str(start_date)+"'"
                e_date = "'"+str(end_date)+"'"
                x_date = str(end_date.strftime("%b")) + \
                    ' '+str(end_date.day)

                query = f'SELECT COUNT(*) FROM "CFO_Anomalies" WHERE "INV_InvoiceDate">= {s_date} AND "INV_InvoiceDate"<= {e_date}'

                cs.execute(query)
                result = cs.fetchone()[0]
                data_list.append(result)
                date_list.append(x_date)
                count -= 1

            line_data = {"data_list": data_list, "date_list": date_list}

            return line_data
        except:
            self.objLog.doLog(exc_info(), 'error')
            return line_data
