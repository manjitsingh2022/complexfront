from django.urls import path

from .views import AnomaliesData, AnomaliesDataById

urlpatterns = [
    path('anomalies-data/', AnomaliesData.as_view()),
    path('update-anomalies/<int:id>/', AnomaliesDataById.as_view())
    # path('anomalie-data-by-id/', AnomaliesDataById.as_view()),

]
