"""Anomalies app's views"""

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from baseapp.utils import formatResponse
from rest_framework.permissions import IsAuthenticated
from .models import Anomalies, SiteType, DocumentType, Status, AuditAnomalies
from .serializers import AnomaliesSerializer, SiteSerializer, DocumentTypeSerializer, StatusSerializer, AuditsSerializer
from django.db.models import Q
from audits.models import Audit
from audits.serializers import AuditSerializer
from .SnowFlakeHandler import SnowFlakeHelper
from logs.LogHandler import LogHelper
from sys import exc_info

class AnomaliesData(APIView):
    objLog = LogHelper('anomalies', 'AnomaliesData')
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        '''
        Method to get Anomalies data
        :param request:
        :return:
        '''
        
        obj_a = SnowFlakeHelper()

        try:
            user = request.user.id
            selected_site = request.GET.get('siteType', None)
            selected_doctype = request.GET.get('documenttype', None)
            selected_satus = request.GET.get('statusType', None)
            selectd_month = request.GET.get('selectd_month', None)
            start_date = request.GET.get('start_date', None)
            end_date = request.GET.get('end_date', None)
            company = request.GET.get('company', None)
            page = int(request.GET.get('page_no', 0))
            anom_search = request.GET.get('anom_search', None)

            upto = 32 * page
            offset = 0
            try:
                if page == 0 or page == 1:
                    offset = 0
                else:
                    offset = (page - 1) * 32
            except:
                pass

            anm_data = obj_a.get_Anomalies_Data(
                selected_site, selected_doctype, selected_satus, start_date, end_date, company, upto, offset, anom_search)
            if anm_data:
                return Response(formatResponse('Anomalies data found', 'success', anm_data,
                                               status.HTTP_200_OK))
            else:
                return Response(formatResponse('An error accured ', 'error', None,
                                               status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))
            
    def post(self, request):
        '''
        Method to save Anomalies data
        :param request:
        :return:
        '''
        try:
            data_set = dict(request.data)
            user = request.user.id
            document_type = None
            save_site = None
            save_audits = None
            save_status = None
            save_anomalies = None
            if data_set:
                document_type = data_set['document_type']
                site = data_set['site']
                status = data_set['status']
                audits = data_set['audits']
                anomalies = data_set['anomalies']

                if document_type['document_type'] == 'null' or document_type['document_type'] == "":
                    return Response(formatResponse('document type is required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                if status['status'] == 'null' or status['status'] == "":
                    return Response(formatResponse('status name type is required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                if site['site_name'] == 'null' or site['site_name'] == "":
                    return Response(formatResponse('site name required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                document_type_obj = DocumentTypeSerializer()
                document_type['user_id'] = user
                document_type = document_type_obj.create(document_type)

                audits_obj = AuditsSerializer()
                audits['user_id'] = user
                save_audits = audits_obj.create(audits)

                site_obj = SiteSerializer()
                site['user_id'] = user
                save_site = site_obj.create(site)

                status_obj = StatusSerializer()
                status['user_id'] = user
                save_status = status_obj.create(status)

                if save_status != None and document_type != None and save_site != None and save_audits != None:
                    anomalies_obj = AnomaliesSerializer()
                    anomalies['user_id'] = user
                    anomalies['document_type_id'] = user
                    anomalies['site_name_id'] = user
                    anomalies['audits_id'] = user
                    anomalies['status_id'] = user
                    save_anomalies = anomalies_obj.create(anomalies)

                    if save_anomalies != None:
                        return Response(formatResponse('Anomalies data saved', 'success', data_set,
                                                       status.HTTP_200_OK))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))

    def put(self, request):
        '''
        Method to update Anomalies data
        :param request:
        :return:
        '''
        try:
            data_set = dict(request.data)
            # user_id = request.user.id
            user_id = 4

            if data_set:
                document_type = data_set['document_type']
                site = data_set['site']
                status = data_set['status']
                audits = data_set['audits']
                anomalies = data_set['anomalies']

            obj_documenttype = DocumentType.objects.get(id=user_id)
            document_type_obj = DocumentTypeSerializer()
            document_type_data = document_type_obj.update(obj_documenttype, document_type)

            obj_site = SiteType.objects.get(id=user_id)
            site_obj = SiteSerializer()
            site_data = site_obj.update(obj_site, site)

            obj_status = Status.objects.get(id=user_id)
            status_obj = StatusSerializer()
            status_data = status_obj.update(obj_status, status)

            obj_audits = AuditAnomalies.objects.get(id=user_id)
            audits_obj = AuditsSerializer()
            audits_data = audits_obj.update(obj_audits, audits)

            if document_type_data != None and site_data != None and status_data != None and audits_data != None:
                obj_anomalies = Anomalies.objects.get(id=user_id)
                anomalies_obj = AnomaliesSerializer()
                anomalies_data = anomalies_obj.update(obj_anomalies, anomalies)

                if anomalies_data != None:
                    return Response(formatResponse('Anomalies data saved', 'success', data_set,
                                                   status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class AnomaliesDataById(APIView):
    objLog = LogHelper('anomalies', 'AnomaliesDataById')
    def put(self, request, id):
        '''
        Method to update Anomalies data
        :param request:
        :return:
        '''
        try:
            data_set = dict(request.data)
            anom_id = id
            obj_anomalies = Anomalies.objects.get(id=anom_id, user_id=request.user.id)

            anomalies_obj = AnomaliesSerializer()
            anomalies_data = anomalies_obj.update(obj_anomalies, data_set)
            if anomalies_data != None:
                return Response(formatResponse('Anomalies data saved', 'success', data_set,
                                               status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))
