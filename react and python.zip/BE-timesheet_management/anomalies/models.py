"""Models for Anomalies app"""
from django.db import models
from baseapp.models import BaseModel
from accounts.models import TimesheetUser


class SiteType(BaseModel):
    """site model - Contains site names"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    site_type = models.CharField(default=None, max_length=100, blank=True)


class DocumentType(BaseModel):
    """document_type model - Contains Different document types"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    document_type = models.CharField(default=None, max_length=100, blank=True)


class Status(BaseModel):
    """status model - Contains Different status types"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    status = models.CharField(default=None, max_length=100, blank=True)


class Anomalies(BaseModel):
    """Anomalies model - Contains Anomalies data"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    status = models.ForeignKey(Status, on_delete=models.CASCADE)
    document_type = models.ForeignKey(DocumentType, on_delete=models.CASCADE)
    site_type = models.ForeignKey(SiteType, on_delete=models.CASCADE)
    plant = models.CharField(default=None, max_length=200, null=True)
    document = models.CharField(max_length=100, null=False)
    anomalies_status = models.CharField(null=True, default=None, max_length=20)


class AuditAnomalies(BaseModel):
    """Audits model - Contains Audits data"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=100, null=False)
    last_name = models.CharField(max_length=100, null=False)
    handle = models.CharField(max_length=100, null=False)
    anomalies = models.ForeignKey(Anomalies, on_delete=models.CASCADE)
