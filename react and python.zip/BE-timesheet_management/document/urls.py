from django.urls import path

from .views import DocumentData, DocumentDataById

urlpatterns = [
    path('document-data/', DocumentData.as_view()),
    path('document-data-by-id/', DocumentDataById.as_view()),

]
