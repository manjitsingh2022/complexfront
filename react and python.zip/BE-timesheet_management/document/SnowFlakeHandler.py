
from snowflake.connector import connect as snow_connect
from os import getenv
from datetime import datetime
from sys import exc_info
from logs.LogHandler import LogHelper


class SnowFlakeHelper():
    objLog = LogHelper('documentSnowflake', 'SnowFlakeHelper')
    account_identifier = getenv("SNOWFLAKE_ACCOUNT")
    username = getenv("SNOWFLAKE_USERNAME")
    password = getenv("SNOWFLAKE_PASSWORD")
    db_name = getenv("SNOWFLAKE_DB_NEW")
    schema = getenv("SNOWFLAKE_SCHEMA_NEW")
    warehouse = getenv("SNOWFLAKE_WAREHOUSE_NEW")

    comp = None
    def get_Documents_Data(self, company, selected_year, start_date, end_date,  offset, selected_machine, company_code, selected_filetype, doc_search, user_id, upto, user_role):
        try:
            doc_final_data = []
            data_result_dict = []
            data_result_dict2 = []

            data_list = []
            data_dict = {}
            year_list = []
            mach_list = []
            doc_type_list = [{'label':  'Purchase Order', 'value': 'Purchase Order', 'type': 'file_type'}, {
                'label': 'Invoice', 'value': 'Invoice', 'type': 'file_type'}]
            mach_sub_list = []
            hire_list = []
            no_of_pages = 1
            year = None
            comp = None
            if company == "Red Top Asset Management":
                comp = "'010R'"
            elif company == "Quartz Plant Hire":
                comp = "'004Q'"
            elif company == "KLT Machinery and Plant Hire":
                comp = "'006K'"
            else:
                comp = None

            company_code = "'"+company_code+"'"
            comp_codes = ('010R', '004Q', '006K')
            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            if selected_year:
                if selected_year != 'undefined' and selected_year != 'null':
                    year = selected_year
            cs = ctx.cursor()
            cs1 = ctx.cursor()
            cs2 = ctx.cursor()
            try:
                if user_role == "CFO" or  user_role == "Approver" :
                    if comp:
                        query2 = f'SELECT count(*) from "Merged_PO_INV" where "INV_Supplier"={comp}'
                        query3 = f'SELECT "Machine Type" from "Merged_PO_INV" where "INV_Supplier" IN {comp_codes}'
                        query = f'SELECT * from "Merged_PO_INV" where "INV_Supplier"={comp} '

                    else:

                        query2 = f'SELECT count(*) from "Merged_PO_INV" where "INV_Supplier" IN {comp_codes}'
                        query3 = f'SELECT "Machine Type" from "Merged_PO_INV" where "INV_Supplier" IN {comp_codes}'
                        query = f'SELECT * from "Merged_PO_INV" where "INV_Supplier" IN {comp_codes}'
                        
                else:
                    query2 = f'SELECT count(*) from "Merged_PO_INV" where "INV_Supplier"={company_code}'
                    query3 = f'SELECT "Machine Type" from "Merged_PO_INV" where "INV_Supplier"={company_code}'
                    query = f'SELECT * from "Merged_PO_INV" where "INV_Supplier"={company_code}'
                    
                if year:
                    query += f'and "INV_InvoiceYear"= {year} '
                    query2 += f'and "INV_InvoiceYear"= {year} '
                    # if start_date and end_date:
                    #     start_date = "'"+start_date+"'"
                    #     end_date = "'"+end_date+"'"
                    #     query += f'and "INV_InvoiceDate">= {start_date} and "INV_InvoiceDate"<= {end_date} '
                    #     query2 += f'and "INV_InvoiceDate">= {start_date} and "INV_InvoiceDate"<= {end_date} '
                if start_date and end_date:
                  
                    s_date = datetime.strptime(start_date, '%Y-%m-%d')
                    e_date = datetime.strptime(end_date, '%Y-%m-%d')

                    end_date = e_date.replace(hour=23, minute=59, second=59)

                    start_date = s_date.isoformat() + 'Z'
                    end_date = end_date.isoformat() + 'Z'   

                    start_date = "'"+start_date+"'"
                    end_date = "'"+end_date+"'"


                    # query += f'and "INV_InvoiceDate">= {start_date} and "INV_InvoiceDate"<= {end_date} '
                    # query2 += f'and "INV_InvoiceDate">= {start_date} and "INV_InvoiceDate"<= {end_date} '

                    query += f' and "INV_InvoiceDate" BETWEEN {start_date} AND {end_date}'
                    query2 += f' and "INV_InvoiceDate" BETWEEN {start_date} AND {end_date}'

                if selected_machine and selected_machine != 'null':
                    selected_machine = f"'{selected_machine}'"
                    query += f'and "Machine Type"= {selected_machine} '
                    query2 += f'and "Machine Type"= {selected_machine} '

                if doc_search and doc_search != 'null' and doc_search != 'Undefined':
                    srch_term = "'%"+doc_search+"%'"
                    query += f'and  ("INV_Supplier" ILIKE {srch_term} or "INVPay_Invoice" ILIKE {srch_term} or "Machine Type" ILIKE {srch_term} ) '
                    query2 += f'and  ("INV_Supplier" ILIKE {srch_term} or "INVPay_Invoice" ILIKE {srch_term} or "Machine Type" ILIKE {srch_term} ) '

                if selected_filetype != "Purchase Order" and selected_filetype != "Invoice":
                    if offset > 0:
                        query += f'limit 10 offset {offset/2}'
                    else:
                        query += f'limit 10 offset {offset}'
                else:
                    query += f'limit 20 offset {offset}'
                
         
                cs.execute(query)
                cs1.execute(query2)
                cs2.execute(query3)
                rows_count = cs1.fetchone()
                mach_rows = cs2.fetchall()

                column_names = [column[0] for column in cs.description]
                rows = cs.fetchall()
                if rows:
                    for row in rows:
                        row_data = dict(zip(column_names, row))
                        data_result_dict.append(row_data)
                if mach_rows:
                    for mc in mach_rows:
                        dct3 = {'label': mc[0], 'value': str(
                            mc[0]), 'type': 'mach_type'}
                        if dct3 not in mach_list:
                            mach_list.append(dct3)
                        # mch_data = dict(zip(column_names, mc))
                        # data_result_dict2.append(mch_data)
                try:
                    if selected_filetype != "Purchase Order" and selected_filetype != "Invoice":
                        rows_count = rows_count[0] * 2
                    else:
                        rows_count = rows_count[0]
                    if rows_count > 20:
                        pages = rows_count/20
                        remainder = int(rows_count % 20)
                        if remainder > 0:
                            no_of_pages = int(pages) + 1
                        else:
                            no_of_pages = pages
                    else:
                        no_of_pages = 1

                except:
                    no_of_pages = 1

                # if data_result_dict2:
                #     for mach in data_result_dict2:
                #         print("-->",mach[0])
                        
                #         dct3 = {'label': mach[0], 'value': str(
                #             mach[0]), 'type': 'mach_type'}
                #         if dct3 not in mach_list:
                #             mach_list.append(dct3)
                if data_result_dict:
                    for dt in data_result_dict:
                        if selected_filetype == "Invoice":
                            inv_dct = {
                                "supplier_code": dt['INV_Supplier'],
                                "document_type": 'Invoice',
                                "document_no": dt['INVPay_Invoice'],
                                "machine_type": dt['Machine Type'],
                                "invoice_date": dt['INV_InvoiceDate'],
                                "invoice_due": dt['INV_DueDate'],
                                "org_value": dt['INV_OrigInvValue'],
                                "total_adjustment": dt['INV_TotalAdjustments'],
                                "transaction": 'Payment',
                                "linked_doc": 'Purchase Order',
                                "linked_doc_no": dt['INV_Reference'],
                            }
                            # if inv_dct not in anom_final_data:
                            doc_final_data.append(inv_dct)

                        if selected_filetype == "Purchase Order":
                            dct_po = {
                                "supplier_code": dt['POHdr_Supplier'],
                                "document_type": 'Purchase Order',
                                "document_no": dt['INVPay_Invoice'],
                                "machine_type": dt['Machine Type'],
                                "invoice_date": dt['POHdr_OrderEntryDate'],
                                "invoice_due": dt['POHdr_OrderDueDate'],
                                "org_value": dt['PODet_MPrice'],
                                "total_adjustment": dt['INV_TotalAdjustments'],
                                "transaction": 'Payment',
                                "linked_doc": 'Purchase Order',
                                "linked_doc_no": dt['PODet_MOrderQty'],
                            }
                            # if dct_po not in anom_final_data:
                            doc_final_data.append(dct_po)

                        if selected_filetype == "null" or selected_filetype == None:

                            inv_dct = {
                                "supplier_code": dt['INV_Supplier'],
                                "document_type": 'Invoice',
                                "document_no": dt['INVPay_Invoice'],
                                "machine_type": dt['Machine Type'],
                                "invoice_date": dt['INV_InvoiceDate'],
                                "invoice_due": dt['INV_DueDate'],
                                "org_value": dt['INV_OrigInvValue'],
                                "total_adjustment": dt['INV_TotalAdjustments'],
                                "transaction": 'Payment',
                                "linked_doc": 'Purchase Order',
                                "linked_doc_no": dt['INV_Reference'],
                            }
                            dct_po = {
                                "supplier_code": dt['POHdr_Supplier'],
                                "document_type": 'Purchase Order',
                                "document_no": dt['INVPay_Invoice'],
                                "machine_type": dt['Machine Type'],
                                "invoice_date": dt['POHdr_OrderEntryDate'],
                                "invoice_due": dt['POHdr_OrderDueDate'],
                                "org_value": dt['PODet_MPrice'],
                                "total_adjustment": dt['INV_TotalAdjustments'],
                                "transaction": 'Payment',
                                "linked_doc": 'Purchase Order',
                                "linked_doc_no": dt['PODet_MOrderQty'],
                            }

                            doc_final_data.append(inv_dct)
                            doc_final_data.append(dct_po)

                        dct2 = {'label': dt['INV_InvoiceYear'], 'value': str(
                            dt['INV_InvoiceYear']), 'type': 'year'}
                        if dct2 not in year_list:
                            year_list.append(dct2)

                        dct4 = {'label': dt['Machine Subtype'], 'value': str(
                            dt['Machine Subtype']), 'type': 'mach_sub_type'}
                        if dct4 not in mach_sub_list:
                            mach_sub_list.append(dct4)

                        dct5 = {'label': dt['Hire Type'], 'value': str(
                            dt['Hire Type']), 'type': 'hire_type'}
                        if dct5 not in hire_list:
                            hire_list.append(dct5)

                    if offset == 0:
                        offset = 1

                    if offset > 1:
                        offset += 1

                    if upto > rows_count:
                        upto = rows_count

                    data_dict = {"doc_data": doc_final_data,
                                 "no_of_pages": no_of_pages, "year_list": year_list, "mach_list": mach_list,
                                 "mach_sub_list": mach_sub_list, "hire_list": hire_list,
                                 "doc_type_list": doc_type_list, "offset": offset, "upto": upto, "total_count": rows_count}

                else:
                    data_dict = {"doc_data": doc_final_data,
                                 "no_of_pages": 0, "year_list": year_list, "mach_list": mach_list, "doc_type_list": doc_type_list}

                return data_dict

            except:
                self.objLog.doLog(exc_info(), 'error')
                return data_dict

            finally:
                cs.close()
                ctx.close()
        except:
            self.objLog.doLog(exc_info(), 'error')
            pass

    def get_Documents_count(self):
        try:
            doc_count = 0
            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            cs = ctx.cursor()
            query = 'SELECT count(*) from "Merged_PO_INV"'
            cs.execute(
                query)
            doc_count = cs.fetchone()

            return doc_count

        except:
            self.objLog.doLog(exc_info(), 'error')
            return doc_count

    def get_month_name(self, month_number):
        month_names = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ]

        if 1 <= month_number <= 12:
            return month_names[month_number - 1]
        else:
            return 'Invalid month number'

    def get_Documents_graph_data(self, month_count,comp):
        graph_data = None
        try:
            from datetime import datetime
            company_code = "'"+comp+"'"
            current_year = datetime.now().year
            current_month = datetime.now().month
            # query = f'''
            #             SELECT "INV_InvoiceMonth" AS month,
            #             COUNT(*) AS record_count
            #             FROM DEV_YMH.CORE."Merged_PO_INV"
            #             WHERE "INV_InvoiceYear" = {current_year}
            #             GROUP BY month
            #             ORDER BY month
            #         '''
            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            if int(month_count) == 12:
                #  SELECT "INV_InvoiceMonth" AS month,
                #             COUNT(*) AS record_count
                #             FROM DEV_YMH.CORE."Merged_PO_INV"
                #             WHERE "INV_InvoiceYear" = {current_year} and "INV_InvoiceMonth" <= {current_month}
                #             GROUP BY month
                #             ORDER BY month
                #  SELECT
                #             DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) AS month,
                #             COUNT(*) AS count_data
                #             FROM
                #             DEV_YMH.CORE."Merged_PO_INV"
                #             WHERE "INV_Supplier"={company_code} AND
                #             DATE_PART('year', TO_TIMESTAMP("INV_InvoiceDate")) = {current_year}
                #             AND DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) <= {current_month}
                #             GROUP BY
                #             month
                #             ORDER BY
                #             month;
                query = f'''
                            WITH RECURSIVE months AS (
                                SELECT 1 AS month
                                UNION ALL
                                SELECT month + 1
                                FROM months
                                WHERE month < {current_month}
                                )
                                SELECT
                                months.month AS month,
                                COALESCE(data.count_data, 0) AS count_data
                                FROM months
                                LEFT JOIN (
                                SELECT
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) AS month,
                                    COUNT(*) AS count_data
                                FROM
                                    DEV_YMH.CORE."Merged_PO_INV"
                                WHERE
                                    "INV_Supplier" = {company_code} AND
                                    DATE_PART('year', TO_TIMESTAMP("INV_InvoiceDate")) = {current_year} AND
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) <= {current_month}
                                GROUP BY
                                    month
                                ) data ON months.month = data.month
                                ORDER BY
                                months.month;'''
                #  SELECT "INV_InvoiceMonth" AS month,
                #             COUNT(*) AS record_count
                #             FROM DEV_YMH.CORE."Merged_PO_INV"
                #             WHERE "INV_InvoiceYear" = {current_year - 1} and "INV_InvoiceMonth" > {current_month}
                #             GROUP BY month
                #             ORDER BY month
                query2 = f'''
                       WITH RECURSIVE months AS (
                        SELECT {current_month} AS month -- Start with the current_month
                        UNION ALL
                        SELECT month + 1
                        FROM months
                        WHERE month < 12 -- Adjust this to the highest month value you need (12 for December)
                    )
                    SELECT
                        months.month AS month,
                        COALESCE(data.count_data, 0) AS count_data
                    FROM months
                    LEFT JOIN (
                        SELECT
                            DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) AS month,
                            COUNT(*) AS count_data
                        FROM
                            DEV_YMH.CORE."Merged_PO_INV"
                        WHERE
                            "INV_Supplier" = {company_code} AND
                            DATE_PART('year', TO_TIMESTAMP("INV_InvoiceDate")) = {current_year-1} AND
                            DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) >= {current_month} -- Change the condition to >=
                        GROUP BY
                            month
                    ) data ON months.month = data.month
                    ORDER BY
                        months.month;
                                    '''

                cs = ctx.cursor()

                cs.execute(query)
                results = cs.fetchall()

                if len(results) < 12:

                    cs2 = ctx.cursor()
                    cs2.execute(query2)

                    results2 = cs2.fetchall()
                else:
                    results2 = []
            else:
             
                query = f'''
                            WITH RECURSIVE months AS (
                                SELECT 1 AS month
                                UNION ALL
                                SELECT month + 1
                                FROM months
                                WHERE month < {current_month}
                                )
                                SELECT
                                months.month AS month,
                                COALESCE(data.count_data, 0) AS count_data
                                FROM months
                                LEFT JOIN (
                                SELECT
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) AS month,
                                    COUNT(*) AS count_data
                                FROM
                                    DEV_YMH.CORE."Merged_PO_INV"
                                WHERE
                                    "INV_Supplier" = {company_code} AND
                                    DATE_PART('year', TO_TIMESTAMP("INV_InvoiceDate")) = {current_year} AND
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) <= {current_month}
                                GROUP BY
                                    month
                                ) data ON months.month = data.month
                                ORDER BY
                                months.month  DESC
                                LIMIT 6;
                        '''
                cs = ctx.cursor()
                cs.execute(query)
                results = cs.fetchall()

                # SELECT "INV_InvoiceMonth" AS month,
                # COUNT(*) AS record_count
                # FROM DEV_YMH.CORE."Merged_PO_INV"
                # WHERE "INV_InvoiceYear" = {current_year - 1} and "INV_InvoiceMonth" > {current_month}
                # GROUP BY month
                # ORDER BY month  desc
                # limit {6-len(results)}
                query2 = f'''
                            WITH RECURSIVE months AS (
                                SELECT 1 AS month
                                UNION ALL
                                SELECT month + 1
                                FROM months
                                WHERE month < {current_month}
                                )
                                SELECT
                                months.month AS month,
                                COALESCE(data.count_data, 0) AS count_data
                                FROM months
                                LEFT JOIN (
                                SELECT
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) AS month,
                                    COUNT(*) AS count_data
                                FROM
                                    DEV_YMH.CORE."Merged_PO_INV"
                                WHERE
                                    "INV_Supplier" = {company_code} AND
                                    DATE_PART('year', TO_TIMESTAMP("INV_InvoiceDate")) = {current_year - 1} AND
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) > {current_month}
                                GROUP BY
                                    month
                                ) data ON months.month = data.month
                                ORDER BY
                                months.month 
                            limit {6-len(results)};
                        '''
                
                if len(results) < 6:

                    cs2 = ctx.cursor()
                    cs2.execute(query2)

                    results2 = cs2.fetchall()
                    results2 = results2[::-1]
                else:
                    from sys import exc_info
                    results2 = []
                    results = results[::-1]


            data_list = []
            month_list = []

            for data in results2:
                data_list.append(data[1])

            for month in results2:
                mnth = self.get_month_name(month[0])
                month_list.append(mnth)

            for data in results:
                data_list.append(data[1])

            for month in results:
                mnth = self.get_month_name(month[0])
                month_list.append(mnth)

            graph_data = {"month_list": month_list, "data_list": data_list}

            return graph_data

        except:
            self.objLog.doLog(exc_info(), 'error')
            return graph_data

    def get_Documents_graph_data2(self, month_count):
        graph_data = None
        try:
            from datetime import datetime
            current_year = datetime.now().year
            current_month = datetime.now().month
            # query = f'''
            #             SELECT "INV_InvoiceMonth" AS month,
            #             COUNT(*) AS record_count
            #             FROM DEV_YMH.CORE."Merged_PO_INV"
            #             WHERE "INV_InvoiceYear" = {current_year}
            #             GROUP BY month
            #             ORDER BY month
            #         '''
            ctx = snow_connect(
                user=self.username,
                password=self.password,
                account=self.account_identifier,
                database=self.db_name,
                warehouse=self.warehouse,
                schema=self.schema,
                autocommit=True
            )
            if int(month_count) == 12:

                query = f'''
                            WITH RECURSIVE months AS (
                                SELECT 1 AS month
                                UNION ALL
                                SELECT month + 1
                                FROM months
                                WHERE month < {current_month}
                                )
                                SELECT
                                months.month AS month,
                                COALESCE(data.count_data, 0) AS count_data
                                FROM months
                                LEFT JOIN (
                                SELECT
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) AS month,
                                    COUNT(*) AS count_data
                                FROM
                                    DEV_YMH.CORE."Merged_PO_INV"
                                WHERE
                                    
                                    DATE_PART('year', TO_TIMESTAMP("INV_InvoiceDate")) = {current_year} AND
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) <= {current_month}
                                GROUP BY
                                    month
                                ) data ON months.month = data.month
                                ORDER BY
                                months.month;  '''

                query2 = f'''
                       WITH RECURSIVE months AS (
                        SELECT {current_month} AS month -- Start with the current_month
                        UNION ALL
                        SELECT month + 1
                        FROM months
                        WHERE month < 12 -- Adjust this to the highest month value you need (12 for December)
                    )
                    SELECT
                        months.month AS month,
                        COALESCE(data.count_data, 0) AS count_data
                    FROM months
                    LEFT JOIN (
                        SELECT
                            DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) AS month,
                            COUNT(*) AS count_data
                        FROM
                            DEV_YMH.CORE."Merged_PO_INV"
                        WHERE
                            
                            DATE_PART('year', TO_TIMESTAMP("INV_InvoiceDate")) = {current_year-1} AND
                            DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) >= {current_month} -- Change the condition to >=
                        GROUP BY
                            month
                    ) data ON months.month = data.month
                    ORDER BY
                        months.month;
                                    '''

                cs = ctx.cursor()

                cs.execute(query)
                results = cs.fetchall()

                if len(results) < 12:

                    cs2 = ctx.cursor()
                    cs2.execute(query2)

                    results2 = cs2.fetchall()
                else:
                    results2 = []
            else:
                query = f'''
                            WITH RECURSIVE months AS (
                                SELECT 1 AS month
                                UNION ALL
                                SELECT month + 1
                                FROM months
                                WHERE month < {current_month}
                                )
                                SELECT
                                months.month AS month,
                                COALESCE(data.count_data, 0) AS count_data
                                FROM months
                                LEFT JOIN (
                                SELECT
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) AS month,
                                    COUNT(*) AS count_data
                                FROM
                                    DEV_YMH.CORE."Merged_PO_INV"
                                WHERE
                                    
                                    DATE_PART('year', TO_TIMESTAMP("INV_InvoiceDate")) = {current_year} AND
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) <= {current_month}
                                GROUP BY
                                    month
                                ) data ON months.month = data.month
                                ORDER BY
                                months.month DESC
                                LIMIT 6;
                        '''
                cs = ctx.cursor()
                cs.execute(query)
                results = cs.fetchall()


                # SELECT "INV_InvoiceMonth" AS month,
                # COUNT(*) AS record_count
                # FROM DEV_YMH.CORE."Merged_PO_INV"
                # WHERE "INV_InvoiceYear" = {current_year - 1} and "INV_InvoiceMonth" > {current_month}
                # GROUP BY month
                # ORDER BY month  desc
                # limit {6-len(results)}
                query2 = f'''
                            WITH RECURSIVE months AS (
                                SELECT 1 AS month
                                UNION ALL
                                SELECT month + 1
                                FROM months
                                WHERE month < {current_month}
                                )
                                SELECT
                                months.month AS month,
                                COALESCE(data.count_data, 0) AS count_data
                                FROM months
                                LEFT JOIN (
                                SELECT
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) AS month,
                                    COUNT(*) AS count_data
                                FROM
                                    DEV_YMH.CORE."Merged_PO_INV"
                                WHERE
                                   
                                    DATE_PART('year', TO_TIMESTAMP("INV_InvoiceDate")) = {current_year - 1} AND
                                    DATE_PART('month', TO_TIMESTAMP("INV_InvoiceDate")) > {current_month}
                                GROUP BY
                                    month
                                ) data ON months.month = data.month
                                ORDER BY
                                months.month 
                            limit {6-len(results)};
                        '''
                if len(results) < 6:

                    cs2 = ctx.cursor()
                    cs2.execute(query2)

                    results2 = cs2.fetchall()
                    results2 = results2[::-1]
                else:
                    results2 = []
                    results = results[::-1]


            data_list = []
            month_list = []

            for data in results2:
                data_list.append(data[1])

            for month in results2:
                mnth = self.get_month_name(month[0])
                month_list.append(mnth)

            for data in results:
                data_list.append(data[1])

            for month in results:
                mnth = self.get_month_name(month[0])
                month_list.append(mnth)

            graph_data = {"month_list": month_list, "data_list": data_list}

            return graph_data

        except:
            self.objLog.doLog(exc_info(), 'error')
            return graph_data
