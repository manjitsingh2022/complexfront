"""Document app's serilizers"""

from rest_framework import serializers
from .models import Documents, FileType, Company, MachineSecond, Foreman, AuditDocument


class DocumentSerializer(serializers.ModelSerializer):
    """Document table's serializer"""
    class Meta:
        model = Documents
        fields = ('id', 'user', 'foreman', 'machine', 'company',
                  'file_type', 'start_time', 'end_time', 'odometer', 'driver', 'Fuel', 'address', 'pin_code')


class FileTypeSerializer(serializers.ModelSerializer):
    """FileType table's serializer"""
    class Meta:
        model = FileType
        fileds = ('user', 'file_type')


class CompanySerializer(serializers.ModelSerializer):
    """Company table's serializer"""
    class Meta:
        model = Company
        fileds = ('user', 'company_name')


class MachineSerializer(serializers.ModelSerializer):
    """Machine table's serializer"""
    class Meta:
        model = MachineSecond
        fileds = ('user', 'machine_type')


class ForemanSerializer(serializers.ModelSerializer):
    """Foreman table's serializer"""
    class Meta:
        model = Foreman
        fileds = ('user', 'foreman_name')


class AuditsDocumentSerializer(serializers.ModelSerializer):
    """Foreman table's serializer"""
    class Meta:
        model = AuditDocument
        # fileds = ('user', 'first_name', 'last_name', 'handle', 'id')
        fields = '__all__'
