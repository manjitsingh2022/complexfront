from django.db import models
from baseapp.models import BaseModel
from accounts.models import TimesheetUser
from machine.models import MachineSecond


class FileType(BaseModel):
    """FileType model - Contains Different file types"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    file_type = models.CharField(default=None, max_length=100, blank=True)


class Company(BaseModel):
    """Company model - Contains comapany names"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    company_name = models.CharField(default=None, max_length=200, blank=True)


class Foreman(BaseModel):
    """Foreman model - Contains foreman names"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    foreman_name = models.CharField(default=None, max_length=200, blank=True)


class Documents(BaseModel):
    """Documents model - Contains Document data"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    foreman = models.ForeignKey(Foreman, on_delete=models.CASCADE)
    machine = models.ForeignKey(MachineSecond, on_delete=models.CASCADE)
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    file_type = models.ForeignKey(FileType, on_delete=models.CASCADE)
    # audits = models.ForeignKey(AuditDocument, on_delete=models.CASCADE)
    start_time = models.TimeField(default=None)
    end_time = models.TimeField(default=None)
    odometer = models.CharField(default=None, max_length=100)
    driver = models.CharField(default=None, max_length=100)
    Fuel = models.CharField(default=None, max_length=100)
    address = models.CharField(default=None, max_length=100, null=True)
    pin_code = models.IntegerField(default=None, null=True)


class AuditDocument(BaseModel):
    """AuditDocument model - Contains Audits data"""
    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    document = models.ForeignKey(Documents, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=100, null=False)
    last_name = models.CharField(max_length=100, null=False)
    handle = models.CharField(max_length=100, null=False)
