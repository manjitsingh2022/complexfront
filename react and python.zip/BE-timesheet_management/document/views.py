from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from baseapp.utils import formatResponse
from rest_framework.permissions import IsAuthenticated
from .models import Documents, Foreman, Company, FileType, AuditDocument
from .serializers import DocumentSerializer, ForemanSerializer, FileTypeSerializer, CompanySerializer, AuditsDocumentSerializer
from sys import exc_info
from machine.serializers import MachineSerializer
from django.db.models import Q
from datetime import datetime
from audits.models import Audit
from audits.serializers import AuditSerializer
from machine.models import MachineSecond
from .SnowFlakeHandler import SnowFlakeHelper
from logs.LogHandler import LogHelper
from sys import exc_info

class DocumentData(APIView):
    objLog = LogHelper('document', 'DocumentData')
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        '''
        Method to get Document data
        :param request:
        :return:
        '''
       
        query = (Q())

        try:
            user = request.user.id
            user_role = request.user.role.role
            company_code = request.user.company_code
            selected_machine = request.GET.get('machineType', None)
            selected_foreman = request.GET.get('foremanType', None)
            selected_comapny = request.GET.get('companyType', None)
            selected_filetype = request.GET.get('fileType', None)
            doc_search = request.GET.get('doc_search', None)
            start_date = request.GET.get('start_date', None)
            end_date = request.GET.get('end_date', None)
            page = int(request.GET.get('page_no', 0))
            selected_year = request.GET.get('year', None)

            if request.user.role.role == "Contractor" or request.user.role.role == "Subcontractor" :
                selected_comapny = request.user.company_name

            upto = 20 * page
            offset = 0
            try:
                if page == 0 or page == 1:
                    offset = 0
                else:
                    offset = (page - 1) * 20

            except:
                pass

            if str(start_date) == 'null' or str(start_date) == 'undefined':
                start_date = None
                end_date = None

            snf_obj = SnowFlakeHelper()
            data = snf_obj.get_Documents_Data(
                selected_comapny, selected_year, start_date, end_date, offset,
                selected_machine, company_code, selected_filetype, doc_search, user, upto,user_role)

            # if selected_machine != None and selected_machine != "null" and selected_machine != '':
            #     query = Q(machine__make=selected_machine)

            # if selected_foreman != None and selected_foreman != "null" and selected_foreman != '':
            #     if query != None:
            #         query.add((Q(foreman__foreman_name=selected_foreman)), query.connector)
            #     else:
            #         query = (Q(foreman__foreman_name=selected_foreman))

            # if selected_comapny != None and selected_comapny != "null" and selected_comapny != '':
            #     if query != None:
            #         query.add((Q(company__company_name=selected_comapny)), query.connector)
            #     else:
            #         query = (Q(company__company_name=selected_comapny))

            # if selected_filetype != None and selected_filetype != "null" and selected_filetype != '':
            #     if query != None:
            #         query.add((Q(file_type__file_type=selected_filetype)), query.connector)
            #     else:
            #         query = (Q(file_type__file_type=selected_filetype))

            # if start_date != "null" and start_date != "" and start_date != None and end_date != "null" and end_date != "" and end_date != None:
            #     try:
            #         start_date = datetime.strptime(start_date, '%d-%m-%Y').date()
            #         end_date = datetime.strptime(end_date, '%d-%m-%Y').date()

            #         if query != None:
            #             query.add(
            #                 (Q(created_at__gte=start_date, created_at__lte=end_date)), query.connector)
            #         else:
            #             query = (Q(created_at__gte=start_date, created_at__lte=end_date))

            #     except:
            #         pass
            # try:
            # d_obj = Documents.objects.filter(
            #     query, user=user)[offset:upto]
            # record_count = Documents.objects.filter(query, user=user).count()

            #     if d_obj:
            #         ds_obj = DocumentSerializer(d_obj, many=True)

            #         documents_data = ds_obj.data
            #         for x in documents_data:
            #             mac_obj = MachineSecond.objects.get(id=x['machine'])
            #             if mac_obj:
            #                 mac_data = MachineSerializer(mac_obj)
            #                 x["machine_data"] = mac_data.data
            #             else:
            #                 x["machine_data"] = []

            #             try:
            #                 aud_obj = Audit.objects.filter(document=x['id'])
            #                 if aud_obj:
            #                     aud_data = AuditSerializer(aud_obj, many=True)
            #                     x['audit_data'] = aud_data.data
            #                 else:
            #                     x['audit_data'] = []

            #             except:
            #                 x['audit_data'] = []
            #             # aud_obj = AuditDocument.objects.filter(document=x['id'])

            #             # if aud_obj:
            #             #     aud_data = AuditsDocumentSerializer(aud_obj, many=True)
            #             #     x['audit_data'] = aud_data.data

            #             # else:
            #             #     aud_data = []

            # except:
            #     pass

            # try:
            #     if record_count > 20:
            #         pages = record_count/20
            #         if type(pages) == float:
            #             split_num = str(pages).split('.')
            #             no_of_pages = int(split_num[0])+1

            #     else:
            #         no_of_pages = 1

            # except:
            #     no_of_pages = 1

            # try:
            #     a_obj = m_obj = AuditDocument.objects.filter(user=user)
            #     as_obj = AuditsDocumentSerializer(a_obj, many=True)
            #     audit_data = as_obj.data
            # except:
            #     pass

            # try:
            #     m_obj = MachineSecond.objects.filter(user=user).values_list(
            #         'machine_type', flat=True).distinct()

            #     if m_obj:
            #         for x in m_obj:
            #             machine_list.append({'label': x, 'value': x, 'type': 'machine'})
            # except:
            #     pass
            # try:
            #     c_obj = Company.objects.filter(user=user).values_list(
            #         'company_name', flat=True).distinct()

            #     if c_obj:
            #         for x in c_obj:
            #             company_list.append({'label': x, 'value': x, 'type': 'company'})
            # except:
            #     pass
            # try:
            #     f_obj = Foreman.objects.filter(user=user).values_list(
            #         'foreman_name', flat=True).distinct()
            #     if f_obj:
            #         for x in f_obj:
            #             foreman_list.append({'label': x, 'value': x, 'type': 'foreman'})
            # except:
            #     pass

            # try:
            #     ft_obj = FileType.objects.filter(user=user).values_list(
            #         'file_type', flat=True).distinct()
            #     if ft_obj:
            #         for x in ft_obj:
            #             type_list.append({'label': x, 'value': x, 'type': 'filetype'})
            # except:
            #     pass

            # data_dict = {'machine': machine_list, 'foreman': foreman_list, 'file_type': type_list,
            #              'company': company_list, 'doc_machine': documents_data, 'no_of_pages': no_of_pages,
            #              'audit_data': audit_data}
            return Response(formatResponse('Document data found', 'success', data,
                                           status.HTTP_200_OK))
        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))

    def post(self, request):
        '''
        Method to save Document data
        :param request:
        :return:
        '''
        try:
            data_set = dict(request.data)
            user = request.user.id
            save_file = None
            save_foreman = None
            save_company = None
            save_machine = None
            save_document = None
            if data_set:
                file_type = data_set['file_type']
                machine = data_set['machine']
                company = data_set['company']
                document = data_set['document']
                foreman = data_set['company']

                if file_type['file_type'] == 'null' or file_type['file_type'] == "":
                    return Response(formatResponse('file type is required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                if company['company_name'] == 'null' or company['company_name'] == "":
                    return Response(formatResponse('company name type is required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                if foreman['foreman_name'] == 'null' or foreman['foreman_name'] == "":
                    return Response(formatResponse('foreman name required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                if machine['machine_name'] == 'null' or machine['machine_name'] == "":
                    return Response(formatResponse('machine name required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                if document['driver'] == 'null' or document['driver'] == "":
                    return Response(formatResponse('driver required', 'error', None,
                                                   status.HTTP_400_BAD_REQUEST))

                file_type_obj = FileTypeSerializer()
                file_type['user_id'] = user
                save_file = file_type_obj.create(file_type)

                company_obj = CompanySerializer()
                company['user_id'] = user
                save_company = company_obj.create(company)

                foreman_obj = ForemanSerializer()
                foreman['user_id'] = user
                save_foreman = foreman_obj.create(foreman)

                machine_obj = MachineSerializer()
                machine['user_id'] = user
                save_machine = machine_obj.create(machine)

                if save_machine != None and save_company != None and save_file != None and save_foreman != None:
                    document_obj = DocumentSerializer()
                    document['user_id'] = user
                    document['foreman_id'] = user
                    document['company_id'] = user
                    document['file_type_id'] = user
                    document['machine_id'] = user
                    save_document = document_obj.create(document)

                    if save_document != None:
                        return Response(formatResponse('Document data saved', 'success', data_set,
                                                       status.HTTP_200_OK))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))


class DocumentDataById(APIView):
    permission_classes = (IsAuthenticated,)
    objLog = LogHelper('document', 'DocumentDataById')

    def get(self, request):
        '''
        Method to get Document data by id
        :param request:
        :return:
        '''
        document_id = request.GET.get("document", None)
        user_id = request.user.id
        machine_data = None
        foreman_data = None
        comapnay_data = None
        file_type_data = None
        document_data = None
        data_dict = {}
        try:
            if document_id:
                d_obj = Documents.objects.get(id=document_id, user=user_id)
                if d_obj:
                    d_serial = DocumentSerializer(d_obj)
                    document_data = d_serial.data
                    if document_data:
                        machine_obj = MachineSecond.objects.get(id=document_data['machine'])
                        mach_serial = MachineSerializer(machine_obj)
                        machine_data = mach_serial.data

                        foreman_obj = Foreman.objects.get(id=document_data['foreman'])
                        foreman_serial = ForemanSerializer(foreman_obj)
                        foreman_data = foreman_serial.data

                        file_obj = FileType.objects.get(id=document_data['file_type'])
                        file_serial = FileTypeSerializer(file_obj)
                        file_type_data = file_serial.data

                        company_obj = Company.objects.get(id=document_data['company'])
                        company_serial = CompanySerializer(company_obj)
                        comapnay_data = company_serial.data

                        data_dict = {"machine": machine_data, "foreman_data": foreman_data,
                                     "file_type": file_type_data, "comapnay_data": comapnay_data,
                                     "document_data": document_data
                                     }

                        return Response(formatResponse('Machine data found', 'success', data_dict,
                                                       status.HTTP_200_OK))
            else:
                return Response(formatResponse('Document Id required', 'error', None,
                                               status.HTTP_400_BAD_REQUEST))

        except:
            self.objLog.doLog(exc_info(), 'error')
            return Response(formatResponse('Internal Server Error', 'error', None,
                                           status.HTTP_500_INTERNAL_SERVER_ERROR))
