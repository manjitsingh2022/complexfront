"""Audit app's serilizers"""

from rest_framework import serializers
from .models import Audit


class AuditSerializer(serializers.ModelSerializer):
    """Foreman table's serializer"""
    class Meta:
        model = Audit
        fields = '__all__'
