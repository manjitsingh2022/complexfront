from django.db import models
from baseapp.models import BaseModel
from accounts.models import TimesheetUser
from document.models import Documents
from telematics.models import Telematics
from anomalies.models import Anomalies


AUDIT_TYPE_CHOICES = (
    ("Telematics", "Telematics"),
    ("Document", "Document"),
    ("Anomalies", "Anomalies")
)


class Audit(BaseModel):

    """Audit model - Contains Audits data"""

    user = models.ForeignKey(TimesheetUser, on_delete=models.CASCADE)
    what = models. CharField(default=None, max_length=100, blank=True, null=True)
    when = models. CharField(default=None, max_length=100, blank=True, null=True)
    who = models. CharField(default=None, max_length=100, blank=True, null=True)
    audit_type = models.CharField(max_length=30, choices=AUDIT_TYPE_CHOICES,
                                  null=True, blank=True, default=None)
    document = models.ForeignKey(Documents, default=True, blank=True,
                                 null=True, on_delete=models.CASCADE)
    telematics = models.ForeignKey(Telematics, default=True, blank=True,
                                   null=True, on_delete=models.CASCADE)
    anomalies = models.ForeignKey(Anomalies, default=True, blank=True,
                                  null=True, on_delete=models.CASCADE)
